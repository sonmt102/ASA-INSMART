﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Memory
{
    public class VIPBlackList
    {
        [Key]
        public Guid Id { get; set; }
        public string Phone { get; set; }
        public bool IsVIP { get; set; }
    }
}
