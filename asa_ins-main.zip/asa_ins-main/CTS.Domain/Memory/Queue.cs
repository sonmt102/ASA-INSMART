﻿using CTS.Common;

namespace CTS.Domain.Memory
{
    public class Queue
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        public virtual List<QueueWaiting> QueueWaitings { get; set; }
        public CallDirection Direction { get; set; }
        public virtual ICollection<QueueAccount> QueueAccounts { get; set; }
    }
}
