﻿namespace CTS.Domain.Memory
{
    public class VOCAssignAccount
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public bool Assigned { get; set; }
        public int Counter { get; set; }
    }
}
