﻿using CTS.Common;
using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Memory
{
    public class CallData
    {
        [Key]
        public string UniqueId { get; set; }
        public DateTime DateReceived { get; set; }
        public int TimeCounter
        {
            get
            {
                var item = (DateTime.Now - DateReceived).TotalSeconds;
                if (!Double.IsNaN(item)) return Convert.ToInt32(item);
                return 0;
            }
        }
        public string? CallStatus { get; set; }
        public string? CusPhone { get; set; }
        public string? Direction { get; set; }
        public CallCoreDirection CallDirection { get; set; }
        public string? LinkedId { get; set; }
        public string? Exten { get; set; }
        public string? Queue { get; set; }
        public string? AnswerTime { get; set; }
        public string? AgentExten { get; set; }
        public string? CallType { get; set; }
        public string? AgentAccount { get; set; }
        public string? AgentFullName { get; set; }
        public string? Channel { get; set; }
    }
}
