﻿namespace CTS.Domain.Memory
{
    public class ActiveLog
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public DateTime StartTime { get; set; }
        public string? Extension { get; set; }
        public string? StatusCode { get; set; }
        public string? Queues { get; set; }
        public bool IsHandler { get; set; }
        public virtual Account Account { get; set; }
    }
}
