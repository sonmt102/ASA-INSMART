﻿namespace CTS.Domain.Memory
{
    public class QueueAccount
    {
        public Guid QueueId { get; set; }
        public virtual Queue Queue { get; set; }
        public Guid AccountId { get; set; }
        public virtual Account Account { get; set; }
        public int? Priority { get; set; }
        public string? StatusCode { get; set; }
        public bool IsPause { get; set; } = true;
        /// <summary>
        /// Cuộc gọi đang đổ chuông trong nhóm với agent này
        /// </summary>
        public bool IsRinging { get; set; } = false;
        /// <summary>
        /// Cuộc gọi đã được agent này nghe máy
        /// </summary>
        public bool IsInCall { get; set; } = false;
        public string? CusPhone { get; set; }
        public DateTime? CallTime { get; set; }

    }
}
