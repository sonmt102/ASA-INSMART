﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Memory
{
    /// <summary>
    /// Đầu số của công ty, ví dụ: 19001900
    /// </summary>
    public class Extension
    {
        [Key]
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        /// <summary>
        /// Đầu số
        /// </summary>
        public string? Exten { get; set; }
        public virtual ICollection<CalendarIVR> CalendarIVRs { get; set; }
    }
}
