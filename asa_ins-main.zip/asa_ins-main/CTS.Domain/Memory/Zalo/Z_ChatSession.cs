﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Zalo.Memory
{
    public class Z_ChatSession
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public virtual ICollection<Z_ChatSessionOA> OAs { get; set; }
        public string Token { get; set; }
        public bool IsDistributed { get; set; }
        public virtual ICollection<Z_ChatSessionSender> Senders { get; set; }
    }

    public class Z_ChatSessionOA
    {
        [Key]
        public Guid Id { get; set; }
        public string OA { get; set; }
        public virtual Z_ChatSession Z_ChatSession { get; set; }
    }

    public class Z_ChatSessionSender
    {
        [Key]
        public Guid Id { get; set; }
        public string OA { get; set; }
        public string Sender { get; set; }
        public virtual Z_ChatSession Z_ChatSession { get; set; }
    }
}
