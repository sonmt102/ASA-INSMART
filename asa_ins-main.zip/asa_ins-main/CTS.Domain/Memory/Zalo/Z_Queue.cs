﻿using CTS.Domain.Memory;

namespace CTS.Domain.Zalo.Memory
{
    public class Z_Queue
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<Z_QueueAccount> Z_QueueAccounts { get; set; }
    }

    public class Z_QueueAccount
    {
        public Guid Z_QueueId { get; set; }
        public virtual Z_Queue Z_Queue { get; set; }
        public Guid AccountId { get; set; }
        public virtual Account Account { get; set; }
    }
}
