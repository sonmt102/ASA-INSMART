﻿namespace CTS.Domain.Memory
{
    public class QueueWaiting
    {
        public Guid Id { get; set; }
        public Guid QueueId { get; set; }
        public string UniqueId { get; set; }
        public virtual Queue Queue { get; set; }
    }
}
