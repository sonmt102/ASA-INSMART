﻿namespace CTS.Domain.Memory
{
    public class AgentStatusCategory
    {
        public Guid Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
        public bool IsPause { get; set; }
        public bool IsAllowAgentHandler { get; set; }
        public bool IsAllowSupHandler { get; set; }
    }
}
