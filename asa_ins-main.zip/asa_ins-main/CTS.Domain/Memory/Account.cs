﻿using CTS.Common;
using System.ComponentModel.DataAnnotations;
namespace CTS.Domain.Memory
{
    public class Account
    {
        [Key]
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string? IP { get; set; }
        public bool IsLogin { get; set; }
        public bool IsLoginExtension { get; set; }
        public int Online { get; set; }
        public DateTime? LoginDate { get; set; }
        public string? Extension { get; set; }
        public bool UseIPPhone { get; set; }
        public bool UseSoftPhone { get; set; }
        public bool UseWebPhone { get; set; }
        public bool IsPrimary { get; set; }
        /// <summary>
        /// Chứa thông tin kênh khi có cuộc gọi (ring hoặc answer)
        /// </summary>
        public string? Channel { get; set; }
        public string? Context { get; set; }
        public bool IsMute { get; set; } = false;
        /// <summary>
        /// Trạng thái cuộc gọi
        /// </summary>
        public DateTime? CallTime { get; set; }
        /// <summary>
        /// Số điện thoại gọi đến
        /// </summary>
        public string? CusPhone { get; set; }
        /// <summary>
        /// Hướng cuộc gọi
        /// </summary>
        public string? LinkedId { get; set; }
        /// <summary>
        /// Hướng cuộc gọi
        /// </summary>
        public virtual CallCoreDirection Direction { get; set; } = CallCoreDirection.Intercom;
        /// <summary>
        /// Trạng thái cuộc gọi
        /// </summary>
        public AgentStatusCall StatusCall { get; set; } = AgentStatusCall.None;
        /// <summary>
        /// Chứa những queue agent đã tham gia
        /// </summary>
        public virtual List<QueueAccount> QueueAccounts { get; set; }
        public virtual List<AccountInTicket> AccountInTickets { get; set; }
        public virtual List<MailQueueAccount> MailQueueAccount { get; set; }
        public virtual List<MailGroupAccount> MailGroupAccounts { get; set; }
    }


    public class MailQueueAccount
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public string QueueName { get; set; }
        public string QueueCode { get; set; }
        public bool IsLeader { get; set; }
    }

    public class MailGroupAccount
    {
        public Guid AccountId { get; set; }
        public string AccountUserName { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public string InboxQueueCode { get; set; }
        public string? RegexCondition { get; set; }
        public bool IsLeader { get; set; }
        public bool IsPause { get; set; }
        public string Status { get; set; }
        public bool IsAssign { get; set; }
        public int AssignTimes { get; set; }
    }

    public class AccountInTicket
    {
        public Guid AccountId { get; set; }
        public virtual Account Account { get; set; }
        public Guid TicketId { get; set; }
    }
}
