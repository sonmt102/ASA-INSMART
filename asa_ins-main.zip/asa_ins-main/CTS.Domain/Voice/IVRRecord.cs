﻿using CTS.Model;

namespace CTS.Domain.Voice
{
    public class IVRRecord : DefaultEntity
    {
        public Guid Id { get; set; }
        public string? FileName { get; set; }
        public string? RealFileName { get; set; }
        public string? Content { get; set; }
    }
}
