﻿using CTS.Common;
using CTS.Domain.Manager;

namespace CTS.Domain.Voice
{
    public class VOI_ActiveLog
    {
        public Guid Id { get; set; }
        public Guid CRM_AccountId { get; set; }
        public virtual CRM_Account CRM_Account { get; set; }
        public Guid MatchingId { get; set; }
        public DateTime StartTime { get; set; }
        public string? Extension { get; set; }
        public string? StatusCode { get; set; }
        public double TotalTime { get; set; }
        public bool HadPause { get; set; }
        public bool HadUnPause { get; set; }
        public TicketFromModule Module { get; set; }
    }
}
