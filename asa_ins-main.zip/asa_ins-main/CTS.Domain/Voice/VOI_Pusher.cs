﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.Voice
{
    public class VOI_Pusher
    {
        public Guid Id { get; set; }
        public string AppId { get; set; }
        public string AppKey { get; set; }
        public string AppSecret { get; set; }
        public string AppCluster { get; set; }
        public string AppChannel { get; set; }
        public string AppEvent { get; set; }
        public bool IsDeleted { get; set; }
    }
}
