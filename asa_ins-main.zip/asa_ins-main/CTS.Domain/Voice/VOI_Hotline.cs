﻿namespace CTS.Domain.Voice
{
    public class VOI_Hotline
    {
        public int Id { get; set; }
        public string Hotline { get; set; }
        public string Queue { get; set; }
    }
}
