﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Voice
{
    public class CalendarIVR
    {
        [Key]
        public Guid Id { get; set; }
        public Guid? CalendarId { get; set; }
        public Guid? IVRId { get; set; }
        public Guid ExtensionId { get; set; }
        public int? Priority { get; set; }
        public virtual Calendar Calendar { get; set; }
        public virtual IVR IVR { get; set; }
        public virtual VOI_Extension Extension { get; set; }
    }
}
