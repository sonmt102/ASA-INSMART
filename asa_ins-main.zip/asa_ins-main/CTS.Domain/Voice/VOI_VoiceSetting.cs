﻿namespace CTS.Domain.Voice
{
    public class VOI_VoiceSetting
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        public string? Description { get; set; }
        public int? IntValue { get; set; }
        public string? StringValue { get; set; }
        public string? JobId { get; set; }
        public string Type { get; set; }
    }
}
