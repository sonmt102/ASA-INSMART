﻿using CTS.Model;

namespace CTS.Domain.Voice
{
    public class AgentCallCalendar : DefaultEntity
    {
        public string Id { get; set; }
        public DateTime Date { get; set; }
        public string? Note { get; set; }
        public string? JobId { get; set; }

        #region Thông tin cuộc gọi
        public string? CusPhone { get; set; }
        public bool IsAnswer { get; set; }
        public bool IsNotAnswer { get; set; }
        public bool IsTransfer { get; set; }
        public bool IsStopInIVR { get; set; }
        public bool IsStopInACD { get; set; }
        public bool IsMissCall { get; set; }
        public bool IsCallAbandon { get; set; }
        public DateTime? CallStartTime { get; set; }
        public string? CallDirection { get; set; }

        #endregion
    }

}
