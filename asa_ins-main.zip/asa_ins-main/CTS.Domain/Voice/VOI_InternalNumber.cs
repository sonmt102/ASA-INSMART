﻿using CTS.Model;

namespace CTS.Domain.Voice
{
    /// <summary>
    /// Số nội bộ
    /// </summary>
    public class VOI_InternalNumber : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Password { get; set; }
        public string UserName { get; set; }
        public bool UseIPPhone { get; set; }
        public bool UseSoftPhone { get; set; }
        public bool UseWebPhone { get; set; }
    }
}
