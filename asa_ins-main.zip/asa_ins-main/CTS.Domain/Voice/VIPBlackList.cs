﻿using System.ComponentModel.DataAnnotations;
using CTS.Common;
using CTS.Model;

namespace CTS.Domain.Voice
{
    public class VOI_VIPBlackList : DefaultEntity
    {
        [Key]
        public Guid Id { get; set; }
        public string? Phone { get; set; }
        public string? Note { get; set; }
        public bool IsVIP { get; set; }
        public bool IsForever { get; set; }
        public string? JobId { get; set; }
        public DateType Type { get; set; }
        public int? DateNum { get; set; }
        public DateTime? EndDate { get; set; }
        public Guid? ContactId { get; set; }
    }
}
