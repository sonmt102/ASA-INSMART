﻿using CTS.Domain.Manager;

namespace CTS.Domain.Voice
{
    public class VOI_QueueAccount
    {
        public Guid VOI_QueueId { get; set; }
        public virtual VOI_Queue VOI_Queue { get; set; }
        public Guid CRM_AccountId { get; set; }
        public virtual CRM_Account CRM_Account { get; set; }
        public int? Priority { get; set; }
    }
}
