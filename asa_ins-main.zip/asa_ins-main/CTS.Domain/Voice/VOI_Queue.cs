﻿using CTS.Common;
using CTS.Model;

namespace CTS.Domain.Voice
{
    public class VOI_Queue : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string Hotline { get; set; }
        public string Strategy { get; set; }
        public CallDirection Direction { get; set; }
        public virtual ICollection<VOI_QueueAccount> QueueAccounts { get; set; }
        public virtual ICollection<VOI_QueueExtension> QueueExtensions { get; set; }
    }
}
