﻿namespace CTS.Domain.Voice
{
    public class VOI_ActiveLogDetail
    {
        public Guid Id { get; set; }
        public Guid CRM_AccountId { get; set; }
        public Guid MatchingId { get; set; }
        public DateTime StartTime { get; set; }
        public string? Extension { get; set; }
        public string? StatusCode { get; set; }
        public string Queues { get; set; }
        public bool HadPause { get; set; }
        public bool HadUnPause { get; set; }
        public bool IsPrimary { get; set; }
    }
}
