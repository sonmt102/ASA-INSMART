﻿using System.ComponentModel.DataAnnotations;
using CTS.Common;
using CTS.Model;

namespace CTS.Domain.Voice
{
    /// <summary>
    /// Đầu số của công ty, ví dụ: 19001900
    /// </summary>
    public class VOI_Extension : DefaultEntity
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        /// <summary>
        /// Đầu số
        /// </summary>
        public string? Exten { get; set; }
        public string? IP { get; set; }
        public int? Port { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public CallDirection Direction { get; set; }
        //public virtual ICollection<CalendarIVR> CalendarIVRs { get; set; }
        public virtual ICollection<VOI_QueueExtension> VOI_QueueExtensions { get; set; }
    }
}
