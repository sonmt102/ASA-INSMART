﻿namespace CTS.Domain.Voice
{
    /// <summary>
    /// Agent nào chỉ xem được miss call ở agent đấy, không căn cứ theo số nội bộ
    /// nhưng vẫn hiển thị ra số nội bộ
    /// TH: nhỡ của agent mà có đăng nhập thì join để lấy agent, nếu không thì chỉ thông báo cho SUP
    /// </summary>
    public class AgentMissCall
    {
        public Guid Id { get; set; }
        public string UniqueId { get; set; }
        public string Agent { get; set; }
        public string InternalNumber { get; set; }
        /// <summary>
        /// Đầu số KH gọi vào
        /// </summary>
        public string Extension { get; set; }
        public DateTime CallTile { get; set; }
    }
}
