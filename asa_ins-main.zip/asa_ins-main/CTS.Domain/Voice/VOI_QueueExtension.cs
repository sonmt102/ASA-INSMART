﻿namespace CTS.Domain.Voice
{
    public class VOI_QueueExtension
    {
        public Guid VOI_QueueId { get; set; }
        public virtual VOI_Queue Queue { get; set; }
        public Guid VOI_ExtensionId { get; set; }
        public virtual VOI_Extension Extension { get; set; }

    }
}
