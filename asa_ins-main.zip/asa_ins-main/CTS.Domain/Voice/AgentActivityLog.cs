﻿namespace CTS.Domain.Voice
{
    public class AgentActivityLog
    {
        public Guid Id { get; set; }
        public Guid AgentId { get; set; }
        public string? AgentName { get; set; }
        public string? QueueName { get; set; }
        public string? StatusCode { get; set; }
        public string? StatusName { get; set; }
        public string? ModifyBy { get; set; }
        public string? DateStr { get; set; }
        public DateTime DateStart { get; set; } = DateTime.Now;
        public DateTime? DateEnd { get; set; }
        public int TotalDuration { get; set; } = 0;
    }
}
