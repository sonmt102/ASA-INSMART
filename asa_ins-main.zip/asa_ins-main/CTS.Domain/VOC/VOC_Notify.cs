﻿using CTS.Common;
using CTS.Model;

namespace CTS.Domain.VOC
{
    public class VOC_Notify : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid VOC_TicketId { get; set; }
        public Guid CRM_AccountId { get; set; }
        public string Content { get; set; }
        public string TicketCode { get; set; }
        public DateTime Date { get; set; }
        public NotifyModule Module { get; set; }
        public virtual VOC_Ticket? VOC_Ticket { get; set; }
    }
}
