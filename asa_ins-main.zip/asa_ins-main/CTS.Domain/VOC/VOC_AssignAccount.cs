﻿using CTS.Domain.Manager;
using CTS.Model;

namespace CTS.Domain.VOC
{
    public class VOC_AssignAccount : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid CRM_AccountId { get; set; }
        public virtual CRM_Account Account { get; set; }
        public int Counter { get; set; }
    }
}
