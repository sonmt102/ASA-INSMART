﻿using CTS.Common;
using CTS.Model;

namespace CTS.Domain.VOC
{
    /// <summary>
    /// Loại cuộc gọi
    /// </summary>
    public class VOC_RequestType : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Index { get; set; }
        public string Code { get; set; }
        public int Time { get; set; }
        public VOCDeadlineTimeType TimeType { get; set; }
        public virtual ICollection<VOC_Action> VOCActions { get; set; }
    }
}
