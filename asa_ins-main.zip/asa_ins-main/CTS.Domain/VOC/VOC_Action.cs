﻿using CTS.Common;
using CTS.Domain.Manager;
using CTS.Model;

namespace CTS.Domain.VOC
{
    public class VOC_Action : DefaultEntity
    {
        public Guid Id { get; set; }
        public VOCActionType Type { get; set; }
        public Guid VOC_RequestTypeId { get; set; }
        public virtual VOC_RequestType VOCRequestType { get; set; }
        public Guid? CRM_AccountId { get; set; }
        public virtual CRM_Account Account { get; set; }
    }
}
