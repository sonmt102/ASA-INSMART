﻿namespace CTS.Domain.VOC
{
    public class VOC_OPChangeOP
    {
        public Guid Id { get; set; }
        public Guid VOC_TransferOPId { get; set; }
        public virtual VOC_TransferOP VOC_TransferOP { get; set; }
        public string BoPhanThuLy { get; set; }
        public string? TenBoPhanThuLy { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
