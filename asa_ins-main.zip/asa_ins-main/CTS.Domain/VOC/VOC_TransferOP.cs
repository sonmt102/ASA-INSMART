﻿using CTS.Common;
using CTS.Model;

namespace CTS.Domain.VOC
{
    public class VOC_TransferOP : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid VOC_TicketId { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public DateTime TransDate { get; set; }
        public int OrderStatus { get; set; }
        public bool Urgent { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public string? PhuongAnGiaiQuyet { get; set; }
        public string? CSComment { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public OPHandler_Status Status { get; set; }
        public DateTime? OPHandlerDate { get; set; }
        public string? CSTATTotal { get; set; }
        public string? OPTATTotal { get; set; }
        public string? NguoiXuLy { get; set; }
        /// <summary>
        /// Đánh dấu đã cho Update cho CS biết, khi CS xem sự vụ thì lại set lại
        /// </summary>
        public bool IsHadUpdate { get; set; }

        public virtual VOC_Ticket VOC_Ticket { get; set; }
        public virtual ICollection<VOC_TransferOP_Content> VOC_TransferOP_Contents { get; set; }
        public virtual ICollection<VOC_OPHandler_CTBHContent> VOC_OPHandler_CTBHContents { get; set; }
        public virtual ICollection<VOC_OPHandler_OPContent> VOC_OPHandler_OPContents { get; set; }
        public virtual ICollection<VOC_OPHandler_Attach> VOC_OPHandler_Attachs { get; set; }
        public virtual ICollection<VOC_OPChangeOP> VOC_OPChangeOPs { get; set; }
        public virtual ICollection<VOC_TransferOP_Reply> VOC_TransferOP_Replys { get; set; }
    }

    public class VOC_TransferOP_Content : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid VOC_TransferOPId { get; set; }
        public string Content { get; set; }
        public DateTime Date { get; set; }
        public virtual VOC_TransferOP VOC_TransferOP { get; set; }
    }


    public class VOC_OPHandler_CTBHContent : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid VOC_TransferOPId { get; set; }
        public string Content { get; set; }
        public DateTime Date { get; set; }
        public virtual VOC_TransferOP VOC_TransferOP { get; set; }
    }

    public class VOC_OPHandler_OPContent : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid VOC_TransferOPId { get; set; }
        public string Content { get; set; }
        public DateTime Date { get; set; }
        public virtual VOC_TransferOP VOC_TransferOP { get; set; }
    }

    public class VOC_OPHandler_Attach : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid VOC_TransferOPId { get; set; }
        public string? Name { get; set; }
        public string? RealName { get; set; }
        public string? Type { get; set; }
        public string? ExtensionFile { get; set; }
        public string? Size { get; set; }
        public virtual VOC_TransferOP VOC_TransferOP { get; set; }
    }

}
