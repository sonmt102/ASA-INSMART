﻿using CTS.Common;
using CTS.Model;

namespace CTS.Domain.VOC
{
    public class VOC_TicketLogStatus : DefaultEntity
    {
        public Guid Id { get; set; }
        public VOCTicketStatus Status { get; set; }
        public DateTime Date { get; set; }
        public Guid VOC_TicketId { get; set; }
        public virtual VOC_Ticket Ticket { get; set; }
    }
}
