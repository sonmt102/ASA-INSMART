﻿using CTS.Common;

namespace CTS.Domain.VOC
{
    public class VOC_Export_TicketDetail
    {
        public Guid Id { get; set; }
        public string? Code { get; set; }
        public string? KenhTiepNhan { get; set; }
        public string? Phone { get; set; }
        public DateTime? ThoiGianTiepNhanEmail { get; set; }
        public string? CustomerName { get; set; }
        public string? CustomerType { get; set; }
        public string? CustomerEmail { get; set; }
        public DateTime? NextReminderDate { get; set; }
        public string? CongTy { get; set; }
        public string? MoiGioi { get; set; }
        public string? LoaiSuVu { get; set; }
        public string? LoaiYeuCau { get; set; }
        public string? YeuCau { get; set; }
        public string? LoaiKhieuNai { get; set; }
        public string? SoHD { get; set; }
        public string? SoHS { get; set; }
        public string? ClaimId { get; set; }
        public string? LoaiHoSo { get; set; }
        public string? NguoiDuocBH { get; set; }
        public string? BenMuaBH { get; set; }
        public string? NoiDungSV { get; set; }
        public bool Urgent { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string? UpdatedByStr { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? CompleteDate { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public bool IsComplete { get; set; }
        public string? CSContent { get; set; }
        public string? NguoiXuLy { get; set; }
        public Guid? NguoiXuLyId { get; set; }
        public int SoLanChuyenOP { get; set; }
        public string? TongThoiGianCSPhanHoiKH { get; set; }
        public string? NguyenNhanDTKN { get; set; }
        public string? ChiTietNguyenNhanKN { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsFollow { get; set; }
        public string? LanChuyen1 { get; set; }
        public string? LanChuyen2 { get; set; }
        public string? LanChuyen3 { get; set; }
        public string? LanChuyen4 { get; set; }
        public string? LanChuyen5 { get; set; }
        public string? LanChuyen6 { get; set; }
        public string? LanChuyen7 { get; set; }
        public string? LanChuyen8 { get; set; }
        public string? LanChuyen9 { get; set; }
        public string? LanChuyen10 { get; set; }
        public string? LanChuyen11 { get; set; }
        public string? LanChuyen12 { get; set; }
        public string? LanChuyen13 { get; set; }
        public string? LanChuyen14 { get; set; }
        public string? LanChuyen15 { get; set; }
        public string? LanChuyen16 { get; set; }
        public string? LanChuyen17 { get; set; }
        public string? LanChuyen18 { get; set; }
        public string? LanChuyen19 { get; set; }
        public string? LanChuyen20 { get; set; }

        public virtual ICollection<VOC_Export_TicketDetail_Transfer> VOC_Export_TicketDetail_Transfers { get; set; }
    }

    public class VOC_Export_TicketDetail_Transfer
    {
        public Guid Id { get; set; }
        public string? BoPhanTL { get; set; }
        public int OrderStatus { get; set; }
        public OPHandler_Status Status { get; set; }
        public bool Urgent { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public DateTime TransDate { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public string? OPContent { get; set; }
        public string? NguoiXuLy { get; set; }
        public Guid? TransferOPId { get; set; }
        public DateTime? OPHandlerDate { get; set; }
        public Guid VOC_Export_TicketDetailId { get; set; }
        public virtual VOC_Export_TicketDetail VOC_Export_TicketDetail { get; set; }
        public virtual ICollection<VOC_Export_TicketDetail_Transfer_Handler> VOC_Export_TicketDetail_Transfer_Handlers { get; set; }
    }

    public class VOC_Export_TicketDetail_Transfer_Handler
    {
        public Guid Id { get; set; }
        public Guid VOC_Export_TicketDetail_TransferId { get; set; }
        public virtual VOC_Export_TicketDetail_Transfer VOC_Export_TicketDetail_Transfer { get; set; }
        public string Handler { get; set; }
    }
}
