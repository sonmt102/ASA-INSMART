﻿namespace CTS.Domain.VOC
{
    public class VOC_OP_ExportByDay
    {
        public Guid Id { get; set; }
        public string NameFile { get; set; }
        public string UrlFile { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentCode { get; set; }
        public string TotalData { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool IsDeleted { get; set; }
    }
}
