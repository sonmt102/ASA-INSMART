﻿using CTS.Common;
using CTS.Domain.Mail;
using CTS.Domain.Manager;
using CTS.Model;

namespace CTS.Domain.VOC
{
    public class VOC_Ticket : DefaultEntity
    {
        public Guid Id { get; set; }
        public string? KenhTiepNhan { get; set; }
        public string? CongTyMoiGioi { get; set; }
        public string MaSV { get; set; }
        public string? CustomerPhone { get; set; }
        public string? CustomerName { get; set; }
        public string? DoiTuongGoiDen { get; set; }
        public string? Email { get; set; }
        public string? Hotline { get; set; }
        public string? BotScenarioId { get; set; }

        #region 1. TTSV

        public string? TTSV_CongTy { get; set; }
        public string? TTSV_LoaiSV { get; set; }
        public string? TTSV_LoaiYeuCau { get; set; }
        public string? TTSV_YeuCau { get; set; }
        public string? TTHS_NguoiDuocBH { get; set; }
        public DateTime? TTHS_DBO { get; set; }
        public string? TTHS_CMND { get; set; }
        public string? TTHS_BenMuaBH { get; set; }
        public string? TTHS_SoHD { get; set; }
        public string? TTHS_SoHS { get; set; }
        public string? ClaimID { get; set; }
        public string? TTHS_LoaiHS { get; set; }
        public string? TTHS_LoaiKL { get; set; }
        public DateTime? TTHS_NgayGioTNEmail { get; set; }
        public DateTime? NextReminderDate { get; set; }
        public bool Urgent { get; set; }
        public bool IsFollow { get; set; }

        public string? CTSV_NoiDungSV { get; set; }
        public string? CTSV_BoPhanTL { get; set; }
        public string? CTSV_DonViTN { get; set; }



        #endregion

        #region 2. QTXL
        public bool? IsCheckCTBH { get; set; }
        public bool? IsCheckCSYT { get; set; }
        public string? QTXL_NoiDungCustomerService { get; set; }
        public string? QTXL_NoiDungDonViTL { get; set; }
        public string? QTXL_NoiDungCTBH { get; set; }
        public string? QTXL_PhuongAnGQ { get; set; }
        public string? QTXL_PhoiHopGQKN { get; set; }
        public string? QTXL_OPPhanHoiPA { get; set; }
        public DateTime? QTXL_ThoiGianPHKH { get; set; }
        public string? QTXL_CSPhanHoiTTKH { get; set; }
        public DateTime? QTXL_ThoiGianCTL { get; set; }
        public DateTime? QTXL_ThoiGianTLPH { get; set; }
        public string? QTXL_NguyenNhanDTKN { get; set; }
        public string? ChiTietNguyenNhanKN { get; set; }

        #endregion

        public Guid? MAIL_INBOXId { get; set; }
        public virtual MAIL_INBOX? MAIL_INBOX { get; set; }
        public string? FromEmail { get; set; }
        public string? Tos { get; set; }
        public string? CCs { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string? CallStatus { get; set; }
        public Guid? CRM_AccountId { get; set; }
        public virtual CRM_Account? CRM_Account { get; set; }
        public DateTime? HandlerDate { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public DateTime? CompleteDate { get; set; }
        public string? ZaloId { get; set; }
        /// <summary>
        /// Tổng thời gian CS phản hồi khách hàng
        /// </summary>
        public string? CSTATTotal { get; set; }
        public virtual ICollection<VOC_TicketHistory> VOC_TicketHistories { get; set; }
        public virtual ICollection<VOC_TicketLogStatus> TicketLogStatus { get; set; }
        public virtual ICollection<VOC_CallData> VOC_CallDatas { get; set; }
        public virtual ICollection<VOC_TransferOP> VOC_TransferOPs { get; set; }
        public virtual ICollection<VOC_CSAttach>? VOC_CSAttachs { get; set; }
        public virtual ICollection<VOC_TicketContent> VOC_TicketContents { get; set; }
        public virtual ICollection<VOC_Ticket_CSHandlerContent> VOC_Ticket_CSHandlerContents { get; set; }
        public virtual ICollection<VOC_Ticket_Reply> VOC_Ticket_Replies { get; set; }

        public string? Conversation { get; set; }
    }
    public class VOC_CSAttach : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid? VOC_TicketId { get; set; }
        public string? Name { get; set; }
        public string? RealName { get; set; }
        public string? Type { get; set; }
        public string? ExtensionFile { get; set; }
        public string? Size { get; set; }
        public virtual VOC_Ticket? VOC_Ticket { get; set; }
    }

}
