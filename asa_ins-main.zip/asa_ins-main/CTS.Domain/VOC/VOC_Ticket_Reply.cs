﻿using CTS.Common;
using CTS.Model;

namespace CTS.Domain.VOC
{
    public class VOC_Ticket_Reply : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid VOC_TicketId { get; set; }
        public TransferOP_ReplyType ReplyType { get; set; }
        public string To { get; set; }
        public string? Cc { get; set; }
        public string? Bcc { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        public bool IsSeen { get; set; }
        public string? QueueCode { get; set; }
        public int? MAIL_SignId { get; set; }
        public virtual VOC_Ticket VOC_Ticket { get; set; }
        public virtual ICollection<VOC_Ticket_Reply_Attach> VOC_Ticket_Reply_Attachs { get; set; }
    }

    public class VOC_Ticket_Reply_Attach : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid? VOC_Ticket_ReplyId { get; set; }
        public string? Name { get; set; }
        public string? RealName { get; set; }
        public string? Type { get; set; }
        public string? ExtensionFile { get; set; }
        public string? Size { get; set; }
        public virtual VOC_Ticket_Reply? VOC_Ticket_Reply { get; set; }
    }
}
