﻿namespace CTS.Domain.VOC
{
    public class VOC_CallData
    {
        public Guid Id { get; set; }
        public Guid? CallId { get; set; }
        public Guid VOC_TicketId { get; set; }
        public virtual VOC_Ticket VOC_Ticket { get; set; }
    }
}
