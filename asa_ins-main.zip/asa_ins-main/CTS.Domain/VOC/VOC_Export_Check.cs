﻿using CTS.Common;

namespace CTS.Domain.VOC
{
    public class VOC_Export_Check
    {
        public Guid Id { get; set; }
        public UpdateTicketType Type { get; set; }
        public bool IsHandler { get; set; }
    }


}
