﻿using CTS.Common;

namespace CTS.Domain.VOC.Export
{
    public class EXPORT_TicketDetail
    {
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string KenhTiepNhan { get; set; }
        public string Phone { get; set; }
        public string CustomerName { get; set; }
        public string CustomerType { get; set; }
        public string CustomerEmail { get; set; }
        public string CongTy { get; set; }
        public string MoiGioi { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiYeuCau { get; set; }
        public string YeuCau { get; set; }
        public string SoHD { get; set; }
        public string SoHS { get; set; }
        public string ClaimId { get; set; }
        public string LoaiHoSo { get; set; }
        public string NguoiDuocBH { get; set; }
        public string BenMuaBH { get; set; }
        public string NoiDungSV { get; set; }
        public bool Urgent { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string UpdatedByStr { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? CompleteDate { get; set; }
        public bool IsComplete { get; set; }
        public string CSContent { get; set; }
        public string NguoiXuLy { get; set; }

        public int SoLanChuyenOP { get; set; }
        public string TAT { get; set; }
        public virtual ICollection<EXPORT_TicketDetail_Transfer> EXPORT_TicketDetail_Transfers { get; set; }
    }

    public class EXPORT_TicketDetail_Transfer
    {
        public int Id { get; set; }
        public Guid EXPORT_TicketDetailId { get; set; }
        public virtual EXPORT_TicketDetail EXPORT_TicketDetail { get; set; }
        public string BoPhanThuLy { get; set; }
        public DateTime TransDate { get; set; }
        public string OPContent { get; set; }
        public string TongThoiGianOPPhanHoi { get; set; }
        public string PhuongAnGiaiQuyet { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckHDCM { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public OPHandler_Status Status { get; set; }
        public DateTime? OPHandlerDate { get; set; }
        public string TATStr { get; set; }
    }
}
