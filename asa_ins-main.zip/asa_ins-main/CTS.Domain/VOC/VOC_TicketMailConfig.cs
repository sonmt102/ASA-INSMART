﻿namespace CTS.Domain.VOC
{
    public class VOC_TicketMailConfig
    {
        public Guid Id { get; set; }
        public string TypeCode { get; set; }
        public string? Data { get; set; }
    }
}
