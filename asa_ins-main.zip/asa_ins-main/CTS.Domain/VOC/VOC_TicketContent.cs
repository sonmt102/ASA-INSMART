﻿namespace CTS.Domain.VOC
{
    public class VOC_TicketContent
    {
        public Guid Id { get; set; }
        public Guid VOC_TicketId { get; set; }
        public string Content { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public virtual VOC_Ticket VOC_Ticket { get; set; }
    }
}
