﻿namespace CTS.Domain.Mail
{
    public class MAIL_INBOX_Tag
    {
        public Guid MAIL_INBOXId { get; set; }
        public virtual MAIL_INBOX MAIL_INBOX { get; set; }
        public int MAIL_TagListId { get; set; }
        public virtual MAIL_TagList MAIL_TagList { get; set; }
    }
}
