﻿using CTS.Model;

namespace CTS.Domain.Mail
{
    public class MAIL_Answer : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid? MAIL_INBOXId { get; set; }
        public virtual MAIL_INBOX? MAIL_INBOX { get; set; }
        public string Tos { get; set; }
        public string? BCCs { get; set; }
        public string? CCs { get; set; }
        public string? Subject { get; set; }
        public string? Content { get; set; }
        public string QueueMail { get; set; }
        public bool IsSuccess { get; set; }
        public bool IsSeen { get; set; }
        public string? SentError { get; set; }
        public int MAIL_SignId { get; set; }
        public virtual MAIL_Sign MAIL_Sign { get; set; }
        public virtual ICollection<MAIL_Answer_Attach> MAIL_Answer_Attaches { get; set; }
    }


    public class MAIL_Answer_Attach
    {
        public Guid Id { get; set; }
        public Guid MAIL_AnswerId { get; set; }
        public string? Name { get; set; }
        public string? RealName { get; set; }
        public string? Type { get; set; }
        public string? ExtensionFile { get; set; }
        public string? Size { get; set; }
        public virtual MAIL_Answer MAIL_Answer { get; set; }
        public bool IsDeleted { get; set; }
    }

}
