﻿namespace CTS.Domain.Mail
{
    public class MAIL_AssignLog
    {
        public Guid Id { get; set; }
        public string AssignTo { get; set; }
        public string AssignBy { get; set; }
        public DateTime AssignDate { get; set; }
        public string? Note { get; set; }
        public Guid MAIL_INBOXId { get; set; }
        public virtual MAIL_INBOX MAIL_INBOX { get; set; }
    }
}
