﻿using CTS.Domain.VOC;

namespace CTS.Domain.Mail
{
    public class MAIL_INBOX
    {
        public Guid Id { get; set; }
        public int Index { get; set; }
        public string? Queue { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        public string? Channel { get; set; }
        public string? From { get; set; }
        public string? FromEmail { get; set; }
        public string? Flag { get; set; }
        public bool IsReply { get; set; }
        public string? MessageId { get; set; }
        public string? InReplyTo { get; set; }
        public int UniqueId { get; set; }
        public DateTime Date { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? CongTy { get; set; }
        public bool IsCheckSubject { get; set; }
        public bool IsAssign { get; set; }
        public bool IsSeen { get; set; }
        public bool AgentMarkReply { get; set; }
        public string? AssignTo { get; set; }
        public DateTime? AssignDate { get; set; }
        public bool IsHandler { get; set; }
        public bool IsImportant { get; set; }
        public DateTime? HandlerDate { get; set; }
        public Guid? VOC_TicketId { get; set; }
        public string? CRM_Note { get; set; }
        public string? FolderMail { get; set; }
        public virtual ICollection<MAIL_INBOX_To> MAIL_INBOX_Tos { get; set; }
        public virtual ICollection<MAIL_INBOX_CC> MAIL_INBOX_CCs { get; set; }
        public virtual ICollection<MAIL_INBOX_BCC> MAIL_INBOX_BCCs { get; set; }
        public virtual ICollection<MAIL_INBOX_Attach> MAIL_INBOX_Attachs { get; set; }
        public virtual ICollection<MAIL_INBOX_Tag> MAIL_INBOX_Tags { get; set; }
        public virtual ICollection<VOC_Ticket> VOC_Tickets { get; set; }
        public virtual ICollection<MAIL_Answer> MAIL_Answers { get; set; }
        public virtual ICollection<MAIL_AssignLog> MAIL_AssignLogs { get; set; }

        //public virtual ICollection<MAIL_INBOX> Childrens { get; set; }
        //public virtual MAIL_INBOX Parent { get; set; }

    }

    public class MAIL_INBOX_Attach
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Queue { get; set; }
        public int UniqueId { get; set; }
        public Guid MAIL_INBOXId { get; set; }
        public virtual MAIL_INBOX MAIL_INBOX { get; set; }
    }
    public class MAIL_INBOX_To
    {
        public Guid Id { get; set; }
        public Guid MAIL_INBOXId { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public virtual MAIL_INBOX MAIL_INBOX { get; set; }
    }

    public class MAIL_INBOX_CC
    {
        public Guid Id { get; set; }
        public Guid MAIL_INBOXId { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public virtual MAIL_INBOX MAIL_INBOX { get; set; }
    }

    public class MAIL_INBOX_BCC
    {
        public Guid Id { get; set; }
        public Guid MAIL_INBOXId { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public virtual MAIL_INBOX MAIL_INBOX { get; set; }
    }
}
