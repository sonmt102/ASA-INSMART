﻿using CTS.Domain.Manager;
using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Mail
{
    public class MAIL_Group
       
    {
        [Key]
        public int Id { get; set; }
        public Guid MAIL_QueueId { get; set; }
        public string Name { get; set; }
        public string InboxQueueCode { get; set; }
        public string? Regex { get; set; }
        public string? Temp { get; set; }
        public int Order { get; set; }
        public virtual ICollection<MAIL_GroupAccount> MAIL_GroupAccounts { get; set; }
    }

    public class MAIL_GroupAccount
    {
        
        public int MAIL_GroupId { get; set; }
        public virtual MAIL_Group MAIL_Group { get; set; }
        public Guid CRM_AccountId { get; set; }
        public virtual CRM_Account CRM_Account { get; set; }
        public bool IsLeader { get; set; }
    }
}
