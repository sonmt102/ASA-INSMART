﻿using CTS.Common;

namespace CTS.Domain.Mail
{
    public class MAIL_Queue
    {
        public Guid Id { get; set; }
        public ServerMailType ServerMailType { get; set; }
        public MailType MailType { get; set; }
        public string Name { get; set; }
        public string? AttachSource { get; set; }
        public string? Code { get; set; }
        public string? Channel { get; set; }
        public string? MailName { get; set; }
        public string? SMTP_Host { get; set; }
        public int SMTP_Port { get; set; }
        public string? SMTP_Username { get; set; }
        public string? SMTP_Password { get; set; }
        public string? ClientID { get; set; }
        public string? ClientSecret { get; set; }
        public string? TenantID { get; set; }
        public int MailCounter { get; set; }
        public bool IsDeleted { get; set; }
        public virtual ICollection<MAIL_AccountQueue> MAIL_AccountQueues { get; set; }
    }
}
