﻿namespace CTS.Domain.Mail
{
    public class MAIL_AssignAccount
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public DateTime AssignDate { get; set; }
        public string AssignBy { get; set; }
        public int Counter { get; set; }
    }
}
