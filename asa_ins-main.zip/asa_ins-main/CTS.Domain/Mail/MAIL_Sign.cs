﻿namespace CTS.Domain.Mail
{
    public class MAIL_Sign
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Content { get; set; }
        public bool IsDeleted { get; set; }
    }
}
