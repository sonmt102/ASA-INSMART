﻿using CTS.Domain.Manager;

namespace CTS.Domain.Mail
{
    public class MAIL_AccountQueue
    {
        public Guid CRM_AccountId { get; set; }
        public virtual CRM_Account CRM_Account { get; set; }
        public Guid MAIL_QueueId { get; set; }
        public virtual MAIL_Queue MAIL_Queue { get; set; }
        public bool IsLeader { get; set; }

       
    }
}
