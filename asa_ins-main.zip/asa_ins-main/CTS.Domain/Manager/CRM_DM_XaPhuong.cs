﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Manager
{
    public class CRM_DM_XaPhuong
    {
        [Key]
        public string MA_XA { get; set; }
        public string MA_TINH { get; set; }
        public string MA_HUYEN { get; set; }
        public string TEN_XA { get; set; }
        public virtual CRM_DM_QuanHuyen DM_QuanHuyen { get; set; }
    }
}
