﻿namespace CTS.Domain.Manager
{
    public class CRM_GroupPermission
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public int OrderIndex { get; set; }
        public int Code { get; set; }
        public bool IsDeleted { get; set; }
        public virtual ICollection<CRM_Permission>? Permissions { get; set; }
    }
}
