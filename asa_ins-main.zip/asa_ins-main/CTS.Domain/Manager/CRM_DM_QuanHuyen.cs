﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Manager
{
    public class CRM_DM_QuanHuyen
    {
        public string MA_TINH { get; set; }
        [Key]
        public string MA_HUYEN { get; set; }
        public string TEN_HUYEN { get; set; }
        public virtual CRM_DM_TinhThanhPho DM_TinhThanhPho { get; set; }
        public virtual ICollection<CRM_DM_XaPhuong> DM_XaPhuongs { get; set; }
    }
}
