﻿namespace CTS.Domain.Manager
{
    public class CRM_DM_TinhThanhPho
    {
        public string MA_TINH { get; set; }
        public string TEN_TINH { get; set; }
        public virtual ICollection<CRM_DM_QuanHuyen> DM_QuanHuyens { get; set; }
    }
}
