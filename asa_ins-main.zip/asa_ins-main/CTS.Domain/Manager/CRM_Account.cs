﻿using CTS.Domain.Mail;
using CTS.Domain.QA;
using CTS.Model;

namespace CTS.Domain.Manager
{
    public class CRM_Account : DefaultEntity
    {
        public Guid Id { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public string? FullName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Email { get; set; }
        public string? Extension { get; set; }
        public string? Position { get; set; }
        public bool IsActive { get; set; }
        public DateTime? DeActiveDate { get; set; }
        public bool IsLock { get; set; }
        public virtual ICollection<CRM_AccountRole>? AccountRoles { get; set; }
        public virtual ICollection<CRM_AccountDepartment>? CRM_AccountDepartments { get; set; }
        public virtual ICollection<MAIL_AccountQueue> MAIL_AccountQueues { get; set; }
        public virtual ICollection<MAIL_GroupAccount> MAIL_GroupAccounts { get; set; }
        public virtual ICollection<QA_AssignAccount>? QA_AssignAccounts { get; set; }
    }

}
