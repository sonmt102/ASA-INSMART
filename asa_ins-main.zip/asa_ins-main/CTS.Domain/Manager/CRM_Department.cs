﻿using CTS.Model;

namespace CTS.Domain.Manager
{
    public class CRM_Department : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string? Code { get; set; }
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
        public virtual ICollection<CRM_AccountDepartment>? CRM_AccountDepartments { get; set; }
    }
}
