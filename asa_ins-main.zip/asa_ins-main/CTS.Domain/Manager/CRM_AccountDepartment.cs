﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Manager
{
    public class CRM_AccountDepartment
    {
        public Guid CRM_AccountId { get; set; }
        public virtual CRM_Account CRM_Account { get; set; }
        public Guid CRM_DepartmentId { get; set; }
        public virtual CRM_Department CRM_Department { get; set; }
    }
}
