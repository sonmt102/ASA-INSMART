﻿using CTS.Model;

namespace CTS.Domain.Manager
{
    public class CRM_Role : DefaultEntity
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public virtual ICollection<CRM_RolePermission>? RolePermission { get; set; }
        public virtual ICollection<CRM_AccountRole>? AccountRole { get; set; }
    }
}
