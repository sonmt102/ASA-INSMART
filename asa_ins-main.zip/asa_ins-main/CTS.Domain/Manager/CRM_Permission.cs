﻿namespace CTS.Domain.Manager
{
    public class CRM_Permission
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        public int OrderIndex { get; set; }
        public Guid CRM_GroupPermissionId { get; set; }
        public virtual ICollection<CRM_RolePermission>? RolePermissions { get; set; }
        public virtual CRM_GroupPermission? GroupPermission { get; set; }
    }
}
