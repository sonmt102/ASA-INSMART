﻿using System.ComponentModel.DataAnnotations;

namespace CTS.Domain.Manager
{
    public class CRM_AccountRole
    {
        public Guid CRM_AccountId { get; set; }
        public Guid CRM_RoleId { get; set; }
        public bool IsCheckAll { get; set; }
        public virtual CRM_Account? Account { get; set; }
        public virtual CRM_Role? Role { get; set; }
    }
}
