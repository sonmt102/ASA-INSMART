﻿namespace CTS.Domain.Manager
{
    public class CRM_Category
    {
        public Guid Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? StringValue { get; set; }
        public string? ICon { get; set; }
        public int OrderIndex { get; set; }
        public Guid? ParentId { get; set; }
        public bool IsDeleted { get; set; }
        public virtual CRM_Category? Parent { get; set; }
        public virtual ICollection<CRM_Category>? Childrens { get; set; }
    }
}
