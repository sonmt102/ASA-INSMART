﻿namespace CTS.Domain.Manager
{
    public class CRM_RolePermission
    {
        public Guid CRM_RoleId { get; set; }
        public Guid CRM_PermissionId { get; set; }
        public virtual CRM_Role? Role { get; set; }
        public virtual CRM_Permission? Permission { get; set; }
    }
}
