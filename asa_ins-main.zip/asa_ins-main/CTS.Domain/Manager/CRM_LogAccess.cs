﻿using CTS.Common;

namespace CTS.Domain.Manager
{
    public class CRM_LogAccess
    {
        public Guid Id { get; set; }
        public LogAccess_DataType DataType { get; set; }
        public LogAccess_Type Type { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string Content { get; set; }
    }
}
