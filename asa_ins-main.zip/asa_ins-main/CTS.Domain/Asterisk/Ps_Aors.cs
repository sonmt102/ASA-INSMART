﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CTS.Domain.Asterisk
{
    public class Ps_Aors
    {
        [Column("id")]
        public string Id { get; set; }
        [Column("max_contacts")]
        public int? Max_Contacts { get; set; } = 3;
        [Column("contact")]
        public string? Contact { get; set; }
        [Column("default_expiration")]
        public int? DefaultExpiration { get; set; } = 180;
        [Column("minimum_expiration")]
        public int? MinimumExpiration { get; set; } = 180;
        [Column("remove_existing")]
        public string? RemoveExisting { get; set; } = "yes";
        [Column("maximum_expiration")]
        public int? MaximumExpiration { get; set; } = 120;
    }
}
