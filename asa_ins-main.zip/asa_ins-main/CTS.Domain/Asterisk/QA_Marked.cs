﻿namespace CTS.Domain.Asterisk
{
    public class QA_Marked
    {
        public Guid Id { get; set; }
        public string Call_LogId { get; set; }
        public virtual CallDetail? CallDetail { get; set; }
        public bool IsMarked { get; set; }
    }
}
