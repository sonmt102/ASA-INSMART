﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CTS.Domain.Asterisk
{
    public class Ps_Endpoints
    {
        [Column("id")]
        public string Id { get; set; }
        [Column("transport")]
        public string Transport { get; set; } = "transport-udp-nat";
        [Column("aors")]
        public string Aors { get; set; }
        [Column("auth")]
        public string Auth { get; set; }
        [Column("context")]
        public string Context { get; set; } = "from-internal";
        [Column("disallow")]
        public string DisAllow { get; set; } = "all";
        [Column("allow")]
        public string Allow { get; set; } = "g722, alaw, ulaw";
        [Column("direct_media")]
        public string Direct_Media { get; set; } = "no";
        [Column("ice_support")]
        public string Ice_Support { get; set; } = "yes";
        [Column("rewrite_contact")]
        public string Rewrite_Contact { get; set; } = "yes";
        [Column("rtp_symmetric")]
        public string Rtp_Symmetric { get; set; } = "yes";
        [Column("from_user")]
        public string? FromUser { get; set; }
        [Column("callerid_tag")]
        public string? CallerId_Tag { get; set; }
        [Column("use_avpf")]
        public string? Use_Avpf { get; set; }
        [Column("media_encryption")]
        public string? Media_Encryption { get; set; }
        [Column("dtls_cert_file")]
        public string? Dtls_Cert_File { get; set; }
        [Column("dtls_private_key")]
        public string? Dtls_Private_Key { get; set; }
        [Column("dtls_setup")]
        public string? Dtls_Setup { get; set; }
        [Column("webrtc")]
        public string? Webrtc { get; set; }
        [Column("dtls_auto_generate_cert")]
        public string? Dtls_Auto_Generate_Cert { get; set; }

    }
}
