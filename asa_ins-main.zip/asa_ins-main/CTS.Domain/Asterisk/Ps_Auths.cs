﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CTS.Domain.Asterisk
{
    public class Ps_Auths
    {
        [Column("id")]
        public string Id { get; set; }
        [Column("auth_type")]
        public string Auth_Type { get; set; } = "userpass";
        [Column("password")]
        public string Password { get; set; }
        [Column("username")]
        public string UserName { get; set; }
    }
}
