﻿namespace CTS.Domain.Asterisk
{
    public class CallLogDetail
    {
        public Guid Id { get; set; }
        public string CallId { get; set; }
        public DateTime Time { get; set; }
        public string? StatusCode { get; set; }
        public string? StatusName { get; set; }
        public string? VoiceCode { get; set; }
        public string? Agent { get; set; }
        public string? Queue { get; set; }
        public virtual CallDetail CallDetail { get; set; }
    }
}
