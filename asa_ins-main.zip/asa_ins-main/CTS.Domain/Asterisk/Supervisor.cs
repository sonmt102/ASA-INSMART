﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.Asterisk
{
    public class Supervisor
    {
        public string? AgentStatusCall { get; set; }
        public string? CallTime { get; set; }
        public int Duration { get; set; } = 0;
        public string? Channel { get; set; }
        public string? Uniqueid { get; set; }
        public string? Linkedid { get; set; }
        public string? MICDIRECTION { get; set; }
        public string? CusPhone { get; set; }
        public string? Extension { get; set; }
        public string? MICEXTEN { get; set; }
        public string? MICAGENTACCOUNT { get; set; }
        public string? InCallQueue { get; set; }
        public string? InWaitingQueue { get; set; }
        public string? QueueInCall { get; set; }
        public string? MICUNIQUEID { get; set; }
        public string? MICLINKEDID { get; set; }
        public string? QueueName { get; set; }
        public string? CallId { get; set; }
    }
}
