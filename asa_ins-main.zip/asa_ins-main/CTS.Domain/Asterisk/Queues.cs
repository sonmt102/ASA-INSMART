﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CTS.Domain.Asterisk
{
    public class Queues
    {
        [Column("name")]
        public string Id { get; set; }
        [Column("timeout")]
        public int TimeOut { get; set; } = 15;
        [Column("ringinuse")]
        public string RingInUse { get; set; } = "no";
        [Column("setinterfacevar")]
        public string SetInterfaceVar { get; set; } = "no";
        [Column("setqueuevar")]
        public string SetQueueVar { get; set; } = "no";
        [Column("setqueueentryvar")]
        public string SetQueueEntryVar { get; set; } = "no";
        [Column("monitor_format")]
        public string Monitor_Format { get; set; } = "wav49";
        [Column("retry")]
        public int Retry { get; set; } = 5;
        [Column("wrapuptime")]
        public int WrapupTime { get; set; } = 0;
        [Column("autofill")]
        public string AutoFill { get; set; } = "yes";
        [Column("monitor_type")]
        public string Monitor_Type { get; set; } = "MixMonitor";
        [Column("autopause")]
        public string AutoPause { get; set; } = "no";
        [Column("autopausedelay")]
        public int AutoPauseDelay { get; set; } = 60;
        [Column("autopausebusy")]
        public string AutoPauseBusy { get; set; } = "no";
        [Column("autopauseunavail")]
        public string AutoPauseUnavail { get; set; } = "no";
        [Column("maxlen")]
        public int Maxlen { get; set; } = 0;
        [Column("servicelevel")]
        public int ServiceLevel { get; set; } = 60;
        [Column("strategy")]
        public string Strategy { get; set; } = "rrmemory";
        [Column("memberdelay")]
        public int MemberDelay { get; set; } = 0;
        [Column("weight")]
        public int Weight { get; set; } = 0;
        [Column("timeoutrestart")]
        public string TimeoutRestart { get; set; } = "no";
    }
}
