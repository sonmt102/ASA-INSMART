﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CTS.Domain.Asterisk
{
    public class QueueMembers
    {
        [Column("uniqueid")]
        public int Uniqueid { get; set; }
        [Column("queue_name")]
        public string QueueName { get; set; }
        [Column("interface")]
        public string Interface { get; set; }
        [Column("membername")]
        public string? MemberName { get; set; }
        [Column("state_interface")]
        public string? StateInterface { get; set; }
        [Column("penalty")]
        public int? Penalty { get; set; }
        [Column("paused")]
        public int? Paused { get; set; }
        [Column("wrapuptime")]
        public int? WrapupTime { get; set; }
    }
}
