﻿namespace CTS.Domain.Zalo
{
    public class Z_Follower
    {
        public Guid Id { get; set; }
        public string User_id { get; set; }
        public string? User_id_by_app { get; set; }
        public string? User_gender { get; set; }
        public string? Avatar { get; set; }
        public string? Avatar120 { get; set; }
        public string? Avatar240 { get; set; }
        public string? Display_name { get; set; }
        public virtual ICollection<Z_Follower_Tag> Z_Follower_Tags { get; set; }
        public virtual ICollection<Z_Follower_Note> Z_Follower_Notes { get; set; }

    }

    public class Z_Follower_Tag
    {
        public Guid Id { get; set; }
        public Guid Z_FollowerId { get; set; }
        public virtual Z_Follower Z_Follower { get; set; }
        public string? Tag { get; set; }
    }

    public class Z_Follower_Note
    {
        public Guid Id { get; set; }
        public Guid Z_FollowerId { get; set; }
        public virtual Z_Follower Z_Follower { get; set; }
        public string? Note { get; set; }
    }
}
