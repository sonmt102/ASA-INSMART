﻿namespace CTS.Domain.Zalo
{
    public class Z_Ctrl_ZNS_Vote
    {
        public Guid Id { get; set; }
        public string? CustomerPhone { get; set; }
        public string? UserZaloId { get; set; }
        public string? Date { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid? TrackingId { get; set; }
        public Guid? BAId { get; set; }
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public string? Msg_id { get; set; }
        public string? Sent_time { get; set; }
        public string? DailyQuota { get; set; }
        public string? RemainingQuota { get; set; }
    }
}
