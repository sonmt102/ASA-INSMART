﻿namespace CTS.Domain.Zalo
{
    public class Z_TagUser
    {
        public string UserId { get; set; }
        public string Tag { get; set; }
    }
}
