﻿namespace CTS.Domain.Zalo.ForControl
{
    public class Z_Ctrl_Consent
    {
        public Guid Id { get; set; }
        public string Phonenumber { get; set; }
        public string CreateBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid? T_ContactId { get; set; }
        public string? Result { get; set; }
        /// <summary>
        /// Người dùng đã gửi đi zalo
        /// Khách hàng đã nhận được thông tin
        /// Yêu cầu đã hết hạn
        /// </summary>
        public string? Status { get; set; }
    }
}
