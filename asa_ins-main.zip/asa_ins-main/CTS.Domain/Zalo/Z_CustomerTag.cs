﻿using CTS.Model;

namespace CTS.Domain.Zalo
{
    public class Z_CustomerTag : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Z_CustomerId { get; set; }
        public string Tag { get; set; }
        public virtual Z_Customer Z_Customer { get; set; }
    }
}
