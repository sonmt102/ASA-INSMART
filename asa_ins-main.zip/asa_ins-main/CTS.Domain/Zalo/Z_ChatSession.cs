﻿namespace CTS.Domain.Zalo
{
    public class Z_ChatSession
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public string OAId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public virtual ICollection<Z_ChatSessionDetail> Z_ChatSessionDetails { get; set; }
    }

    public class Z_ChatSessionDetail
    {
        public Guid Id { get; set; }
        public Guid Z_ChatSessionId { get; set; }
        public virtual Z_ChatSession Z_ChatSession { get; set; }
        public string SenderId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}
