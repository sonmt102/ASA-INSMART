﻿namespace CTS.Domain.Zalo
{
    public class Z_AccountClientToken
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public string Token { get; set; }
        public bool IsDistributed { get; set; }
    }
}
