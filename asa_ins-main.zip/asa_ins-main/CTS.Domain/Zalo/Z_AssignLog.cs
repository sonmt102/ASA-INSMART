﻿namespace CTS.Domain.Zalo
{
    public class Z_AssignLog
    {
        public Guid Id { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string? AssignToUserName { get; set; }
        public string? AssignToFullName { get; set; }
        public string Z_CustomerId { get; set; }
        public virtual Z_Customer Z_Customer { get; set; }
    }
}
