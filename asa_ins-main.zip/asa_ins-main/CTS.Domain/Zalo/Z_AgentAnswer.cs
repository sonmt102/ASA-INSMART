﻿using CTS.Model;

namespace CTS.Domain.Zalo
{
    public class Z_AgentAnswer
    {
        public Guid Id { get; set; }
        public string Agent { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Msg_id { get; set; }
        public string User_id_by_app { get; set; }
        public int ? TimeReply { get; set; }
        public string? TypeMessage { get; set; }
        public string? MessageText { get; set; }
        public string? UrlFile { get; set; }
        public virtual ICollection<Z_AgentAnswerDetail> Z_AgentAnswerDetails { get; set; }
    }

    public class Z_AgentAnswerDetail
    {
        public Guid Id { get; set; }
        public Guid Z_AgentAnswerId { get; set; }
        //public Guid Z_AgentAnswer_Id { get; set; }
        public string? MsgId_KH { get; set; }
        public string? TimeId { get; set; }
        public DateTime CreatedDate { get; set; }
        public virtual Z_AgentAnswer Z_AgentAnswer { get; set; }
    }
}
