﻿namespace CTS.Domain.Zalo.ZNS
{
    public class ZNS_Vote_BA_Request
    {
        public Guid Id { get; set; }
        public string? Date { get; set; }
        public string? CustomerPhone { get; set; }
        public string? UserZaloId { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
