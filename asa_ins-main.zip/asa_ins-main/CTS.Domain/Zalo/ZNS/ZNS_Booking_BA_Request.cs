﻿namespace CTS.Domain.Zalo.ZNS
{
    public class ZNS_Booking_BA_Request
    {
        public Guid Id { get; set; }
        public string? Time { get; set; }
        public string? DepartureAdr { get; set; }
        public string? Arrival_Adr { get; set; }
        public string? VehicleNumber { get; set; }
        public string? VehicleLicense { get; set; }
        public string? DriverName { get; set; }
        public string? DriverPhone { get; set; }
        public string? CustomerPhone { get; set; }
        public string? UserZaloId { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
