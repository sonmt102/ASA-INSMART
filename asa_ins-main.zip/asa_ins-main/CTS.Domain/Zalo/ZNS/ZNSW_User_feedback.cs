﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.Zalo.ZNS
{
	public class ZNSW_User_feedback
	{
		public Guid Id { get; set; }
		public string? Event_name { get; set; }
		public string? Message_Note { get; set; }
		public int? Message_Rate { get; set; }
		public string? Message_submit_time { get; set; }
		public string? Message_msg_id { get; set; }
		public Guid? Message_tracking_id { get; set; }
		public string? App_id { get; set; }
		public string? Timestamp { get; set; }
		public DateTime? Timestamp_Date { get; set; }
	}


	public class ZNSW_User_feedbackDetail
	{
		public Guid Id { get; set; }
		public Guid ZNSW_User_feedbackId { get; set; }
		public string? Data { get; set; }

	}
}
