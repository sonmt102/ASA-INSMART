﻿namespace CTS.Domain.Zalo
{
    public class Z_Customer
    {
        public string Id { get; set; }
        public string? Name { get; set; }
        public string? AssignTo { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string? MessageLast { get; set; }
        public string? TypeMessageLast { get; set; }
        public string? UserSendLast { get; set; }
        public string? UrlAvata { get; set; }
        public string? NameZalo { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<Z_AssignLog> Z_AssignLogs { get; set; }
        public virtual ICollection<Z_CustomerTag> Z_CustomerTags { get; set; }
    }
}
