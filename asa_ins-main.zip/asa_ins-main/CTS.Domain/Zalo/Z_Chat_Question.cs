﻿namespace CTS.Domain.Zalo
{
    public class Z_Chat_Question
    {
        public Guid Id { get; set; }
        public string OAId { get; set; }
        public string keyWord { get; set; }
        public string Content { get; set; }
        public int Index { get; set; }
    }
}
