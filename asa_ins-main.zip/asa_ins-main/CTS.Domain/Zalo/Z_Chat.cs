﻿using CTS.Model;

namespace CTS.Domain.Zalo
{
    public class Z_Chat : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid? ZWId { get; set; }
        public Guid? AccountId { get; set; }
        public string SenderId { get; set; }
        public bool IsOASend { get; set; }
        public string Event_name { get; set; }
        public string AppId { get; set; }
        public DateTime Timestamp { get; set; }
        public bool IsReceived { get; set; }
        public bool IsSeen { get; set; }
        public DateTime ReceivedDate { get; set; }
        public DateTime SeenDate { get; set; }
        public virtual ICollection<Z_ChatDetail> Z_ChatDetails { get; set; }
    }


    public class Z_ChatDetail
    {
        public Guid Id { get; set; }
        public Guid Z_ChatId { get; set; }
        public virtual Z_Chat Z_Chat { get; set; }
        public string? Type { get; set; }


        //tin nhẵn chữ
        public string? Text { get; set; }
        public string? Msg_id { get; set; }

        //ảnh
        public string? Thumbnail { get; set; }
        public string? Url { get; set; }


        public string? Description { get; set; }
        public string? StickerId { get; set; }

        //File
        public string? Size { get; set; }
        public string? Name { get; set; }
        public string? Checksum { get; set; }

        //Vị trí
        public string? Latitude { get; set; }
        public string? Longitude { get; set; }

    }
}
