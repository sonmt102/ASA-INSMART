﻿using CTS.Model;

namespace CTS.Domain.CIMS
{
    public class CIMS_Customer : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string? Email { get; set; }
    }
}
