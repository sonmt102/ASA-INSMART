﻿using CTS.Model;

namespace CTS.Domain.CIMS
{
    public class CIMS_DanhMucTinh : DefaultEntity
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        public Guid? ParentId { get; set; }
        public virtual CIMS_DanhMucTinh? Parent { get; set; }
        public virtual ICollection<CIMS_DanhMucTinh> Children { get; set; }
    }
}
