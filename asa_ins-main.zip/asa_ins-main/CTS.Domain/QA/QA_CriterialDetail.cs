﻿using CTS.Model;

namespace CTS.Domain.QA
{
    public class QA_CriterialDetail : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public Guid QA_CriterialId { get; set; }
        public decimal Mark { get; set; }
        public int OrderIndex { get; set; }
        public virtual QA_Criterial QA_Criterial { get; set; }
        public virtual ICollection<QA_MarkDetail> QA_MarkDetails { get; set; }
    }
}
