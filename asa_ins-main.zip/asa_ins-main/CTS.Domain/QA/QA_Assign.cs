﻿using CTS.Domain.Manager;
using CTS.Model;

namespace CTS.Domain.QA
{
    public class QA_Assign : DefaultEntity
    {
        public Guid Id { get; set; }
        public Guid CRM_AccountId { get; set; }
        public string Direction { get; set; }
        public int NumberCall { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public virtual ICollection<QA_AssignAccount>? QA_AssignAccounts { get; set; }
        public virtual CRM_Account CRM_Account { get; set; }
        public virtual ICollection<QA_Mark>? Marks { get; set; }
    }
}
