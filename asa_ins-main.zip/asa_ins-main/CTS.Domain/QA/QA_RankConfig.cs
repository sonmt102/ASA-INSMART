﻿using CTS.Model;

namespace CTS.Domain.QA
{
    public class QA_RankConfig : DefaultEntity
    {
        public Guid Id { get; set; }
        public decimal MarkFrom { get; set; }
        public decimal MarkTo { get; set; }
        public string Name { get; set; }
        public virtual ICollection<QA_Mark> QA_Marks { get; set; }
    }

    public class QA_AgentError : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public Guid QA_GroupCriteriaId { get; set; }
        public virtual QA_GroupCriteria QA_GroupCriteria { get; set; }
        public virtual ICollection<QA_MarkAgentError> QA_MarkAgentErrors { get; set; }
    }

    public class QA_MarkAgentError
    {
        public Guid QA_MarkId { get; set; }
        public Guid QA_AgentErrorId { get; set; }
        public virtual QA_Mark QA_Mark { get; set; }
        public virtual QA_AgentError QA_AgentError { get; set; }
    }
}
