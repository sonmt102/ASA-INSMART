﻿using CTS.Common;
using CTS.Model;

namespace CTS.Domain.QA
{
    public class QA_GroupCriteria : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public QALoaiTieuChi Type { get; set; }
        public virtual ICollection<QA_Criterial> Criterials { get; set; }
        public virtual ICollection<QA_AgentError> AgentErrors { get; set; }
    }
}
