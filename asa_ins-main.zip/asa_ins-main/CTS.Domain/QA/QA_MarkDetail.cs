﻿using CTS.Model;

namespace CTS.Domain.QA
{
    public class QA_MarkDetail : DefaultEntity
    {
        public Guid Id { get; set; }
        public decimal CriterialMark { get; set; }
        public decimal Mark { get; set; }
        public string? ChiTietLoi { get; set; }
        public string? HuongDanSuaLoi { get; set; }
        public string? NhanVienPhanHoi { get; set; }
        public Guid QA_CriterialDetailId { get; set; }
        public Guid QA_CriterialId { get; set; }
        public Guid QA_MarkId { get; set; }
        public virtual QA_Mark QA_Mark { get; set; }
        public virtual QA_CriterialDetail QA_CriterialDetail { get; set; }
        public virtual QA_Criterial? QA_Criterial { get; set; }
    }
}
