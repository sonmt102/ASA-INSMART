﻿namespace CTS.Domain.QA
{
    public class QA_MarkFeedback
    {
        public Guid Id { get; set; }
        public Guid MarkId { get; set; }
        public string RateContent { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public virtual QA_Mark Mark { get; set; }
    }

    public class MarkFeedback
    {
        public Guid Id { get; set; }
        public Guid MarkId { get; set; }
        public string RateContent { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString("dd/MM/yyyy HH:mm"); }
    }

    public class CreateFeedbackModel
    {
        public Guid MarkId { get; set; }
        public string Content { get; set; }
    }

    public class CloseMarkFeedbackModel
    {
        public Guid MarkId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
