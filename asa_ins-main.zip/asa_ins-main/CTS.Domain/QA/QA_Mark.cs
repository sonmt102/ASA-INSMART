﻿using CTS.Model;

namespace CTS.Domain.QA
{
    public class QA_Mark : DefaultEntity
    {
        public Guid Id { get; set; }
        public decimal TotalMark { get; set; }
        public bool IsCloseFeedback { get; set; }
        public string? CallDirection { get; set; }
        public string? AgentStation { get; set; }
        public int? CallDuration { get; set; }
        public DateTime CallDate { get; set; }
        public string CallId { get; set; }
        public string? LocalNumber { get; set; }
        public string MarkBy { get; set; }
        public string CustomerPhone { get; set; }
        public string Agent { get; set; }
        public virtual ICollection<QA_MarkDetail> QA_MarkDetails { get; set; }
        public Guid? QA_RankConfigId { get; set; }
        public virtual QA_RankConfig? QA_RankConfig { get; set; }
        /// <summary>
        /// Lượt phân công
        /// </summary>
        public Guid? QA_AssignId { get; set; }
        public virtual QA_Assign? Assign { get; set; }
    }


}
