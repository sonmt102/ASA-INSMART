﻿using CTS.Domain.Manager;

namespace CTS.Domain.QA
{
    public class QA_AssignAccount
    {
        public Guid QA_AssignId { get; set; }
        public Guid CRM_AccountId { get; set; }
        public virtual QA_Assign QA_Assign { get; set; }
        public virtual CRM_Account CRM_Account { get; set; }
    }
}
