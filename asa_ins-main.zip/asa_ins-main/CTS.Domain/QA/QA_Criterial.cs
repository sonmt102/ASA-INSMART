﻿using CTS.Model;

namespace CTS.Domain.QA
{
    public class QA_Criterial : DefaultEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public Guid QA_GroupCriteriaId { get; set; }
        public int Mark { get; set; }
        public int OrderIndex { get; set; }
        public virtual ICollection<QA_CriterialDetail> QA_CriterialDetails { get; set; }
        //public virtual QA_GroupCriteria QA_GroupCriteria { get; set; }
        public virtual ICollection<QA_MarkDetail> QA_MarkDetails { get; set; }
    }
}
