﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.KMS
{
    public class KMS_Posts
    {
        public Guid Id { get; set; }
        public string? PostTitle { get; set; }
        public string? PostUrl { get; set; }
        public string? PostShortContent { get; set; }
        public string? PostContent { get; set; }
        public string? PostAvatar { get; set; }
        public string? PostDocument { get; set; }
        public DateTime? PostExpired { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public bool IsFeatured { get; set; }
        public bool EnableComment { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<KMS_Posts_Category>? KMS_Posts_Categories { get; set; }
        public virtual ICollection<KMS_Posts_Modifier>? KMS_Posts_Modifiers { get; set; }
        public virtual ICollection<KMS_Posts_Comments>? KMS_Posts_Comments { get; set; }
        public virtual ICollection<KMS_Files_Approved>? KMS_Files_Approved { get; set; }
        public virtual KMS_Posts_Views? KMS_Posts_Views { get; set; }
    }

    public class KMS_Posts_Category
    {
        public Guid KMS_PostsId { get; set; }
        public virtual KMS_Posts? Posts { get; set; }
        public Guid KMS_CategoryId { get; set; }
        public virtual KMS_Category? Category { get; set; }
    }
}
