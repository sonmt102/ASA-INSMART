﻿using CTS.Domain.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.KMS
{
    public class KMS_Category
    {
        public Guid Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? StringValue { get; set; }
        public string? ICon { get; set; }
        public int OrderIndex { get; set; }
        public Guid? ParentId { get; set; }
        public bool IsDeleted { get; set; }
        public virtual KMS_Category? Parent { get; set; }
        public virtual ICollection<KMS_Category>? Childrens { get; set; }
        public virtual ICollection<KMS_Posts_Category>? KMS_Posts_Categories { get; set; }
    }
}
