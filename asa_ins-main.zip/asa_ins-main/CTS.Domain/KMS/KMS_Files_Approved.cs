﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.KMS
{
    public class KMS_Files_Approved
    {
        public Guid Id { get; set; }
        public string FileBaseUrl { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileHash { get; set; }
        public string FilePhash { get; set; }
        public string FileMime { get; set; }
        public string FileSize { get; set; }
        public string FileUrl { get; set; }
        public bool IsApproved { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public Guid KMS_PostsId { get; set; }
        public virtual KMS_Posts? KMS_Posts { get; set; }
    }
}
