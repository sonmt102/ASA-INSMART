﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.KMS
{
    public class KMS_Posts_Modifier
    {
        public Guid Id { get; set; }
        public string? PostTitle { get; set; }
        public string? PostShortContent { get; set; }
        public string? PostContent { get; set; }
        public string? PostAvatar { get; set; }
        public string? PostDocument { get; set; }
        public string? Note { get; set; }
        public string? Action { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid KMS_PostsId { get; set; }
        public virtual KMS_Posts KMS_Posts { get; set; }

    }
}
