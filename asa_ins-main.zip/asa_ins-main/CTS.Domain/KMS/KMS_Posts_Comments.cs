﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.KMS
{
    public class KMS_Posts_Comments
    {
        public Guid Id { get; set; }
        public Guid KMS_PostsId { get; set; }
        public string Comment { get; set; }
        public string? CreatedBy { get; set; }
        public string? FullName { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid? ParentId { get; set; }
        public bool IsDeleted { get; set; }
        public virtual KMS_Posts_Comments? Parent { get; set; }
        public virtual ICollection<KMS_Posts_Comments>? Childrens { get; set; }
        public virtual KMS_Posts? KMS_Posts { get; set; }
    }
}
