﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.KMS
{
    public class KMS_Posts_Views
    {
        public Guid Id { get; set; }
        public Guid KMS_PostsId { get; set; }
        public int Views { get; set; }
        public string UserViews { get; set; }
        public virtual KMS_Posts? KMS_Posts { get; set; }

    }
}
