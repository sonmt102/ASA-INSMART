﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Domain.KMS
{
    public class ArchiversElfinder
    {
        public List<string> create { get; set; }
        public List<string> extract { get; set; }
        public CreateextElfinder createext { get; set; }
    }

    public class CreateextElfinder
    {
        public string applicationzip { get; set; }
    }

    public class CwdElfinder
    {
        public string volumeid { get; set; }
        public string? phash { get; set; }
        public int dirs { get; set; }
        public string name { get; set; }
        public string hash { get; set; }
        public string mime { get; set; }
        public int ts { get; set; }
        public int size { get; set; }
        public int read { get; set; }
        public int write { get; set; }
        public int locked { get; set; }
    }

    public class DebugElfinder
    {
        public string connector { get; set; }
    }

    public class FileHashElfinder
    {
        public string phash { get; set; }
        public string name { get; set; }
        public string hash { get; set; }
        public string mime { get; set; }
        public int ts { get; set; }
        public int size { get; set; }
        public int read { get; set; }
        public int write { get; set; }
        public int locked { get; set; }
        public string tmb { get; set; }
        public string dim { get; set; }
        public string volumeid { get; set; }
        public int? dirs { get; set; }
        public int? isroot { get; set; }
    }

    public class OptionsElfinder
    {
        public ArchiversElfinder archivers { get; set; }
        public List<string> disabled { get; set; }
        public int copyOverwrite { get; set; }
        public string path { get; set; }
        public string separator { get; set; }
        public string tmbUrl { get; set; }
        public string trashHash { get; set; }
        public int uploadMaxConn { get; set; }
        public object uploadMaxSize { get; set; }
        public string url { get; set; }
    }

    public class KMS_Elfinder
    {
        public string api { get; set; }
        public List<object> netDrivers { get; set; }
        public CwdElfinder cwd { get; set; }
        public DebugElfinder debug { get; set; }
        public List<FileHashElfinder> files { get; set; }
        public OptionsElfinder options { get; set; }
    }


}
