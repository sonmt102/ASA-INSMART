﻿namespace CTS.Model.Mail.SMTP
{
    public class OAuth2Settings
    {
        public string Authority { get; set; }

        public string ClientId { get; set; }

        public string ClientSecret { get; set; }
    }
}
