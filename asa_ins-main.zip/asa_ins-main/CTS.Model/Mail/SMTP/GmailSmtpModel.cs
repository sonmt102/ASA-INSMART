﻿namespace CTS.Model.Mail.SMTP
{
    public class GmailSmtpModel
    {
        public string EmailName { get; set; }
        public string Email { get; set; }
        public int Port { get; set; }
        public string Host { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class Office365SmtpModel
    {
        public string EmailName { get; set; }
        public string Email { get; set; }
        public int SMTP_Port { get; set; }
        public string Username { get; set; }
        public string? ClientID { get; set; }
        public string? ClientSecret { get; set; }
        public string? TenantID { get; set; }
        public string? SMTP_Host { get; set; }
    }
}
