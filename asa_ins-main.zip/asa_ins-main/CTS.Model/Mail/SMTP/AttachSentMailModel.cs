﻿namespace CTS.Model.Mail.SMTP
{
    public class AttachSentMailModel
    {
        public string FilePath { get; set; }
        public string MineFile { get; set; }
        public string FileName { get; set; }
    }
}
