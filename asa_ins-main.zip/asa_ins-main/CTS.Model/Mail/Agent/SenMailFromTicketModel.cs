﻿using CTS.Model.VOC.OP;
using System.Globalization;

namespace CTS.Model.Mail.Agent
{
    public class SendMailFromTicketModel
    {
        public Guid OPId { get; set; }
        public string QueueCode { get; set; }
        public string Tos { get; set; }
        public string CCs { get; set; }
        public string Bccs { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public int SignId { get; set; }
        public Guid? MailId { get; set; }
        public Guid Id { get; set; }
        public bool IsSentInTicket { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> Attachs { get; set; }


    }

    public class CallFromOPModel
    {
        public string Phone { get; set; }
        public Guid OPId { get; set; }
    }
    public class MailSummaryModel
    {
        public int Total { get; set; }
        public string TotalStr
        {
            get
            {
                if (Total == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return Total.ToString("#,###", cul.NumberFormat);
            }
        }
        public int DaDoc { get; set; }
        public string DaDocStr
        {
            get
            {
                if (DaDoc == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return DaDoc.ToString("#,###", cul.NumberFormat);
            }
        }
        public int DaXuLy { get; set; }
        public string DaXuLyStr
        {
            get
            {
                if (DaXuLy == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return DaXuLy.ToString("#,###", cul.NumberFormat);
            }
        }
        public int ChuaDoc { get; set; }
        public string ChuaDocStr
        {
            get
            {
                if (ChuaDoc == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return ChuaDoc.ToString("#,###", cul.NumberFormat);
            }
        }
        public int XuLyGap { get; set; }
        public string XuLyGapStr
        {
            get
            {
                if (XuLyGap == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return XuLyGap.ToString("#,###", cul.NumberFormat);
            }
        }
        public int KHReply { get; set; }
        public string KHReplyStr
        {
            get
            {
                if (KHReply == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return KHReply.ToString("#,###", cul.NumberFormat);
            }
        }
    }
}
