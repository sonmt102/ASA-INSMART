﻿using CTS.Common;
using CTS.Model.VOC;

namespace CTS.Model.Mail
{
    public class DetailEmailModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string MessageId { get; set; }
        public string? Channel { get; set; }
        public string? From { get; set; }
        public string? FromEmail { get; set; }
        public string FromStr
        {
            get
            {
                if (string.IsNullOrEmpty(From)) return FromEmail;
                else return $"{From}<{FromEmail}>";

            }
        }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public List<TagListModel> Tags { get; set; }
        public List<DetailEmail_AttachModel> Attachs { get; set; }
        public List<DetailEmail_CCsModel> CCs { get; set; }
        public List<DetailEmail_CCsModel> Tos { get; set; }
        public List<TicketHistoryPhoneModel> TicketHistories { get; set; }
        public List<DetailAnswerEmailModel> Answers { get; set; }

        public string Color { get => Helper.RandomColor(); }
        public string NameChar { get => string.IsNullOrEmpty(FromStr) ? "?" : FromStr[..1]; }

    }

    public class DetailAnswerEmailModel
    {
        public Guid Id { get; set; }
        public string Color { get => Helper.RandomColor(); }
        public string NameChar { get => string.IsNullOrEmpty(Tos) ? "?" : Tos[..1]; }
        public string Subject { get; set; }
        public string BodyContent { get; set; }
        public string Body { get => BodyContent.Replace($"https://insmart.aseanbpo.com.vn/Analytics/Read", "#"); }
        public string? FromEmail { get; set; }
        public string CreatedBy { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public List<DetailEmail_AttachModel> Attachs { get; set; }
        public string CCs { get; set; }
        public string Tos { get; set; }
        public string BCCs { get; set; }
    }

    public class DetailEmail_AttachModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }

    public class DetailEmail_CCsModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Display
        {
            get
            {
                if (string.IsNullOrEmpty(Name)) return Email;
                else return $"{Name}<{Email}>";

            }
        }
    }
}
