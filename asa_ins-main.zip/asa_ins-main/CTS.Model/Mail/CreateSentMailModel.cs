﻿using CTS.Model.VOC.OP;

namespace CTS.Model.Mail
{
    public class CreateSentMailModel
    {
        public Guid Id { get; set; }
        public Guid? MailId { get; set; }
        public Guid? AnswerMailId { get; set; }
        public string? Body { get; set; }
        public string? ContentMailAnswer { get; set; }
        public string Subject { get; set; }
        public string To { get; set; }
        public string CC { get; set; }
        public string BCC { get; set; }
        public int SelectSign { get; set; }
        public string QueueMail { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> Attachs { get; set; }

    }
}
