﻿namespace CTS.Model.Mail
{
    public class TagListModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? Code { get; set; }
        public string? Color { get; set; }
        public string? ColorBadge { get; set; }
    }
}
