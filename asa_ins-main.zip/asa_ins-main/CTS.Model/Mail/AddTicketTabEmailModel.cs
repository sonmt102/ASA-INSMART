﻿namespace CTS.Model.Mail
{
    public class AddTicketTabEmailModel
    {
        public Guid MAIL_INBOXId { get; set; }
        public string FromMail { get; set; }
    }
}
