﻿using CTS.Common;
using Newtonsoft.Json;

namespace CTS.Model.Mail
{

    public class MailAgentInfoModel
    {
        public bool GeneralStatusBool
        {
            get => Groups != null && Groups.Count > 0 && Groups.Any(x => x.StatusCode == AgentStatusConst.SanSang);
        }
        public string GeneralStatus
        {
            get
            {
                if (Groups != null && Groups.Count > 0)
                {
                    var g = Groups.GroupBy(x => x.StatusCode).Select(s => s.Key).ToList();
                    if (g.Count > 1)
                    {
                        if (Groups.Any(x => x.StatusCode == AgentStatusConst.SanSang))
                            return AgentStatusConst.SanSang;
                        else
                            return AgentStatusConst.ChuaSanSang;
                    }
                    else
                    {
                        return g.FirstOrDefault();
                    }
                }
                return AgentStatusConst.ChuaSanSang;
            }
        }
        public string GeneralStatusStr
        {
            get
            {
                return GeneralStatus switch
                {
                    AgentStatusConst.DangNhap => "Đăng nhập",
                    AgentStatusConst.SanSang => "Sẵn sàng",
                    AgentStatusConst.ChuaSanSang => "Chưa sẵn sàng",
                    AgentStatusConst.NghiTrua => "Nghỉ trưa",
                    AgentStatusConst.Email => "Email",
                    AgentStatusConst.Hop => "Đi họp",
                    AgentStatusConst.RaNgoai => "Ra ngoài",
                    AgentStatusConst.ViecRieng => "Việc riêng",
                    AgentStatusConst.AnToi => "Ăn tối",
                    AgentStatusConst.NhapLieu => "Nhập liệu",
                    AgentStatusConst.SUP_Logout => "Supervisor loại khỏi nhóm",
                    AgentStatusConst.RoiNhom => "Rời nhóm",
                    AgentStatusConst.VaoNhom => "Vào nhóm",
                    AgentStatusConst.RequestLogout => "Người dùng yêu cầu logout",
                    AgentStatusConst.SUP_Pause => "Supervisor đặt trạng thái tạm dừng",
                    AgentStatusConst.SUP_UnPause => "Supervisor đặt trạng thái sẵn sàng",
                    _ => "Chưa sẵn sàng",
                };
            }
        }
        public List<MailAgentQueueInfoModel> Queues { get; set; }
        public List<MailAgentGroupInfoModel> Groups { get; set; }
    }

    public class MailAgentQueueInfoModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("text")]
        public string Text { get; set; }

    }

    public class MailAgentGroupInfoModel
    {
        public Guid AccountId { get; set; }
        public string AccountUserName { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public bool IsPause { get; set; }
        public string StatusCode { get; set; }
        public bool IsAssign { get; set; }
        public bool StatusCodeBool
        {
            get
            {
                return StatusCode switch
                {
                    AgentStatusConst.SanSang => true,
                    _ => false,
                };
            }
        }
        public string StatusCodeStr
        {
            get
            {
                return StatusCode switch
                {
                    AgentStatusConst.DangNhap => "Đăng nhập",
                    AgentStatusConst.SanSang => "Sẵn sàng",
                    AgentStatusConst.ChuaSanSang => "Chưa sẵn sàng",
                    _ => "Chưa sẵn sàng",
                };
            }
        }
    }
}
