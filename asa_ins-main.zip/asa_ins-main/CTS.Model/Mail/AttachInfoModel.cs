﻿namespace CTS.Model.Mail
{
    public class AttachInfoModel
    {
        public string Name { get; set; }
        public string Queue_Code { get; set; }
        public int UniqueId { get; set; }
    }
}
