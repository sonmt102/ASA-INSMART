﻿using CTS.Common;
using CTS.Domain.Mail;

namespace CTS.Model.Mail.SUP
{
    public class SUPGroupModel
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public List<SUPOnlineModel> Accounts { get; set; }
    }
    public class SUPOnlineModel
    {
        public int GroupId { get; set; }
        public string Color { get => Helper.RandomColor(); }
        public string Pre { get => UserName[..1]; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Status { get; set; }
        public int AssginNumber { get; set; }
        public bool IsPause { get; set; }
        public bool IsOnline { get; set; }
        public Guid CRM_AccountId { get; set; }
    }

    public class SUPUpdateQueueModel
    {
        public Guid CRM_AccountId {  get; set; }
        public int MAIL_GroupId { get; set; }
        public bool IsLeader { get; set; }
        public Guid MAIL_QueueId { get; set; }

      
      
    }
}
