﻿using CTS.Common;

namespace CTS.Model.Mail
{
    public class AgentMailModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Subject { get; set; }
        public string? AssignTo { get; set; }
        public bool IsAssign { get; set; }
        public string CongTy { get; set; }
        public DateTime? AssignDate { get; set; }
        public string AssignDateStr { get => AssignDate.HasValue ? AssignDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool IsHandler { get; set; }
        public bool IsSeen { get; set; }
        public bool IsImportant { get; set; }
        public bool AgentMarkReply { get; set; }
        public bool HadAttachs { get; set; }
        public List<TagListModel> Tags { get; set; }
        public bool IsShowControl { get => IsHandler || IsSeen || AgentMarkReply || IsImportant; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string? From { get; set; }
        public string? FromEmail { get; set; }
        public string FromStr
        {
            get
            {
                return string.IsNullOrEmpty(From) ? FromEmail : From;
            }
        }
        public string Color { get => Helper.RandomColor(); }
        public string NameChar { get => string.IsNullOrEmpty(FromStr) ? "?" : FromStr[..1]; }
    }
}
