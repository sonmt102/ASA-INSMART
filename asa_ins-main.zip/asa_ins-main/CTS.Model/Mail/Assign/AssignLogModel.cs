﻿using CTS.Common;

namespace CTS.Model.Mail.Assign
{
    public class AssignLogModel
    {
        public string AssignBy { get; set; }
        public DateTime AssignDate { get; set; }
        public string AssignDateStr { get => AssignDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string AssignTo { get; set; }
        public string Note { get; set; }
    }
}
