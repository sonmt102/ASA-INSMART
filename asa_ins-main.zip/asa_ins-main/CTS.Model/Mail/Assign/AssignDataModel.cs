﻿namespace CTS.Model.Mail.Assign
{
    public class AssignDataModel
    {
        public Guid AccountId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public int Counter { get; set; }
    }
}
