﻿namespace CTS.Model.Mail.Assign
{
    public class TransferMailModel
    {
        public string TransToAgent { get; set; }
        public List<Guid> MailIds { get; set; }
        public string? Note { get; set; }

    }
}
