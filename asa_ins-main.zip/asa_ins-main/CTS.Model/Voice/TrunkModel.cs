﻿namespace CTS.Model.Voice
{
    public class TrunkModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string Phone { get; set; }
        public string IP { get; set; }
        public int Port { get; set; }
    }

    public class TrunkMemoryModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }

    public class CreateTrunkModel
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public string Phone { get; set; }
        public string IP { get; set; }
        public int Port { get; set; }

        public string Transport { get => "transport-udp-nat"; }
        public string Context { get => "from-internal"; }
        public int Contacts { get => 3; }
        public string Allow { get => "g722, alaw, ulaw"; }
    }
}
