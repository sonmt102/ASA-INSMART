﻿using CTS.Common;
using CTS.Model.General;

namespace CTS.Model.Voice
{
    public class ExtensionModel
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        /// <summary>
        /// Đầu số
        /// </summary>
        public string? Exten { get; set; }
        public string? IP { get; set; }
        public int? Port { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public CallDirection Direction { get; set; }

        public string? QueueCode { get; set; }
    }

    public class ListExtensionModel
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        /// <summary>
        /// Đầu số
        /// </summary>
        public string? Exten { get; set; }
        public string? IP { get; set; }
        public int? Port { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public CallDirection Direction { get; set; }
        public string DirectionStr
        {
            get
            {
                return Direction switch
                {
                    CallDirection.Inbound => "Gọi vào",
                    CallDirection.Outbound => "Gọi ra",
                    CallDirection.Both => "Cả gọi vào, gọi ra",
                    _ => string.Empty
                };
            }
        }

    }

    public class ListExtensionDetailModel
    {

        public Guid? SelectedIVR { get; set; }
        public List<SelectModel> IVRs = new();
        public Guid? SelectedCalendar { get; set; }

        public List<SelectModel> Calendars = new();
        public int? Priority { get; set; }
    }

    public class CreateExtensionModel
    {
        public string Name { get; set; }
        /// <summary>
        /// Đầu số
        /// </summary>
        public string Exten { get; set; }
        public string IP { get; set; }
        public int? Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public CallDirection Direction { get; set; }
    }


    public class UpdateExtensionModel
    {
        public Guid? Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        /// <summary>
        /// Đầu số
        /// </summary>
        public string Exten { get; set; }
        public string IP { get; set; }
        public int? Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public CallDirection Direction { get; set; }
        public List<UpdateExtensionDetailModel> Details { get; set; }

    }

    public class UpdateExtensionDetailModel
    {
        public Guid? CalendarId { get; set; }
        public Guid? IVRId { get; set; }
        public int Priority { get; set; }
    }
}
