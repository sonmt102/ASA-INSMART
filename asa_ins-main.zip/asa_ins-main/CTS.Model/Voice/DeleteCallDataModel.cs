﻿namespace CTS.Model.Voice
{
    public class DeleteCallDataModel
    {
        public string UniqueId { get; set; }
        public string CusPhone { get; set; }
    }
}
