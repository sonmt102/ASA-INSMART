﻿namespace CTS.Model.Voice
{
    public class CallInQueueModel
    {
        public string? QueueName { get; set; }
        public int Calling { get; set; } = 0;
        public int Answering { get; set; } = 0;
        public int Ringing { get; set; } = 0;

    }
}
