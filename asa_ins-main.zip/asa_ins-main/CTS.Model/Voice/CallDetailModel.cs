﻿namespace CTS.Model.Voice
{
    public class CallDetailModel
    {
        public int STT { get; set; }
        public string CallId { get; set; }
        public string Domain { get; set; }
        public string? CallDirection { get; set; }
        public string? DNIS { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Extension { get; set; }
        public string? Queue { get; set; }
        public string? Agent { get; set; }
        public DateTime? CallStartTime { get; set; }
        public DateTime? CallEndTime { get; set; }
        public DateTime? PickupTime { get; set; }
        public int? LineDuration { get; set; }
        public int? IVRDuration { get; set; }
        public int? ACDDuration { get; set; }
        public int? HandleDuration { get; set; }
        public int? HoldDuration { get; set; }
        public string? CallStatus { get; set; }
        public string? CallEventLog { get; set; }
        public int? IsAnswer { get; set; }
        public int? IsNotAnswer { get; set; }
        public int? IsTransfer { get; set; }
        public int? IsStopInIVR { get; set; }
        public int? IsStopInACD { get; set; }
        public int? IsMissCall { get; set; }
        public int? IsCallAbandon { get; set; }
        public string? OMS_ID { get; set; }
        public string? HangupBy { get; set; }
    }
}
