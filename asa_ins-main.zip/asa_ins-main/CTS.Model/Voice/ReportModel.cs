﻿using CTS.Common;
using CTS.Domain.Asterisk;
using CTS.Domain.VOC;
using Microsoft.VisualBasic;
using System.Numerics;
using System.Runtime.Serialization;

namespace CTS.Model.Voice
{
    public class ReportCallDetailModel
    {
        public int STT { get; set; }
        public Guid? Id { get; set; }
        public string CallId { get; set; }
        public string? Extension { get; set; }
        public string? PhoneNumber { get; set; }
        public string? CallDirection { get; set; }
        public string? CallDirectionStr
        {
            get => CallDirection == UserEventStatusConst.IVR ? "Gọi vào" :
                CallDirection == UserEventStatusConst.CALLOUTBOUND ? "Gọi ra" : "Không xác định";
        }
        public DateTime? CallStartTime { get; set; }
        public string? CallStartTimeStr
        {
            get
            {
                return CallStartTime != null ? CallStartTime.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : String.Empty;
            }
        }
        public string? AgentCallStartTimeStr
        {
            get
            {
                return CallStartTime != null ? $"Ngày {CallStartTime.Value.ToString(FormatDate.DateTime_103)} " +
                    $"vào lúc {CallStartTime.Value:HH:mm}" : String.Empty;
            }
        }
        public DateTime? CallEndTime { get; set; }
        public string? CallEndTimeStr
        {
            get
            {
                return CallEndTime != null ? CallEndTime.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : String.Empty;
            }
        }
        public string? Agent { get; set; }
        public string? Queue { get; set; }
        public string? QueueStr { get; set; }
        public int? Duration { get; set; }
        public string DurationStr { get => Duration.HasValue ? TimeSpan.FromSeconds(Duration.Value).ToString() : TimeSpan.Zero.ToString(); }
        public string CallStatus { get => IsAnswer ? "Trả lời" : "không trả lời"; }
        public string CallStatusDetail
        {
            //(status.Contains(0) && x.IsStopInIVR == 1) //KH dừng ở IVR
            //|| (status.Contains(1) && x.IsStopInACD == 1 && !x.IsAgentBusy) //KH dừng ở ACD
            //|| (status.Contains(2) && x.IsStopInACD == 1 && x.IsAgentBusy) //TĐV bận, TH: tất cả TĐV không SS hoặc đang nghe số khác gọi đến
            //|| (status.Contains(3) && x.IsAgentHangup)  // TĐV ngắt máy
            //|| (status.Contains(4) && x.IsCallerHangup && !x.IsAgentHangup) //KH ngắt máy
            //|| (status.Contains(5) && !x.IsAgentHangup && x.IsAgentNoPickup) //TĐV không nghe máy
            //|| (status.Contains(6) && x.IsAnswer)

            get
            {
                switch (CallDirection)
                {
                    case UserEventStatusConst.CALLOUTBOUND:
                        if (IsAnswer) return "Kết nối";
                        else return "Không kết nối";
                    case UserEventStatusConst.IVR:
                        if (IsAnswer) return "Trả lời";
                        else if (IsStopInIVR == 1) return "KH dừng ở IVR";
                        else if (IsStopInACD == 1 && !IsAgentBusy) return "KH dừng ở ACD";
                        else if (IsStopInACD == 1 && IsAgentBusy) return "TĐV bận";
                        else if (IsAgentHangup) return "TĐV ngắt máy";
                        else if (IsCallerHangup && !IsAgentHangup) return "KH ngắt máy";
                        else if (!IsAgentHangup && IsAgentNoPickup) return "TĐV không nghe máy";
                        else return "KH ngắt máy";
                    default:
                        return "Gọi nội bộ";
                }

            }
        }
        public bool IsAnswer { get; set; }
        public int IsNotAnswer { get; set; }
        public string? CallEventLog { get; set; }
        public string? Recoding { get; set; }
        public string? Hotline { get; set; }
        public long? HoldTime { get; set; }
        public string? HangupBy { get; set; }
        public Guid? OMS_ID { get; set; }
        public string? FullName { get; set; }
        public string? AgentFullName { get; set; }
        public string? VOCRequestTypeName { get; set; }
        public string? KN_LoaiKhieuNai { get; set; }
        public Guid? TicketId { get; set; }
        public int IsStopInIVR { get; set; }
        public int IsStopInACD { get; set; }
        public int IsMissCall { get; set; }
        public int IsCallAbandon { get; set; }
        public bool IsAgentBusy { get; set; }
        public bool IsCallerHangup { get; set; }
        public bool IsAgentHangup { get; set; }
        public bool IsAgentNoPickup { get; set; }
    }


    public class ReportCallByDayModel
    {
        public int STT { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_103); }
        public int Total { get; set; }
        public int TotalInbound { get; set; }
        public int TotalInboundAns { get; set; }
        public int TotalInboundNoAns { get; set; }
        public int TotalOutbound { get; set; }
        public float Rate { get; set; }

    }



    public class ReportCallByHourlyModel
    {
        public int STT { get; set; }
        public int Hour { get; set; }
        public string HourStr { get => Hour < 10 ? $"0{Hour}:00:00" : $"{Hour}:00:00"; }
        public int Total { get; set; }
        public int TotalInbound { get; set; }
        public int TotalInboundAns { get; set; }
        public int TotalInboundNoAns { get; set; }
        public int TotalOutbound { get; set; }
        public float Rate { get; set; }

    }


    public class ReportCallByDNISModel
    {
        public int STT { get; set; }
        public string DNIS { get; set; }
        public int Total { get; set; }
        public int TotalInbound { get; set; }
        public int TotalInboundAns { get; set; }
        public int TotalInboundNoAns { get; set; }
        public int TotalOutbound { get; set; }
        public float Rate { get; set; }

    }

    public class ReportCallAbandonModel
    {
        //[{ id: 0, text: 'KH dừng ở IVR' }, { id: 1, text: 'KH dừng ở ACD' }, { id: 2, text: 'TĐV bận' },
        //{ id: 3, text: 'TĐV ngắt máy' }, { id: 4, text: 'KH ngắt máy' }, { id: 5, text: 'TĐV không nghe máy' }]
        public int STT { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_103); }
        public int Total { get => StopIVR + StopACD + AgentBusy + AgentHangup + CallerHangup + AgentNoPickup; }
        public int StopIVR { get; set; }
        public int StopACD { get; set; }
        public int AgentBusy { get; set; }
        public int AgentHangup { get; set; }
        public int CallerHangup { get; set; }
        public int AgentNoPickup { get; set; }
    }


    public class ReportTotalIndexModel
    {
        public int Total { get; set; }
        public int TotalInbound { get; set; }
        public int TotalInboundAns { get; set; }
        public int TotalInboundNoAns { get; set; }
        public int TotalOutbound { get; set; }
        public int TotalOutboundAns { get; set; }

    }

    public class ReportRateQueueModel
    {
        public string QueueName { get; set; }
        public int Total { get; set; }
        public int TotalInbound { get; set; }
        public int TotalInboundAns { get; set; }
        public int TotalInboundNoAns { get; set; }
        public int TotalOutbound { get; set; }
        public float Rate { get; set; }
    }


    public class ReportTopAgentModel
    {
        public string Agent { get; set; }
        public int Total { get; set; }
        public int TotalInbound { get; set; }
        public int TotalInboundAns { get; set; }
        public int TotalInboundNoAns { get; set; }
        public int TotalOutbound { get; set; }
        public float Rate { get; set; }
    }

    public class ReportMissCheckModel
    {
        public int STT { get; set; }
        public string CallId { get; set; }
        public string? Extension { get; set; }
        public string? PhoneNumber { get; set; }
        public string? CallDirection { get; set; }
        public string? CallDirectionStr
        {
            get => CallDirection == UserEventStatusConst.IVR ? "Gọi vào" :
                CallDirection == UserEventStatusConst.CALLOUTBOUND ? "Gọi ra" : "Không xác định";
        }
        public DateTime? CallStartTime { get; set; }
        public string? CallStartTimeStr
        {
            get
            {
                return CallStartTime != null ? CallStartTime.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : String.Empty;
            }
        }
        public string? AgentCallStartTimeStr
        {
            get
            {
                return CallStartTime != null ? $"Ngày {CallStartTime.Value.ToString(FormatDate.DateTime_103)} " +
                    $"vào lúc {CallStartTime.Value:HH:mm}" : String.Empty;
            }
        }
        public DateTime? CallEndTime { get; set; }
        public string? CallEndTimeStr
        {
            get
            {
                return CallEndTime != null ? CallEndTime.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : String.Empty;
            }
        }
        public string? Agent { get; set; }
        public string? Queue { get; set; }
        public string? QueueStr { get; set; }
        public int? Duration { get; set; }
        public string DurationStr { get => Duration.HasValue ? TimeSpan.FromSeconds(Duration.Value).ToString() : TimeSpan.Zero.ToString(); }
        public string CallStatus { get => IsAnswer ? "Trả lời" : "không trả lời"; }
        public string CallStatusDetail
        {
            //(status.Contains(0) && x.IsStopInIVR == 1) //KH dừng ở IVR
            //|| (status.Contains(1) && x.IsStopInACD == 1 && !x.IsAgentBusy) //KH dừng ở ACD
            //|| (status.Contains(2) && x.IsStopInACD == 1 && x.IsAgentBusy) //TĐV bận, TH: tất cả TĐV không SS hoặc đang nghe số khác gọi đến
            //|| (status.Contains(3) && x.IsAgentHangup)  // TĐV ngắt máy
            //|| (status.Contains(4) && x.IsCallerHangup && !x.IsAgentHangup) //KH ngắt máy
            //|| (status.Contains(5) && !x.IsAgentHangup && x.IsAgentNoPickup) //TĐV không nghe máy
            //|| (status.Contains(6) && x.IsAnswer)

            get
            {
                switch (CallDirection)
                {
                    case UserEventStatusConst.CALLOUTBOUND:
                        if (IsAnswer) return "Kết nối";
                        else return "Không kết nối";
                    case UserEventStatusConst.IVR:
                        if (IsAnswer) return "Trả lời";
                        else if (IsStopInIVR == 1) return "Dừng ở IVR";
                        else if (IsStopInACD == 1 && !IsAgentBusy) return "Dừng ở ACD";
                        else if (IsStopInACD == 1 && IsAgentBusy) return "TĐV bận";
                        //else if (IsAgentHangup) return "TĐV ngắt máy";
                        //else if (IsCallerHangup && !IsAgentHangup) return "KH ngắt máy";
                        //else if (!IsAgentHangup && IsAgentNoPickup) return "TĐV không nghe máy";
                        else return "Gọi nhỡ";
                    default:
                        return "Gọi nội bộ";
                }

            }
        }
        public bool IsAnswer { get; set; }
        public int IsNotAnswer { get; set; }
        public string? CallEventLog { get; set; }
        public string? Recoding { get; set; }
        public string? Hotline { get; set; }
        public long? HoldTime { get; set; }
        public string? HangupBy { get; set; }
        public Guid? OMS_ID { get; set; }
        public string? FullName { get; set; }
        public string? AgentFullName { get; set; }
        public string? VOCRequestTypeName { get; set; }
        public Guid? TicketId { get; set; }
        public int IsStopInIVR { get; set; }
        public int IsStopInACD { get; set; }
        public int IsMissCall { get; set; }
        public int IsCallAbandon { get; set; }
        public bool IsAgentBusy { get; set; }
        public bool IsCallerHangup { get; set; }
        public bool IsAgentHangup { get; set; }
        public bool IsAgentNoPickup { get; set; }
    }
    public class ExportReportMissCheckModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportMissCheckModel> Result { get; set; } = new List<ReportMissCheckModel>();

    }

    public class ExportReportCallDetailModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportCallDetailModel> Result { get; set; } = new List<ReportCallDetailModel>();

    }


    public class ExportReportCallBydDayModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportCallByDayModel> Result { get; set; } = new List<ReportCallByDayModel>();

    }

    public class ExportReportCallByHourlyModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportCallByHourlyModel> Result { get; set; } = new List<ReportCallByHourlyModel>();

    }

    public class ExportReportCallByDNISModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportCallByDNISModel> Result { get; set; } = new List<ReportCallByDNISModel>();

    }
    public class ExportReportCallAbandonModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportCallAbandonModel> Result { get; set; } = new List<ReportCallAbandonModel>();

    }


    public class ReportAgentStatusDetailModel
    {
        public int STT { get; set; }
        public string Agent { get; set; }
        public string Status { get; set; }
        public DateTime StartTime { get; set; }
        public string StartTimeStr { get => StartTime.ToString(FormatDate.DateTime_ddMMyyyyHHmmss); }
        public DateTime EndTime { get; set; }
        public string EndTimeStr { get => EndTime.ToString(FormatDate.DateTime_ddMMyyyyHHmmss); }

    }

    public class ExportReportAgentStatusDetailModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportAgentStatusDetailModel> Result { get; set; } = new List<ReportAgentStatusDetailModel>();

    }

    public class ReportAgentProductivityModel
    {
        public string Agent { get; set; }
        public int AgentTotalTime { get; set; }
        public int AgentOnlineTime { get; set; }
        public int AgentOfflineTime { get; set; }
        public int Total { get; set; }
        public int TotalInbound { get => TotalInboundAns + TotalInboundNoAns; }
        public int TotalInboundAns { get; set; }
        public int TotalInboundNoAns { get; set; }
        public int TotalOutbound { get => TotalOutboundAns + TotalOutboundNoAns; }
        public int TotalOutboundAns { get; set; }
        public int TotalOutboundNoAns { get; set; }
        public float AnswerRate { get; set; }
        public float AbandonRate { get; set; }
    }

    public class ExportReportAgentPerformanceModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportAgentProductivityModel> Result { get; set; } = new();

    }
    public class DashboardHeaderTotal
    {
        public int TotalIVR { set; get; } = 0;
        public int TotalQueue { set; get; } = 0;
        public int TotalRinging { set; get; } = 0;
        public int TotalAnswer { set; get; } = 0;
    }
    public class DashboardTotalIndex
    {
        public int TotalIncoming { set; get; }
        public int TotalOutgoing { set; get; }
        public int TotalQueue { set; get; }
        public int TotalAnswer { set; get; }
        public int TotalNoAnswer { set; get; }
        public dynamic NoAnswerRate { get => (TotalNoAnswer > 0 && TotalQueue > 0) ? ((TotalNoAnswer * 100) / TotalQueue) : 0; }
    }

    public class DashboardObjectDateTime
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
    }

    public class DashboardObjectChart
    {
        public DateTime FromDate { get; set; }
        public string FromDateStr { get => FromDate.ToString("HH:mm"); }
        public int TotalCall { get; set; }
    }

    public class DashboardAgentProductivity
    {
        public string UserName { get; set; }
        public int TotalIncoming { get; set; }
        public int TotalAnswer { get; set; }
        public int TotalNoAnswer { get; set; }
        public string AverageAnswer { get; set; }
    }


    public class ExportReportAgentCallHistoryModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public string Queues { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public List<ReportCallDetailModel> Result { get; set; } = new List<ReportCallDetailModel>();

    }


    //// Model các báo cáo mới

    #region Lịch sử thay đổi trạng thái ĐTV

    public class MgAgentStatusModel
    {
        public string AgentId { get; set; }
        public string AgentName { get; set; }
        public string QueueName { get; set; }
        public string StatusName { get; set; }
        public long DateStart { get; set; }
        public long? DateEnd { get; set; }
        public int TotalDuration { get; set; }
    }
    public class ReportAgentChangeStatusModel
    {
        public int STT { get; set; }
        public double TotalTime { get; set; }
        public string Agent { get; set; }
        public Guid AgentId { get; set; }
        public string Queue { get; set; }
        public string FullName { get; set; }
        public string Status { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public DateTime StartTime { get => DateStart; }
        public DateTime? EndTime { get => DateEnd.HasValue ? DateEnd.Value : null; }
        public string StartTimeStr { get => StartTime.ToString(FormatDate.DateTime_ddMMyyyyHHmmss); }
        public string EndTimeStr { get => EndTime.HasValue ? EndTime.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : string.Empty; }
        public TimeSpan TotalTimeStr { get => TimeSpan.FromSeconds(Math.Floor(TotalTime)); }

    }

    public class ExportReportAgentChangeStatusModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReportAgentChangeStatusModel> Result { get; set; } = new List<ReportAgentChangeStatusModel>();

    }


    #endregion

    #region Lịch sử trạng thái của nhân viên
    public class ReportAgentStatusHistoryModel
    {
        public int STT { get; set; }
        public double TotalTime { get; set; }
        public string Agent { get; set; }
        public string FullName { get; set; }
        public string Status { get; set; }
        public string StatusCode { get; set; }
        public DateTime StartTime { get; set; }
        public string StartTimeStr { get => StartTime.ToString(FormatDate.DateTime_ddMMyyyyHHmmss); }
        public TimeSpan TotalTimeStr { get => TimeSpan.FromSeconds(Math.Floor(TotalTime)); }

    }


    public class ReportGroupAgentStatusHistoryModel
    {
        public string Agent { get; set; }
        public List<ReportAgentStatusHistoryModel> reportAgentChangeStatusModels { get; set; }
    }
    public class ReponseAgentStatusHistoryModel
    {
        public string Agent { get; set; }
        public string Queue { get; set; }
        public string FullName { get; set; }
        public DateTime? FirstOnline { get; set; }
        public string FirstOnlineStr { get => FirstOnline.HasValue ? FirstOnline.Value.ToString(FormatDate.DateTime_121) : string.Empty; }
        public DateTime? FirstAvailable { get; set; }
        public string FirstAvailableStr { get => FirstAvailable.HasValue ? FirstAvailable.Value.ToString(FormatDate.DateTime_121) : string.Empty; }
        public DateTime? LastOffline { get; set; }
        public string LastOfflineStr { get => LastOffline.HasValue ? LastOffline.Value.ToString(FormatDate.DateTime_121) : string.Empty; }
        public double TimeAway { get; set; }
        public TimeSpan TimeAwayStr { get => TimeSpan.FromSeconds((int)TimeAway); }
        public double TimeOnline { get; set; }
        public TimeSpan TimeOnlineStr { get => TimeSpan.FromSeconds((int)TimeOnline); }
        public double TimeAvailable { get; set; }
        public TimeSpan TimeAvailableStr { get => TimeSpan.FromSeconds((int)TimeAvailable); }
        public double TimeAtLunch { get; set; }
        public TimeSpan TimeAtLunchStr { get => TimeSpan.FromSeconds((int)TimeAtLunch); }
        public double TimeNotAvailable { get; set; }
        public TimeSpan TimeNotAvailableStr { get => TimeSpan.FromSeconds((int)TimeNotAvailable); }
        public double TimeOther { get; set; }
        public TimeSpan TimeOtherStr { get => TimeSpan.FromSeconds((int)TimeOther); }
        public double TimeInputData { get; set; }
        public TimeSpan TimeInputDataStr { get => TimeSpan.FromSeconds((int)TimeInputData); }
        public double TimeBackEnd { get; set; }
        public TimeSpan TimeBackEndStr { get => TimeSpan.FromSeconds((int)TimeBackEnd); }

    }
    public class ExportReportAgentStatusHistory
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReponseAgentStatusHistoryModel> Result { get; set; } = new List<ReponseAgentStatusHistoryModel>();

    }
    #endregion

    #region Lịch sử đổ cuộc gọi vào TĐV

    public class ExportReportAgentCallHistory
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReportAgentCallHistory> Result { get; set; } = new List<ReportAgentCallHistory>();

    }

    public class ReportAgentCallHistory
    {
        public string CallId { get; set; }
        public string Direction { get; set; }
        public string? Agent { get; set; }
        public string? AgentName { get; set; }
        public string? Queue { get; set; }
        public DateTime StartTime { get; set; }
        public string StartTimeStr { get => StartTime.ToString(FormatDate.DateTime_ddMMyyyyHHmmss); }
        public DateTime EndTime { get; set; }
        public string EndTimeStr { get => EndTime.ToString(FormatDate.DateTime_ddMMyyyyHHmmss); }
        public DateTime? EnterQueueTime { get; set; }
    }
    #endregion

    #region Hiệu suất TĐV

    public class ReportAgentProductivityGroup
    {
        public string Agent { get; set; }
        public List<CallDetail> CallDetails { get; set; } = new List<CallDetail>();
        public List<CallLog> CallLogs { get; set; }
    }
    public class ReportAgentProductivity
    {
        public string Agent { get; set; }
        public TimeSpan AvgAnswerTime { get => (CallConnected > 0 && AvgTalkTime > 0) ? TimeSpan.FromSeconds(AvgTalkTime / CallConnected) : TimeSpan.FromSeconds(0); }
        public int AvgTalkTime { get; set; }
        public TimeSpan AvgTalkTimeStr { get => AvgTalkTime > 0 ? TimeSpan.FromSeconds(AvgTalkTime) : TimeSpan.FromSeconds(0); }
        public int CallConnected { get; set; }
        public int CallMissed { get; set; }
        public int CallOut { get; set; }
    }
    public class ExportReportAgentProductivity
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReportAgentProductivityCallModels> Result { get; set; } = new List<ReportAgentProductivityCallModels>();

    }

    public class ReportAgentProductivityCallModels
    {
        public string Agent { get; set; }
        public int TotalCallIn { get; set; }
        public int TotalCallInOk { get; set; }
        public int TotalTalkTime { get; set; }
        public TimeSpan TotalTalkTimeStr { get => TimeSpan.FromSeconds(TotalTalkTime); }
        public TimeSpan TotalTalkTimeAvg { get => (TotalTalkTime > 0 && TotalCallInOk > 0) ? TimeSpan.FromSeconds(TotalTalkTime / TotalCallInOk) : TimeSpan.FromSeconds(0); }
        public int TotalTimeHold { get; set; }
        public TimeSpan TotalTimeHoldStr { get => TotalTimeHold > 0 ? TimeSpan.FromSeconds(TotalTimeHold) : TimeSpan.FromSeconds(0); }
        public int TotalTimeHoldAvg { get; set; }
        public TimeSpan TotalTimeHoldAvgStr { get => TotalTimeHoldAvg > 0 ? TimeSpan.FromSeconds(TotalTimeHoldAvg) : TimeSpan.FromSeconds(0); }
        public int TotalCallInMiss { get; set; }
        public double PercentCallInMiss { get => (TotalCallInMiss > 0 && TotalCallIn > 0) ? (TotalCallInMiss / TotalCallIn) : 0; }
        public int TotalCallOut { get; set; }
        public int TotalCallOutOk { get; set; }
        public int TotalCallOutNOk { get; set; }
        public int TotalTimeCallOutOk { get; set; }
        public TimeSpan TotalTimeCallOutOkStr { get => TimeSpan.FromSeconds(TotalTimeCallOutOk); }
        public TimeSpan TotalTimeCallOutOkAvgStr { get => (TotalTimeCallOutOk > 0 && TotalCallOutOk > 0) ? TimeSpan.FromSeconds(TotalTimeCallOutOk / TotalCallOutOk) : TimeSpan.FromSeconds(0); }
        public int TotalTimeCallOutNOk { get; set; }
        public int TotalTimeCallOut { get; set; }
        public TimeSpan TotalTimeCallOutStr { get => TimeSpan.FromSeconds(TotalTimeCallOut); }
    }
    #endregion

    #region Chi tiết lịch sử cuộc gọi
    public class ReportDetaillCallHistoryModel
    {
        public int STT { get; set; } = 0;
        public string CallId { get; set; }
        public string Direction { get; set; }
        public string PhoneNumber { get; set; }
        public string CustomerName { get; set; }
        public string DNIS { get; set; }
        public string? Hotline { get; set; }
        public string Queue { get; set; }
        public string Agent { get; set; }
        public DateTime CallStart { get; set; }
        public string CallStartStr { get => CallStart.ToString(FormatDate.DateTime_121); }
        public DateTime CallEnd { get; set; }
        public string CallEndStr { get => CallEnd.ToString(FormatDate.DateTime_121); }
        public DateTime? CallPickup { get; set; }
        public string CallPickupStr { get => CallPickup.HasValue ? CallPickup.Value.ToString(FormatDate.DateTime_121) : string.Empty; }
        public long HoldTime { get; set; }
        public TimeSpan HoldTimeStr { get => TimeSpan.FromSeconds(HoldTime); }
        public int WaitingTime { get; set; }
        public TimeSpan WaitingTimeStr { get => TimeSpan.FromSeconds(WaitingTime); }
        public int TalkTime { get; set; }
        public TimeSpan TalkTimeStr { get => TimeSpan.FromSeconds(TalkTime); }
        public int RingTime { get; set; }
        public TimeSpan RingTimeStr { get => TimeSpan.FromSeconds(RingTime); }
        public string Status { get; set; }
    }

    public class ExportReportDetaillCallHistoryModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReportDetaillCallHistoryModel> Result { get; set; } = new List<ReportDetaillCallHistoryModel>();

    }

    #endregion

    #region Tổng hợp

    public class ReportChartTotalCallModels
    {
        public List<ReportCallByHourlyModel> ReportCallByHourlyModels { get; set; }
        public List<ReportCallByDayModel> ReportCallByDayModels { get; set; }
    }
    public class ReportTotalCallModels
    {
        public int TotalCall { get; set; }
        public int TotalCallOk { get => TotalCallInOk + TotalCallOutOk; }
        public int? TotalTimeCall { get; set; }
        public int TotalCallIn { get; set; }
        public int TotalCallInOk { get; set; }
        public int TotalCallInNOk { get; set; }
        public int TotalCallOut { get; set; }
        public int TotalCallIVR { get; set; }
        public int TotalCallInQueue { get; set; }
        public int TotalCallMissCall { get; set; }
        public int TotalCallOutOk { get; set; }
        public int TotalCallOutNOk { get; set; }
        public int TotalCallHold { get; set; }
        public int TotalTimeCallIVR { get; set; }
        public int TotalTimeCallInNOkWait { get; set; }
        public int TotalTimeCallOutOkWait { get; set; }
        public int TotalTimeCallOutNOkWait { get; set; }
        public int TotalTimeCallHold { get; set; }
        public int TotalTimeCallWait { get; set; }
        public TimeSpan TotalTimeCallWaitStr { get => TimeSpan.FromSeconds(TotalTimeCallWait); }
        public int TotalTimeCallSpeed { get; set; }
        public int? TotalTimeCallIn { get; set; }
        public TimeSpan TotalTimeCallInStr { get => TotalTimeCallIn.HasValue ? TimeSpan.FromSeconds(TotalTimeCallIn.Value) : TimeSpan.FromSeconds(0); }
        public int TotalTimeCallInOk { get; set; }
        public TimeSpan TotalTimeCallInOkStr { get => TimeSpan.FromSeconds(TotalTimeCallInOk); }
        public int TotalTimeCallOut { get; set; }
        public int TotalTimeCallOutOk { get; set; }
        public int TotalTimeCallOutNOk { get; set; }
        public int TotalTimeCallATT { get; set; }
        public int TotalTimeCallOk { get => (TotalTimeCallInOk + TotalTimeCallOutOk); }
        public TimeSpan TotalTimeCallOkAvgStr { get => (TotalCallIn > 0 && TotalCallOut > 0 && TotalTimeCallOk > 0) ? TimeSpan.FromSeconds(TotalTimeCallOk / (TotalCallIn + TotalCallOut)) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeCallOutStr { get => TimeSpan.FromSeconds(TotalTimeCallOut); }
        public TimeSpan TotalTimeCallOutAvgStr { get => (TotalCallOut > 0 && TotalTimeCallOut > 0) ? TimeSpan.FromSeconds((TotalTimeCallOut / TotalCallOut)) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeCallOutOkStr { get => TimeSpan.FromSeconds(TotalTimeCallOutOk); }
        public TimeSpan TotalTimeCallOkStr { get => TimeSpan.FromSeconds(TotalTimeCallOk); }
        public TimeSpan TotalTimeIVRStr { get => TimeSpan.FromSeconds(TotalTimeCallIVR); }
        public TimeSpan TotalTimeAvgIVRStr { get => (TotalCallIn > 0 && TotalTimeCallIVR > 0) ? TimeSpan.FromSeconds((TotalTimeCallIVR / TotalCallIn)) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeCallOutNOkAvgStr { get => (TotalCallOutNOk > 0 && TotalTimeCallOutNOk > 0) ? TimeSpan.FromSeconds((TotalTimeCallOutNOk / TotalCallOutNOk)) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeAvgStr { get => TotalTimeCall.HasValue ? (TotalCall > 0 && TotalTimeCall.Value > 0) ? TimeSpan.FromSeconds((TotalTimeCall.Value / TotalCall)) : TimeSpan.FromSeconds(0) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeInAvgStr { get => TotalTimeCallIn.HasValue ? (TotalCallIn > 0 && TotalTimeCallIn.Value > 0) ? TimeSpan.FromSeconds((TotalTimeCallIn.Value / TotalCallIn)) : TimeSpan.FromSeconds(0) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeCallATTAvgStr { get => (TotalCallInOk == 0 && TotalCallOutOk == 0) ? TimeSpan.FromSeconds(0) : TimeSpan.FromSeconds(TotalTimeCallATT / (TotalCallInOk + TotalCallOutOk)); }
        public TimeSpan TotalTimeCallHoldAvgStr { get => (TotalCallHold > 0 && TotalTimeCallHold > 0) ? TimeSpan.FromSeconds((TotalTimeCallHold / TotalCallHold)) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeCallHoldStr { get => TimeSpan.FromSeconds(TotalTimeCallHold); }
        public TimeSpan TotalTimeCallWaitAvgStr { get => (TotalCallInQueue > 0 && TotalTimeCallWait > 0) ? TimeSpan.FromSeconds((TotalTimeCallWait / TotalCallInQueue)) : TimeSpan.FromSeconds(0); }
        public TimeSpan TotalTimeCallSpeedAvgStr { get => (TotalCallInOk > 0 && TotalTimeCallSpeed > 0) ? TimeSpan.FromSeconds((TotalTimeCallSpeed / TotalCallInOk)) : TimeSpan.FromSeconds(0); }
        public int TotalWrapupTime { get; set; }
        public TimeSpan TotalWrapupTimeStr { get => TimeSpan.FromSeconds(TotalWrapupTime); }
        public TimeSpan TotalTimeCallAHT { get => (TotalCallInOk > 0 && (TotalTimeCallInOk > 0 || TotalTimeCallHold > 0 || TotalWrapupTime > 0)) ? TimeSpan.FromSeconds((TotalTimeCallInOk + TotalTimeCallHold + TotalWrapupTime) / TotalCallInOk) : TimeSpan.FromSeconds(0); }
        public dynamic PercentCallNOk { get => (TotalCallInNOk > 0 && TotalCallInQueue > 0) ? TimeSpan.FromSeconds((TotalCallInNOk / TotalCallInQueue * 100)) : TimeSpan.FromSeconds(0); }
        public dynamic PercentCallOutNOk { get => (TotalCallInNOk > 0 && TotalCallInQueue > 0) ? TimeSpan.FromSeconds((TotalCallInNOk / TotalCallInQueue * 100)) : TimeSpan.FromSeconds(0); }
    }

    public class ExportReportTotalCallModels : ReportTotalCallModels
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
    }
    #endregion

    #region Hoạt động của TĐV
    public class ReportAgentActivityGroupModel
    {
        public string Agent { get; set; }
        public List<VOC_Ticket> VOC_Tickets { get; set; }
    }
    public class ReportAgentActivityModel
    {
        public string Agent { get; set; }
        public string AgentName { get; set; }
        public int TicketNew { get; set; }
        public int TicketProgress { get; set; }
        public int TicketWaiting { get; set; }
        public int TicketDone { get; set; }
        public int TicketTotal { get; set; }
    }
    public class ExportReportAgentActivityModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReportAgentActivityModel> Result { get; set; } = new List<ReportAgentActivityModel>();

    }
    #endregion

    #region HIệu suất tổng đài theo ngày

    public class ReportCallProductivityModel : ReportTotalCallModels
    {
        public int STT { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_103); }

    }

    public class GroupReportCallProductivityModel
    {
        public DateTime Date { get; set; }
        public List<CallLog> CallLogs { get; set; }
    }

    public class ExportReportCallProductivityModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReportCallProductivityModel> Result { get; set; } = new List<ReportCallProductivityModel>();

    }
    #endregion

    #region Hiệu suất tổng đài theo khoảng thời gian
    public class ReportCallDetailProductivityModel
    {
        public string CallId { get; set; }
        public string? CallDirection { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Queue { get; set; }
        public string? Agent { get; set; }
        public string DateGroup { get => CallStartTime.ToString("yyyy-MM-dd"); }
        public DateTime CallStartTime { get; set; }
        public DateTime CallEndTime { get; set; }
        public DateTime? PickupTime { get; set; }
        public int? LineDuration { get; set; }
        public int? IVRDuration { get; set; }
        public int? ACDDuration { get; set; }
        public int? HandleDuration { get; set; }
        public long? HoldDuration { get; set; }
        public bool IsAnswer { get; set; }
        public int IsNotAnswer { get; set; }
        public int IsTransfer { get; set; }
        public int IsStopInIVR { get; set; }
        public int IsStopInACD { get; set; }
        public int IsMissCall { get; set; }
        public int IsCallAbandon { get; set; }
        public bool IsAgentHangup { get; set; }
        public bool IsAgentBusy { get; set; }
        public bool IsCallerHangup { get; set; }
        public bool IsAgentNoPickup { get; set; }
        public Guid OMS_ID { get; set; }
        public Guid? TicketId { get; set; }
        public DateTime TicketCreate { get; set; }
    }
    public class ReportCallProductivityHourlyGroupModel
    {
        public DateTime Date { get; set; }
        public List<ReportCallDetailProductivityModel> CallDetails { get; set; }
    }
    public class ReportCallProductivityHourlyModel : ReportTotalCallModels
    {
        public DateTime DateStart { get; set; }
        public DateTime DateEnd { get; set; }
        public string DateStr { get => $"{DateStart.ToString("dd-MM-yyyy HH:mm:ss")} - {DateEnd.ToString("dd-MM-yyyy HH:mm:ss")}"; }
        public List<CallLog> CallLogs { get; set; }
    }

    public class ExportReportCallProductivityHourlyModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportDate { get; set; }
        public List<ReportCallProductivityHourlyModel> Result { get; set; } = new List<ReportCallProductivityHourlyModel>();

    }
    public class DateTimeModel
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
    public class ReportTicketProgressCallModel
    {
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
        public Guid CallId { get; set; }
        public Guid TicketId { get; set; }
    }
    public class ReportProgressCallEndModel
    {
        public DateTime CallEndTime { get; set; }
        public Guid CallId { get; set; }
    }
    #endregion
}
