﻿using CTS.Common;

namespace CTS.Model.Voice
{
    public class MissCheckModel
    {
        public int STT { get; set; }
        public string CallId { get; set; }
        public string? Extension { get; set; }
        public string? PhoneNumber { get; set; }
        public string? CallDirection { get; set; }
        public string? CallDirectionStr
        {
            get => CallDirection == UserEventStatusConst.IVR ? "Gọi vào" :
                CallDirection == UserEventStatusConst.CALLOUTBOUND ? "Gọi ra" : 
                CallDirection == UserEventStatusConst.NONE_DIVERT ? "Divert" : "Không xác định";
        }
        public DateTime? CallStartTime { get; set; }
        public string? CallStartTimeStr
        {
            get
            {
                return CallStartTime != null ? CallStartTime.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : String.Empty;
            }
        }
        public DateTime? CallEndTime { get; set; }
        public string? CallEndTimeStr
        {
            get
            {
                return CallEndTime != null ? CallEndTime.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : String.Empty;
            }
        }
        public string? Agent { get; set; }
        public string? Queue { get; set; }
        public string? QueueStr { get; set; }
        public int? Duration { get; set; }
        public string DurationStr { get => Duration.ConvertSecondsToDate(); }
        public string CallStatus { get => IsAnswer ? "Trả lời" : "không trả lời"; }
        public string CallStatusDetail
        {
            //(status.Contains(0) && x.IsStopInIVR == 1) //KH dừng ở IVR
            //|| (status.Contains(1) && x.IsStopInACD == 1 && !x.IsAgentBusy) //KH dừng ở ACD
            //|| (status.Contains(2) && x.IsStopInACD == 1 && x.IsAgentBusy) //TĐV bận, TH: tất cả TĐV không SS hoặc đang nghe số khác gọi đến
            //|| (status.Contains(3) && x.IsAgentHangup)  // TĐV ngắt máy
            //|| (status.Contains(4) && x.IsCallerHangup && !x.IsAgentHangup) //KH ngắt máy
            //|| (status.Contains(5) && !x.IsAgentHangup && x.IsAgentNoPickup) //TĐV không nghe máy
            //|| (status.Contains(6) && x.IsAnswer)

            get
            {
                switch (CallDirection)
                {
                    case UserEventStatusConst.CALLOUTBOUND:
                        if (IsAnswer) return "Kết nối";
                        else return "Không kết nối";
                    case UserEventStatusConst.NONE_DIVERT:
                        if (IsAnswer) return "Trả lời";
                        else return "Không kết nối";
                    case UserEventStatusConst.IVR:
                        if (IsAnswer) return "Trả lời";
                        else if (IsStopInIVR == 1) return "KH dừng ở IVR";
                        //else if (IsStopInACD == 1 && !IsAgentBusy) return "KH dừng ở ACD";
                        //else if (IsStopInACD == 1 && IsAgentBusy) return "TĐV bận";
                        //else if (IsAgentHangup) return "TĐV ngắt máy";
                        //else if (IsCallerHangup && !IsAgentHangup) return "KH ngắt máy";
                        //else if (!IsAgentHangup && IsAgentNoPickup) return "TĐV không nghe máy";
                        else return "Gọi nhỡ";
                    default:
                        return "Gọi nội bộ";
                }

            }
        }
        public bool IsAnswer { get; set; }
        public int IsNotAnswer { get; set; }
        public string? CallEventLog { get; set; }
        public string? Recoding { get; set; }
        public string? DNIS { get; set; }
        public string? Hotline { get; set; }
        public int? HoldTime { get; set; }
        public string? HangupBy { get; set; }
        public Guid? OMS_ID { get; set; }
        public string? FullName { get; set; }
        public string? VOCRequestTypeName { get; set; }
        public Guid? TicketId { get; set; }
        public int IsStopInIVR { get; set; }
        public int IsStopInACD { get; set; }
        public int IsMissCall { get; set; }
        public int IsCallAbandon { get; set; }
        public bool IsAgentBusy { get; set; }
        public bool IsCallerHangup { get; set; }
        public bool IsAgentHangup { get; set; }
        public bool IsAgentNoPickup { get; set; }
    }
}
