﻿namespace CTS.Model.Voice
{
    public class AgentNotifyMissCallModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string? CallId { get; set; }
        public string? Agent { get; set; }
        public string? InternalNumber { get; set; }
        /// <summary>
        /// Đầu số KH gọi vào
        /// </summary>
        public string? Extension { get; set; }
        public DateTime CallTime { get; set; }
        public string? Queue { get; set; }
        public string? CusPhone { get; set; }
        public string? Direction { get; set; }
        public bool IsView { get; set; }
    }

    public class UpdateAgentNotifyMissCallModel
    {
        public Guid Id { get; set; }
        public string? CallId { get; set; }
        public string? Agent { get; set; }
        public string? InternalNumber { get; set; }
        /// <summary>
        /// Đầu số KH gọi vào
        /// </summary>
        public string? Extension { get; set; }
        public DateTime CallTime { get; set; }
        public string? Queue { get; set; }
        public string? CusPhone { get; set; }
        public string? Direction { get; set; }
        public bool IsView { get; set; }
    }
}
