﻿namespace CTS.Model.Voice
{
    public class CallLog
    {
        public string CallId { get; set; }
        public string Domain { get; set; }
        public string? CallDirection { get; set; }
        public string? DNIS { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Extension { get; set; }
        public string? Queue { get; set; }
        public string? Agent { get; set; }
        public DateTime CallStartTime { get; set; }
        public DateTime CallEndTime { get; set; }
        public DateTime? PickupTime { get; set; }
        public int? LineDuration { get; set; }
        public int? IVRDuration { get; set; }
        public int? ACDDuration { get; set; }
        public int? HandleDuration { get; set; }
        public long? HoldDuration { get; set; }
        public string? CallStatus { get; set; }
        public string? CallEventLog { get; set; }
        public bool IsAnswer { get; set; }
        public int IsNotAnswer { get; set; }
        public int IsTransfer { get; set; }
        public int IsStopInIVR { get; set; }
        public int IsStopInACD { get; set; }
        public int IsMissCall { get; set; }
        public int IsCallAbandon { get; set; }
        public bool IsAgentHangup { get; set; }
        public bool IsAgentBusy { get; set; }
        public bool IsCallerHangup { get; set; }
        public bool IsAgentNoPickup { get; set; }
        public Guid? OMS_ID { get; set; }
        public string? HangupBy { get; set; }
        public List<CallLogDetailModel> CallLogDetails { get; set; }
    }

    public class CallLogDetailModel
    {
        public Guid Id { get; set; }
        public string CallId { get; set; }
        public DateTime Time { get; set; }
        public string StatusCode { get; set; }
        public string StatusName { get; set; }
        public string VoiceCode { get; set; }
        public string Agent { get; set; }
        public string Queue { get; set; }
    }
}
