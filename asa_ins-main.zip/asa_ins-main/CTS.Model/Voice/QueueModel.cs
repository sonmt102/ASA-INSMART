﻿using CTS.Common;

namespace CTS.Model.Voice
{
    public class QueueModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string Strategy { get; set; }
        public CallDirection Direction { get; set; }
        public string DirectionStr
        {
            get
            {
                var result = "Gọi vào";
                switch (Direction)
                {
                    case CallDirection.Outbound:
                        result = "Gọi ra";
                        break;
                    case CallDirection.Both:
                        result = "Gọi vào & Gọi ra";
                        break;
                }
                return result;
            }
        }
        public List<QueueAccountModel> QueueAccounts { get; set; }
        public List<QueueExtensionModel> QueueExtensions { get; set; }
    }

    public class QueueAccountModel
    {
        public string UserName { get; set; }
        public string AccountFullName { get; set; }
        public Guid AccountId { get; set; }
        public int? Priority { get; set; }
        public string QueueCode { get; set; }
        public string QueueName { get; set; }
        public Guid QueueId { get; set; }
    }

    public class QueueExtensionModel
    {
        public string ExtensionCode { get; set; }
        public string ExtensionName { get; set; }
        public Guid ExtensionId { get; set; }
    }

    public class CreateQueueModel
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public CallDirection Direction { get; set; }
        public List<Guid> AccountIds { get; set; }
        public List<Guid> ExtensionIds { get; set; }
        public string Strategy { get; set; }
    }

    public class UpdateQueueLevelModel
    {
        public Guid Id { get; set; }
        public List<QueueAccountModel> QueueAccounts { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
