﻿using CTS.Common;

namespace CTS.Model.Voice
{
    public class SupChanspyModel
    {
        public string AgentExten { get; set; }
        public string SUPExtension { get; set; }
        public string SUPUserName { get; set; }
        public FixChanSpyExen FixChanSpyExen { get; set; }
        public string FixExten
        {
            get { return ((int)FixChanSpyExen).ToString(); }
        }
        public string FixPriority { get => "1"; }
        public string FixContext { get => "asa-context"; }
        public string Linkedid { get; set; }
        public string Uniqueid { get; set; }
        public string MICAGENTACCOUNT { get; set; }
        public string MICEXTEN { get; set; }
        public string MICUNIQUEID { get; set; }
        public string QueueInCall { get; set; }
    }
}
