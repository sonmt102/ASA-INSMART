﻿namespace CTS.Model.Voice
{

    public class InternalNumberLoginModel
    {
        public InternalNumberModel Number1 { get; set; }
        public InternalNumberModel Number2 { get; set; }
    }

    public class InternalNumberModel
    {
        public int STT { get; set; }
        public string Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string? Domain { get; set; }
        public int? Socket_Port { get; set; }
        public string Socket { get => $"wss://{Domain}:{Socket_Port}/ws"; }
        public string? Transport { get; set; }
        public string? Context { get; set; }
        public bool UseIPPhone { get; set; }
        public bool UseSoftPhone { get; set; }
        public bool UseWebPhone { get; set; }
    }

    public class CreateInternalNumberModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        //public bool UseIPPhone { get; set; }
        //public bool UseSoftPhone { get; set; }
        //public bool UseWebPhone { get; set; }
        public string Transport { get; set; } = "transport-udp-nat";
        public string Context { get; set; } = "from-internal";
        public int Contacts { get => 1; }
        public string Allow { get => "g722, alaw, ulaw, opus"; }
    }


    public class UpdateInternalNumberModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        //public bool UseIPPhone { get; set; }
        //public bool UseSoftPhone { get; set; }
        //public bool UseWebPhone { get; set; }
        public string Transport { get; set; } = "transport-udp-nat";
        public string Context { get; set; } = "from-internal";
    }

    public class EndpointInternalNumberModel
    {
        public string UserName { get; set; }
        public string Transport { get; set; }
        public string Context { get; set; }
    }
}
