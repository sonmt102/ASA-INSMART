﻿namespace CTS.Model.Voice
{
    public class CallEventModel
    {
        public string Channel { get; set; }
        public string Domain { get; set; }
        /// <summary>
        /// Đầu số KH gọi vào, ví dụ: 1900, 1800
        /// </summary>
        public string Trunk { get; set; }
        public string Direction { get; set; }
        /// <summary>
        /// Call Id
        /// </summary>
        public string CallId { get; set; }
        public string LinkedId { get; set; }
        /// <summary>
        /// Số điện thoại của KH
        /// </summary>
        public string CusPhone { get; set; }
        /// <summary>
        /// Agent nhận cuộc gọi
        /// </summary>
        public string AgentAccount { get; set; }
        public string AgentExten { get; set; }
        /// <summary>
        /// Trạng thái cuộc gọi, ví dụ: IVR
        /// </summary>
        public string CallStatus { get; set; }
        public string Queue { get; set; }
        public DateTime? CallTime { get; set; }
        public long HoldTime { get; set; } = 0;
        public string RingTime { get; set; }
        public string AnswerTime { get; set; }
        public string CallType { get; set; } = "internal";
    }
}
