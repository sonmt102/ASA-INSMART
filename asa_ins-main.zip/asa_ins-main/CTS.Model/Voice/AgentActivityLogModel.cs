﻿namespace CTS.Model.Voice
{
    public class AgentActivityLogModel
    {
        public Guid? AgentId { get; set; }
        public string? AgentName { get; set; }
        public string? QueueName { get; set; }
        public string? StatusCode { get; set; }
        public string? StatusName { get; set; }
        public DateTime DateStart { get; set; }
        public int TotalDuration { get; set; } = 0;
    }
}
