﻿namespace CTS.Model.Voice
{
    public class AnswerPopupParamModel
    {
        public string? CusPhone { get; set; }
        public string? Queue { get; set; }
        public string? CallId { get; set; }
        public string? AgentAccount { get; set; }
        public string? AgentExten { get; set; }
        public string? Extension { get; set; }
        public DateTime CallTime { get; set; }
    }
}
