﻿namespace CTS.Model.Voice
{
    public class AgentStatusCategoryModel
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public bool IsPause { get; set; }
        public bool IsAllowAgentHandler { get; set; }
        public bool IsAllowSupHandler { get; set; }
    }
}
