﻿using Microsoft.AspNetCore.Http;

namespace CTS.Model.Voice
{
    public class IVRRecordModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string FileName { get; set; }
        public string RealFileName { get; set; }
        public string Content { get; set; }
    }

    public class CreateIVRRecordModel
    {
        public IFormFile? File { get; set; }
        public string RealFileName { get; set; }
        public string FileName { get; set; }
        public string Content { get; set; }
    }
}
