﻿using CTS.Common;

namespace CTS.Model.SUP
{
    public class QueueModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public int Account { get; set; } = 0;
        public int Busy { get; set; } = 0;
        public int Pause { get; set; } = 0;
        public int Waiting { get; set; }
        public int Ready { get; set; }
        public int NotReady { get; set; }
        public List<AgentModel> Agents { get; set; } = new List<AgentModel>();
    }
    public class QueueMemberModel
    {
        public string Name { get; set; }
        public int TotalAgents { get => Agents.Count(); }
        public int TotalAgentAvailable { get => Agents.Where(x => x.Status == 0).Count(); }
        public int TotalAgentUnAvailable { get => Agents.Where(x => x.Status == 1).Count(); }
        public List<MemberModel> Agents { get; set; } = new List<MemberModel>();
    }
    public class MemberModel
    {
        public string QueueName { get; set; }
        public string MemberName { get; set; }
        public string FullName { get; set; }
        public string Extension { get; set; }
        public string StatusCode { get; set; }
        public string StatusName { get; set; }
        public int StatusTime { get; set; }
        public int Status { get; set; }
        public AgentStatusCall? AgentStatusCall { get; set; }
        public string? QueueInCall { get; set; } = string.Empty;
        public string? CusPhone { get; set; } = string.Empty;
        public string? Channel { get; set; } = string.Empty;
        public string? UniqueId { get; set; } = string.Empty;
        public string? LinkedId { get; set; } = string.Empty;
        public DateTime? CallTime { get; set; }
        public bool? InCallQueue { get; set; }
        public bool? InWaitingQueue { get; set; }
    }
}
