﻿namespace CTS.Model.SUP
{
    public class ChangeStatusAgentInQueueModel
    {
        public Guid AgentId { get; set; }
        public Guid QueueId { get; set; }
        public bool IsPause { get; set; }
        public bool IsPrimary { get; set; } = false;
        public string Extension { get; set; }
    }
}
