﻿using CTS.Common;

namespace CTS.Model.SUP
{
    public class AgentModel
    {
        public Guid Id { get; set; }
        public string FullName { get; set; }
        public string UserName { get; set; }
        public string Extension { get; set; }
        public bool IsLogin { get; set; }
        public List<AgentQueueModel> Queues { get; set; }
        public AgentStatusCall AgentStatusCall { get; set; }
        public bool InCallQueue { get; set; }
        public bool InWaitingQueue { get; set; }
        /// <summary>
        /// Khi có cuộc gọi hoặc đang ring thì tên queue ở đây
        /// </summary>
        public string QueueInCall { get; set; }
        public string CusPhone { get; set; }
        public DateTime? CallTime { get; set; }
        /// <summary>
        /// Channel cuộc gọi đang diễn ra
        /// </summary>
        public string? Channel { get; set; }
        public bool IsPrimary { get; set; }

    }

    public class AgentQueueModel
    {
        public Guid QueueId { get; set; }
        public string Name { get; set; }
        public bool IsPause { get; set; }
    }


    public class SearchAgentModel
    {
        public Guid? QueueId { get; set; }
        public string? Agent { get; set; }
    }
    public class AgentAccountModel
    {
        public Guid Id { get; set; }
        public string FullName { get; set; }
        public string UserName { get; set; }
        public string Extension { get; set; }

    }
}
