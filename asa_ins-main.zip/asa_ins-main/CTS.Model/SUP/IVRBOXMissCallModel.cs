﻿namespace CTS.Model.SUP
{
    public class IVRBOXMissCallModel
    {
        public int StopInACD { get; set; }
        public int MissCall { get; set; }
    }
}
