﻿using CTS.Common;

namespace CTS.Model.SUP
{
    public class ChanSpyModel
    {
        /// <summary>
        /// Tài khoản của SUP đi nghe xen
        /// </summary>
        public string SUPUserName { get; set; }
        /// <summary>
        /// Số nội bộ của SUP đi nghe xenq
        /// </summary>
        public string SUPExtension { get; set; }
        /// <summary>
        /// Số nội bộ bị nghe xen
        /// </summary>
        public string Extension { get; set; }
        public string FixContext { get => "asa-context"; }
        /// <summary>
        /// 101 nghe xen
        /// 102 nhắc nhở
        /// 103 hội thoại
        /// </summary>
        public string FixExten
        {
            get { return ((int)FixChanSpyExen).ToString(); }
        }
        public FixChanSpyExen FixChanSpyExen { get; set; }

        public string FixPriority { get => "1"; }
    }
}
