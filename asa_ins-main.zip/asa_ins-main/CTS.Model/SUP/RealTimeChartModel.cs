﻿namespace CTS.Model.SUP
{
    public class RealTimeChartModel
    {
        public DateTime Date { get; set; }
        public int IVR { get; set; }
        public int Call { get; set; }
    }
}
