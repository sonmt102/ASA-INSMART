﻿using CTS.Common;

namespace CTS.Model.SUP
{
    public class SelectQueueModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public CallDirection CallDirection { get; set; }
        public string Direction
        {
            get
            {
                return CallDirection switch
                {
                    CallDirection.Inbound => "Gọi vào",
                    CallDirection.Outbound => "Gọi ra",
                    CallDirection.Both => "Gọi vào & gọi ra",
                    _ => "",
                };
            }
        }
    }
}
