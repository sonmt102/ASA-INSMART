﻿using CTS.Common;
using System.Runtime.CompilerServices;

namespace CTS.Model.Intergration.VoiceBot
{
    public class TicketModel
    {
        public string CustomerName { get; set; }
        public string CustomerPhone { get; set; }
        public string Email { get; set; }
    }
}
