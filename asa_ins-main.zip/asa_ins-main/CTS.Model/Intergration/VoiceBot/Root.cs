﻿using Newtonsoft.Json;

namespace CTS.Model.Intergration.VoiceBot
{

    public class Report
    {
        /// <summary>
        /// Tên công ty bảo hiểm
        /// </summary>
        [JsonProperty("reports.company_name")]
        public string? CompanyName { get; set; }
        /// <summary>
        /// Tên khách hàng
        /// </summary>
        [JsonProperty("reports.customer_name")]
        public string? HoTenKhachHang { get; set; }
        /// <summary>
        /// Số hợp đồng bảo hiểm của khách hàng
        /// </summary>
        [JsonProperty("reports.customer_ctrID")]
        public string? SoHopDong { get; set; }
        /// <summary>
        /// Yêu cầu của khách hàng
        /// </summary>
        [JsonProperty("reports.customer_req")]
        public string? NoiDungYeucau { get; set; }


        [JsonProperty("reports.customer_ID")]
        public string? ReportsCMND { get; set; }
        [JsonProperty("reports.customer_bdate")]
        public string? ReportsDOB { get; set; }
    }

    public class BotPhiNhanThoModel
    {
        [JsonProperty("conversation")]
        public BotPhiNhanTho_ConversationModel Conversation { get; set; }
    }

    public class BotPhiNhanTho_ConversationModel
    {
        public string? event_type { get; set; }
        public string? conversation_id { get; set; }
        /// <summary>
        /// Số điện thoại khách hàng
        /// </summary>
        [JsonProperty("customer_phone")]
        public string? CustomerPhone { get; set; }
        public long? create_at { get; set; }
        public int? sip_code { get; set; }
        public Report? report { get; set; }
        [JsonProperty("system.scenario_id")]
        public string? BotScenarioId { get; set; }
    }



    public class Root
    {
        public string? event_type { get; set; }
        public string? conversation_id { get; set; }
        /// <summary>
        /// Số điện thoại khách hàng
        /// </summary>
        [JsonProperty("customer_phone")]
        public string? CustomerPhone { get; set; }
        public long? create_at { get; set; }
        public int? sip_code { get; set; }
        public Report? report { get; set; }
        [JsonProperty("system.scenario_id")]
        public string? BotScenarioId { get; set; }

    }


    public class Bot2KYCModel
    {

        [JsonProperty("event_type")]
        public string EventType { get; set; }
        [JsonProperty("conversation_id")]
        public string ConversationId { get; set; }
        [JsonProperty("customer_phone")]
        public string CustomerPhone { get; set; }
        [JsonProperty("report")]
        public Bot2KYC_ReportModel Report { get; set; }
    }

    public class Bot2KYC_ReportModel
    {
        [JsonProperty("reports.customer_req")]
        public string? CustomerReq { get; set; }
    }

}
