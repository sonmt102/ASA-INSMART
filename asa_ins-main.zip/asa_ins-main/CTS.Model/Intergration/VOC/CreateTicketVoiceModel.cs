﻿using CTS.Common;
using CTS.Model.Intergration.VoiceBot;
using System.Globalization;

namespace CTS.Model.Intergration.VOC
{

    //[21/05/2023 10:12:14] Sơn Zai: Bot 02:
    //reports.TenKH
    //reports.NgaySinh
    //reports.CanCuoc
    //reports.SoHD
    //reports.YeuCau
    //[21 / 05 / 2023 10:12:19] Sơn Zai: bot 03:
    //reports.SoHD
    //reports.TenKH
    //reports.YeuCau
    //[21 / 05 / 2023 10:17:53] Nguyễn Công Bình: Gạch nốt cho anh bot 1
    //[21/05/2023 10:18:01] Nguyễn Công Bình: Đối chiếu luôn em ạ
    //[21 / 05 / 2023 10:19:58] Sơn Zai: Bot KYC:
    //reports.TenCty : tên công ty KH tham gia
    //reports.TenKH: tên khách hàng
    //reports.SoHD :  số hợp đồng
    //[21 / 05 / 2023 10:20:19] Sơn Zai: bot 01:
    //reports.YeuCau
    public class CreateTicketVoiceModel
    {
        public string CustomerPhone { get; set; }
        public string? CustomerName { get; set; }
        public string? CustomerCompany { get; set; }
        public string? Contract { get; set; }
        public string? Conversation { get; set; }
        public string? YeuCau { get; set; }
        public string? DOBStr { get; set; }
        public string? BotScenarioId { get; set; }
        public DateTime? DOB
        {
            get
            {
                if (!string.IsNullOrEmpty(DOBStr) && DateTime.TryParseExact(DOBStr, FormatDate.DateTime_103,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? CMND { get; set; }

        public string TicketDateStr { get; set; }
        public DateTime? TicketDate
        {
            get
            {
                if (!string.IsNullOrEmpty(TicketDateStr) && DateTime.TryParseExact(TicketDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
    }
}
