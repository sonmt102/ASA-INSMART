﻿namespace CTS.Model.General
{
    public class UserRefreshLogin
    {
        public string UserName { get; set; }
        public string OldToken { get; set; }
    }
}
