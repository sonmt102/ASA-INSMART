﻿namespace CTS.Model.General
{
    public class MICConfigModel
    {
        public string APIKEY { get; set; }
        public string MA_DVI { get; set; }
        public string Pass { get; set; }
        public string Url { get; set; }
    }
}
