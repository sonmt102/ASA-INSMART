﻿namespace CTS.Model.General
{
    public class RabbitQueueSettingModel
    {
        public string HostName { get; set; }
        public string VirtualHost { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public ushort Port { get; set; }
        public string Exchange { get; set; }
        public string RoutingKey_ZaloData { get; set; }
        public string QueueName_ZaloData { get; set; }
        public string Exchange_Zalo_Chat { get; set; }
        public string QueueName_Zalo_Chat { get; set; }
        public string RoutingKey_Zalo_Chat { get; set; }
        public ClaimSubmission ClaimSubmission { get; set; }
    }

    public class ClaimSubmission
    {
        public int RetryCount { get; set; }
        public int Interval { get; set; }
    }
}
