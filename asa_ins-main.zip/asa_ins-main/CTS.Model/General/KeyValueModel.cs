﻿namespace CTS.Model.General
{
    public class KeyValueModel
    {
        public Guid GuidValue { get; set; }
        public string StringValue { get; set; }
    }
}
