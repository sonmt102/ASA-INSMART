﻿namespace CTS.Model.General
{
    public class ApplicationKeyModel
    {
        public bool UseTicket { get; set; }
        public bool Use2Extension { get; set; }
        public bool UseFacebook { get; set; }
        public bool UseZalo { get; set; }
        public bool UseChat { get; set; }
    }
}
