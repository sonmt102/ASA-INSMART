﻿using CTS.Common;

namespace CTS.Model.General
{
    public class CreateExportLogModel
    {
        public ExportExcelLogType Type { get; set; }
        public string CreateBy { get; set; }
        public DateTime CreateDate { get; set; }
        public string Time { get; set; }
        public string FileName { get; set; }
        public ExportExcelLogStatus Status { get; set; }
    }
}
