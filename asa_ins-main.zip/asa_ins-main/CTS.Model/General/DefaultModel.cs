﻿using CTS.Common;

namespace CTS.Model.General
{
    public abstract class DefaultModel
    {
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CreatedBy { get; set; }
    }
}
