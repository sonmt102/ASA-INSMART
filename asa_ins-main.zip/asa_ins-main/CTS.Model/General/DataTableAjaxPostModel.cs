﻿using CTS.Common;

namespace CTS.Model.General
{
    public class DataTablePostModel
    {
#pragma warning disable IDE1006 // Naming Styles
        public int draw { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public int start { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public int length { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public List<Column> columns { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public Search search { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public List<Order> order { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Column
    {
#pragma warning disable IDE1006 // Naming Styles
        public string data { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public string name { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public bool searchable { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public bool orderable { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public Search search { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Search
    {
#pragma warning disable IDE1006 // Naming Styles
        public string value { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public string regex { get; set; }
#pragma warning restore IDE1006 // Naming Styles
        public Guid? GuidValue { get; set; }
        public List<Guid> GuidValues { get; set; }
        public Guid? GuidValue1 { get; set; }
        public Guid? GuidValue2 { get; set; }
        public Guid? GuidValue3 { get; set; }
        public string StringValue1 { get; set; }
        public string StringValue2 { get; set; }
        public string StringValue3 { get; set; }
        public string StringValue4 { get; set; }
        public string StringValue5 { get; set; }
        public string StringValue6 { get; set; }
        public string StringValue7 { get; set; }
        public string StringValue8 { get; set; }
        public string StringValue9 { get; set; }
        public string StringValue10 { get; set; }
        public string StringValue11 { get; set; }
        public string StringValue12 { get; set; }
        public string StringValue13 { get; set; }
        public string StringValue14 { get; set; }
        public string StringValue15 { get; set; }
        public string StringValue16 { get; set; }
        public string StringValue17 { get; set; }
        public string StringValue18 { get; set; }
        public string StringValue19 { get; set; }
        public string StringValue20 { get; set; }
        public string StringValue21 { get; set; }
        public string StringValue22 { get; set; }
        public string StringValue23 { get; set; }
        public string StringValue24 { get; set; }
        public string StringValue25 { get; set; }
        public string StringValue26 { get; set; }
        public string StringValue27 { get; set; }
        public int? IntValue1 { get; set; }
        public int? IntValue2 { get; set; }
        public int? IntValue3 { get; set; }
        public bool? BoolValue1 { get; set; }
        public bool? BoolValue2 { get; set; }
        public bool? BoolValue3 { get; set; }
        public bool? BoolValue4 { get; set; }
        public List<Guid> ListGuid1 { get; set; }
        public List<string> ListString1 { get; set; }
        public List<string> ListString2 { get; set; }
        public List<string> ListString3 { get; set; }
        public List<string> ListString4 { get; set; }
        public List<int> ListInt1 { get; set; }
        public List<VOCTicketStatus> ListEnum1 { get; set; }
        public List<OPHandler_Detail_Status> OPStatus { get; set; }
    }

    public class Order
    {
#pragma warning disable IDE1006 // Naming Styles
        public int column { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public string dir { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class DataTableResultModel
    {
#pragma warning disable IDE1006 // Naming Styles
        public int draw { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public int recordsTotal { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public int recordsFiltered { get; set; }
#pragma warning restore IDE1006 // Naming Styles
#pragma warning disable IDE1006 // Naming Styles
        public Object data { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }
}
