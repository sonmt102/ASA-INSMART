﻿namespace CTS.Model.General
{
    public class ActiveLogMatchingModel
    {
        public Guid AccountId { get; set; }
        public Guid MatchingId { get; set; }
        public bool HadPauseRecord { get; set; } = false;
        public bool HadUnPauseRecord { get; set; } = false;
        private DateTime? _LoginDate;
        public DateTime LoginDate { get => _LoginDate ?? DateTime.Now; set => _LoginDate = value; }
        private DateTime? _UnPauseDate;
        public DateTime UnPauseDate { get => _UnPauseDate ?? DateTime.Now; set => _UnPauseDate = value; }
        private DateTime? _PauseDate;
        public DateTime PauseDate { get => _PauseDate ?? DateTime.Now; set => _PauseDate = value; }

    }
}
