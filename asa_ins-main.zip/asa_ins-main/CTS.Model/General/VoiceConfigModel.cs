﻿namespace CTS.Model.General
{
    public class VoiceConfigModel
    {
        public string Domain { get; set; }
        public int Socket_Port { get; set; }
        public string Host { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int SSH_Port { get; set; }
        public string SSH_UserName { get; set; }
        public string SSH_Password { get; set; }
        /// <summary>
        /// File của crm
        /// </summary>
        public string IVRRecordCRMPath { get; set; }
        /// <summary>
        /// File của voice
        /// </summary>
        public string IVRRecordVoicePath { get; set; }
        /// <summary>
        /// Đường dẫn lưu trữ file ghi âm trên server voice
        /// </summary>
        public string CallRecordingPath { get; set; }
        public SSH_CRMModel SSH_CRM { get; set; }

    }

    public class SSH_CRMModel
    {
        public string IP { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
