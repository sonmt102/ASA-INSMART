﻿using Newtonsoft.Json;
using CTS.Common;

namespace CTS.Model.General
{
    public class GeneralSettingModel
    {
        public string[] AllowedAuthOrigins { get; set; }
        public string ApplicationKey { get; set; }
        public GeneralSettingRedis RedisConfig { get; set; }
        public string Url { get; set; }
        public string UploadMailAttachPath { get; set; }
        public ApplicationKeyModel Application { get => JsonConvert.DeserializeObject<ApplicationKeyModel>(Helper.Decrypt(ApplicationKey)); }
        public string EMUploadPath { get; set; }
        public List<AccountIntergration> Intergrations { get; set; }
    }

    public class GeneralSettingRedis
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
    }


    public class AccountIntergration
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
