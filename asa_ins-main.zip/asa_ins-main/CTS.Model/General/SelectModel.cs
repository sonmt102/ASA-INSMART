﻿using CTS.Common;

namespace CTS.Model.General
{
    public class SelectModel
    {
        public string id { get; set; }
        public string text { get; set; }
        public bool selected { get; set; }
        public int OrderIndex { get; set; }
        public string Type { get; set; }
        public Guid? GuidValue { get; set; }
        public string Text1 { get; set; }
        public DateTime? DateValue { get; set; }
        public QALoaiTieuChi LoaiTieuChi { get; set; }
    }
}
