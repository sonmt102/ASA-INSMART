﻿using CTS.Common;
using CTS.Model.General;

namespace CTS.Model.EM
{
    public class TemplateModel : DefaultModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public EMSMSTemplateType Type { get; set; }
        public string TypeStr
        {
            get
            {
                return Type switch
                {
                    EMSMSTemplateType.Email => "Gửi Email",
                    EMSMSTemplateType.SMS => "Gửi SMS",
                    _ => string.Empty,
                };
            }
        }
        public string Subject { get; set; }
        public string Content { get; set; }
        public string ContentSMS { get; set; }
        public List<TemplateDetailFieldMapModel> FieldMaps { get; set; }
    }

    public class TemplateDetailFieldMapModel
    {
        public string Name { get; set; }
        public bool Delete { get; set; }
        public int OrderIndex { get; set; }
    }
}
