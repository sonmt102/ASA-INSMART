﻿namespace CTS.Model.EM
{
    public class SplitLinkModel
    {
        public string Data { get; set; }
        public string Link
        {
            get
            {
                if (!string.IsNullOrEmpty(Data))
                {
                    string[] arr = Data.Split('$');
                    if (arr != null)
                    {
                        return arr[0];
                    }
                    return Data;
                }
                return Data;
            }
        }
        public string Title
        {
            get
            {
                if (!string.IsNullOrEmpty(Data))
                {
                    string[] arr = Data.Split('$');
                    if (arr != null)
                    {
                        if (arr.Length > 1)
                        {
                            return arr[1];
                        }
                        else
                        {
                            return arr[0];
                        }
                    }
                    return Link;
                }
                return Link;
            }
        }
    }
}
