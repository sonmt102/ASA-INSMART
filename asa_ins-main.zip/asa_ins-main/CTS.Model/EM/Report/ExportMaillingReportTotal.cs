﻿using CTS.Common;

namespace CTS.Model.EM.Report
{
    public class ExportMaillingReportTotalModel
    {
        public List<CampaignListModel> ListItem { get; set; }
    }
    public class CampaignListModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Subject { get; set; }
        public string TypeCode { get; set; }
        public DateTime? AutoDate { get; set; }
        public string AutoDateStr { get => AutoDate.HasValue ? AutoDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public int DataCount { get; set; }
        /// <summary>
        /// Đã gửi
        /// </summary>
        public int TotalSent { get; set; }
        public int TotalRead { get; set; }
        public int SuccessCount { get; set; }
        public int FailCount { get; set; }
        public bool IsActive { get; set; }

        // Template
        public string Title { get; set; }
        public string Content { get; set; }
        // End Template

        //public SendMailCampaignStatus CampaignStatus { get; set; }
        public string Note { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_103); }
        public List<ListFieldMapModel> FieldMaps { get; set; }
    }
}
