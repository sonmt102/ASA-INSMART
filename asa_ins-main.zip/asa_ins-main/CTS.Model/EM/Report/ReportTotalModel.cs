﻿namespace CTS.Model.EM.Report
{
    public class ReportTotalModel
    {
        public int STT { get; set; }
        public Guid FileId { get; set; }
        public string FileName { get; set; }
        public string TemplateName { get; set; }
        public int DaGui { get; set; }
        public int ThanhCong { get; set; }
        public int Loi { get; set; }
        public int DaXem { get; set; }
        public int Tong { get; set; }
    }
}
