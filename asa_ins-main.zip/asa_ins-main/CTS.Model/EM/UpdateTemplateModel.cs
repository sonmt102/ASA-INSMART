﻿using CTS.Common;

namespace CTS.Model.EM
{
    public class UpdateTemplateModel
    {
        public string Name { get; set; }
        public EMSMSTemplateType Type { get; set; }
        public string? Subject { get; set; }
        public string Content { get; set; }
        public string ContentSMS { get; set; }
        public List<UpdateTemplateFieldModel> FieldMaps { get; set; }
    }
    public class UpdateTemplateFieldModel
    {
        public string Name { get; set; }
        public EMSMSTemplateType Type { get; set; }
        public bool Delete { get; set; }
    }
}
