﻿using CTS.Common;

namespace CTS.Model.EM
{
    public class ListFieldMapModel
    {
        public int Index { get; set; }
        public string Name { get; set; }
        public EMSMSTemplateType Type { get; set; }
        public string FieldColumn
        {
            get
            {
                switch (Type)
                {
                    case EMSMSTemplateType.Email:
                        return Index switch
                        {
                            0 => "STT",
                            1 => "Email",
                            2 => "Attachs",
                            _ => $"Field{Index - 2}"
                        };
                    case EMSMSTemplateType.SMS:
                        return Index switch
                        {
                            0 => "STT",
                            1 => "PhoneNumber",
                            _ => $"Field{Index - 1}"
                        };
                    default:
                        return Index switch
                        {
                            0 => "STT",
                            1 => "Email",
                            2 => "Attachs",
                            _ => $"Field{Index - 2}"
                        };
                }

            }
        }
    }
}
