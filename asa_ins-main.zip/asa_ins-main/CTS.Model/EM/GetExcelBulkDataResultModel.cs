﻿namespace CTS.Model.EM
{
    public class GetExcelBulkDataResultModel
    {
        public List<ListFieldMapModel> Columns { get; set; }
        public object Data { get; set; }
    }
}
