﻿using CTS.Common;
using CTS.Model.General;

namespace CTS.Model.EM
{
    public class CustomerListEmailModel : DefaultModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string? Email { get; set; }
        public string? Attachs { get; set; }
        public string? Field1 { get; set; }
        public string? Field2 { get; set; }
        public string? Field3 { get; set; }
        public string? Field4 { get; set; }
        public string? Field5 { get; set; }
        public string? Field6 { get; set; }
        public string? Field7 { get; set; }
        public string? Field8 { get; set; }
        public string? Field9 { get; set; }
        public string? Field10 { get; set; }
        public string? Field11 { get; set; }
        public string? Field12 { get; set; }
        public string? Field13 { get; set; }
        public string? Field14 { get; set; }
        public string? Field15 { get; set; }
        public string? Field16 { get; set; }
        public string? Field17 { get; set; }
        public string? Field18 { get; set; }
        public string? Field19 { get; set; }
        public string? Field20 { get; set; }
        public string? Field21 { get; set; }
        public string? Field22 { get; set; }
        public string? Field23 { get; set; }
        public string? Field24 { get; set; }
        public string? Field25 { get; set; }
        public string? Field26 { get; set; }
        public string? Field27 { get; set; }
        public string? Field28 { get; set; }
        public string? Field29 { get; set; }
        public string? Field30 { get; set; }
        public string? Field31 { get; set; }
        public bool IsSent { get; set; }

        /// <summary>
        /// Is user Read
        /// </summary>
        public bool IsRead { get; set; }

        /// <summary>
        /// Send success or unsuccess
        /// </summary>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// Error when send
        /// </summary>
        public string? Error { get; set; }
        public string? FileName { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? UpdatedDateStr { get => UpdatedDate.HasValue ? UpdatedDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }

    }

    public class CustomerListSMSModel : DefaultModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Field1 { get; set; }
        public string? Field2 { get; set; }
        public string? Field3 { get; set; }
        public string? Field4 { get; set; }
        public string? Field5 { get; set; }
        public string? Field6 { get; set; }
        public string? Field7 { get; set; }
        public string? Field8 { get; set; }
        public string? Field9 { get; set; }
        public string? Field10 { get; set; }
        public string? Field11 { get; set; }
        public string? Field12 { get; set; }
        public string? Field13 { get; set; }
        public string? Field14 { get; set; }
        public string? Field15 { get; set; }
        public string? Field16 { get; set; }
        public string? Field17 { get; set; }
        public string? Field18 { get; set; }
        public string? Field19 { get; set; }
        public string? Field20 { get; set; }
        public string? Field21 { get; set; }
        public string? Field22 { get; set; }
        public string? Field23 { get; set; }
        public string? Field24 { get; set; }
        public string? Field25 { get; set; }
        public string? Field26 { get; set; }
        public string? Field27 { get; set; }
        public string? Field28 { get; set; }
        public string? Field29 { get; set; }
        public string? Field30 { get; set; }
        public string? Field31 { get; set; }
        public bool IsSent { get; set; }

        /// <summary>
        /// Is user Read
        /// </summary>
        public bool IsRead { get; set; }

        /// <summary>
        /// Send success or unsuccess
        /// </summary>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// Error when send
        /// </summary>
        public string? Error { get; set; }
        public string? FileName { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? UpdatedDateStr { get => UpdatedDate.HasValue ? UpdatedDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }

    }
}
