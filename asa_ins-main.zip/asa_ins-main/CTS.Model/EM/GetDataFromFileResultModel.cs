﻿using System.Data;

namespace CTS.Model.EM
{
    public class GetDataFromFileResultModel
    {
        public string[] ColumnNames { get; set; }
        public DataTable? Table { get; set; }
        public string FileName { get; set; }
        /// <summary>
        /// 1: sai định dạng
        /// 2: trùng email trong file
        /// </summary>
        public int InvalidType { get; set; } = 0;
        public List<string> InvalidEmails { get; set; }
        public string InvalidEmailString { get => string.Join("; ", InvalidEmails); }
    }
}
