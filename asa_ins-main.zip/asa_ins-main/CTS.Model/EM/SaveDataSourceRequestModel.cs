﻿namespace CTS.Model.EM
{
    public class SaveDataSourceRequestModel
    {
        public string FileName { get; set; }
        public string FileNameRandom { get; set; }
        public string TempFolder { get; set; }
        public string FileExtension { get; set; }
        public string FileContentType { get; set; }
        public string UploadType { get; set; }
        public Guid TemplateId { get; set; }
        public bool CheckAll { get; set; }
        public bool CheckFile { get; set; }
    }
}
