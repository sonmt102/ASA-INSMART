﻿using CTS.Common;
using CTS.Model.General;

namespace CTS.Model.EM.Config
{
    public class ListConfigModel : DefaultModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Host { get; set; }
        public int? Port { get; set; }
        public bool SSLoTLS { get; set; }
        public bool UseDefaultCredentials { get; set; }
        public bool IsActive { get; set; }
        public string? EmailName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public EMSMSTemplateType Type { get; set; }
        public string TypeStr
        {
            get
            {
                return Type switch
                {
                    EMSMSTemplateType.Email => "Gửi Email",
                    EMSMSTemplateType.SMS => "Gửi SMS",
                    _ => string.Empty,
                };
            }
        }
    }
}
