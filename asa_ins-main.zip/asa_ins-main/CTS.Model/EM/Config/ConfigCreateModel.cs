﻿using CTS.Common;

namespace CTS.Model.EM.Config
{
    public class ConfigCreateModel
    {
        public string? EmailName { get; set; }
        public string Name { get; set; }
        public string TemplateTypeStr { get; set; }
        public string Host { get; set; }
        public int Port { get; set; }
        public bool SSLoTLS { get; set; }
        public bool UseDefaultCredentials { get; set; }
        public bool IsActive { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public EMSMSTemplateType Type { get; set; }
    }
}
