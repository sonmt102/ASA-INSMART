﻿namespace CTS.Model.EM
{
    public class ImportHistoryModel
    {
        public string FileName { get; set; }
        public string FileNameRandom { get; set; }
        public string TempFolder { get; set; }
        public string FileExtension { get; set; }
        public string FileContentType { get; set; }
        public string UploadType { get; set; }
        public Guid TemplateId { get; set; }
    }

    public class FileInTemplateModel
    {
        public Guid? TemplateId { get; set; }
        public string FileName { get; set; }
        public Guid? HistoryId { get; set; }
        public int DataCount { get; set; }
        public int Success { get; set; }
        public int SuccessPercent { get => (Success * 100) / DataCount; }
        public int Error { get; set; }
        public int ErrorPercent { get => (Error * 100) / DataCount; }
        public bool IsSending { get; set; }

    }
}
