﻿using CTS.Domain.KMS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Model.KMS
{
    public class KMSPostModel
    {
        public int? STT { get; set; }
        public Guid Id { get; set; }
        public string? PostTitle { get; set; }
        public string? PostUrl { get; set; }
        public string? PostShortContent { get; set; }
        public string? PostContent { get; set; }
        public string? PostAvatar { get; set; }
        public object? PostDocument { get; set; }
        public List<string>? PostCategories { get; set; }
        public List<string>? CategoryIds { get; set; }
        public DateTime? PostExpired { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsApproved { get; set; }
        public bool IsFeatured { get; set; }
        public bool EnableComment { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString("dd/MM/yyyy"); }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? TotalViews { get; set; }
        public virtual ICollection<KMS_Posts_Category>? KMS_Posts_Categories { get; set; }
        public virtual KMS_Posts_Views? KMS_Posts_Views { get; set; }
    }
    public class CreateKMSPostModel
    {
        public Guid? Id { get; set; }
        public string? PostTitle { get; set; }
        public string? PostShortContent { get; set; }
        public string? PostContent { get; set; }
        public string? PostAvatar { get; set; }
        public List<KMSPostDocumentModel>? PostDocument { get; set; }
        public string? PostExpired { get; set; }
        public List<string>? CategoryIds { get; set; }
        public bool EnableComment { get; set; }
        public bool IsFeatured { get; set; }
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
    }

    public class KMSPostDocumentModel
    {
        public string phash { get; set; }
        public string name { get; set; }
        public string hash { get; set; }
        public string mime { get; set; }
        public string size { get; set; }
        public string baseUrl { get; set; }
        public string url { get; set; }
        public string path { get; set; }
    }

    public class KMSPostDetailParamModel
    {
        public Guid? Id { get; set;}
        public string? Slug { get; set;}
    }

    public class KMSPostCreateCommentModel
    {
        public Guid? PostsId { get; set; }
        public string? Comment { get; set; }
        public string? CreatedBy { get; set; }
        public string? FullName { get; set; }
    }

    public class KMSPostCommentModel
    {
        public Guid Id { get; set; }
        public Guid PostsId { get; set; }
        public string Comment { get; set; }
        public string? CreatedBy { get; set; }
        public string? FullName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString("dd/MM/yyyy HH:mm"); }
        public Guid? ParentId { get; set; }
        public List<KMS_Posts_Comments>? Childrens { get; set; }
        public bool CanDeleted { get; set; }
    }
}
