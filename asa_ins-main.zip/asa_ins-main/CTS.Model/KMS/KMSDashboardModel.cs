﻿using CTS.Domain.KMS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Model.KMS
{
    public class KMSDashboardModel
    {
    }

    public class KMSDashboardCategory
    {
        public Guid Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? ICon { get; set; }
        public Guid? ParentId { get; set; }
        public List<KMS_Category>? Childrens { get; set; }
        public List<KMS_Posts_Category>? KMS_Posts_Categories { get; set; }
    }

    public class KMSDashCategoryModel
    {
        public Guid? Id { get; set; }
        public Guid? ParentId { get; set; }
        public string CategoryName { get; set; }
        public string? Code { get; set; }
        public string StringValue { get; set; }
        public string ICon { get; set; }
        public int TotalPosts { get; set; }
        public List<KMSDashCategoryPostModel>? CategoryPostModels { get; set; }
    }

    public class KMSDashCategoryPostModel
    {
        public int? STT { get; set; }
        public Guid Id { get; set; }
        public string? PostTitle { get; set; }
        public string? PostUrl { get; set; }
        public string? PostShortContent { get; set; }
        public string? PostContent { get; set; }
        public string? PostAvatar { get; set; }
        public List<string>? PostDocument { get; set; }
        public List<string>? PostCategories { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString("dd/MM/yyyy"); }
        public int? TotalViews { get; set; }
    }
}
