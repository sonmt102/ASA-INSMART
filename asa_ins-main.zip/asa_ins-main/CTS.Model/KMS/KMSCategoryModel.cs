﻿using CTS.Model.General;

namespace CTS.Model.KMS
{
    public class KMSCategoryRequestModel
    {
        public Guid? Id { get; set; }
        public Guid? ParentId { get; set; }
        public string CategoryName { get; set; }
        public string? Code { get; set; }
        public string StringValue { get; set; }
        public string ICon { get; set; }
    }
    public class CreateKMSCategoryRequestModel
    {
        public Guid? Id { get; set; }
        public Guid? ParentId { get; set; }
        public string CategoryName { get; set; }
        public string? Code { get; set; }
        public string StringValue { get; set; }
        public string ICon { get; set; }
    }

    public class KMSCategoryRenameRequestModel
    {
        public Guid Id { get; set; }
        public string OldText { get; set; }
        public string Text { get; set; }
    }


    public class DataForKMSCategoryTree
    {
        public int CatTypeId { get; set; }
        public string CatTypeName { get; set; }
        public string CatTypeGroup { get; set; }
    }

    public class KMSCategoryItemModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public int Id { get; set; }
        public string Value { get; set; }
        public string ExpandProperties { get; set; }
    }


    public class KMSCategoryGroupSelectModel
    {
        public string Group { get; set; }
        public string DataValueFeld { get; set; }
        public string DataTextFeld { get; set; }
    }

}
