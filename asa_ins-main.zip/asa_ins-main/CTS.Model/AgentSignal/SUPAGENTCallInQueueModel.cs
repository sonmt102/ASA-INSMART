﻿using CTS.Common;

namespace CTS.Model.AgentSignal
{
    public class SUPAGENTCallInQueueModel
    {
        public Guid Id { get; set; }
        public string CusPhone { get; set; }
        public string QueueInCall { get; set; }
        public AgentStatusCall AgentStatusCall { get; set; }
        public DateTime CallTime { get; set; }
        public string Channel { get; set; }
    }
}
