﻿using CTS.Common;

namespace CTS.Model.AgentSignal
{
    public class AGENTRingingModel
    {
        public string CusPhone { get; set; }
        public DateTime CallTime { get; set; }
        public CallCoreDirection CallDirection { get; set; }
        public string AgentExten { get; set; }
        public string Channel { get; set; }
        public string CallId { get; set; }
    }
}
