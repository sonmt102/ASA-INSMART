﻿using CTS.Common;

namespace CTS.Model.AgentSignal
{
    public class SUPAGENTCallModel
    {
        public Guid Id { get; set; }
        public string CusPhone { get; set; }
        public AgentStatusCall AgentStatusCall { get; set; }
        public DateTime CallTime { get; set; }
    }
}
