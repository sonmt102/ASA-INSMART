﻿using CTS.Model.SUP;

namespace CTS.Model.AgentSignal
{
    public class SUPAGENTAgentChangeStatusModel
    {
        public Guid Id { get; set; }
        public List<AgentQueueModel> Queues { get; set; }
    }
}
