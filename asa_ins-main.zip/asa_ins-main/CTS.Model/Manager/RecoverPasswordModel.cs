﻿namespace CTS.Model.Manager
{
    public class RecoverPasswordModel
    {
        public string UserName { get; set; }
        public string Code { get; set; }
        public string Password { get; set; }
        public string Msg { get; set; }
    }
}
