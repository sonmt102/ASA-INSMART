﻿namespace CTS.Model.Manager.Role
{
    public class RoleModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string RoleName { get; set; }
        public int Accounts { get; set; }
        public bool IsCheck { get; set; }
    }
}
