﻿namespace CTS.Model.Manager.Role
{
    public class GroupPermissionModel
    {
        public string GroupName { get; set; }
        public List<PermissionModel> Permissions { get; set; }
        public int OrderIndex { get; set; }
    }

    public class PermissionModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool IsCheck { get; set; }
    }
}
