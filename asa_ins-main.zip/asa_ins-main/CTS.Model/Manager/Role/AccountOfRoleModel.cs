﻿namespace CTS.Model.Manager.Role
{
    public class AccountOfRoleModel
    {
        public Guid AccountId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public bool IsCheck { get; set; }
    }
}
