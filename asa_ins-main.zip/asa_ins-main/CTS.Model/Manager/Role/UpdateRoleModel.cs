﻿namespace CTS.Model.Manager.Role
{
    public class UpdateRoleModel
    {
        public string Name { get; set; }
        public List<Guid> AccountIds { get; set; }
    }
}
