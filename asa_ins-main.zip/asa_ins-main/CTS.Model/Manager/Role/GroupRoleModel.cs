﻿namespace CTS.Model.Manager.Role
{
    public class GroupRoleModel
    {
        public string GroupName { get; set; }
        public List<RoleModel> Roles { get; set; }
    }


}
