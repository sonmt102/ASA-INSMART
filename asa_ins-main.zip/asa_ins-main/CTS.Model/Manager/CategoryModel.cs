﻿using CTS.Model.General;

namespace CTS.Model.Manager
{

    public class CreateCategoryRequestModel
    {
        public Guid? Id { get; set; }
        public Guid? ParentId { get; set; }
        public string CategoryName { get; set; }
        public string Code { get; set; }
        public string StringValue { get; set; }
        public string ICon { get; set; }
    }

    public class CategoryRenameRequestModel
    {
        public Guid Id { get; set; }
        public string OldText { get; set; }
        public string Text { get; set; }
    }


    public class DataForCategoryTree
    {
        public int CatTypeId { get; set; }
        public string CatTypeName { get; set; }
        public string CatTypeGroup { get; set; }
    }

    public class CategoryItemModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public int Id { get; set; }
        public string Value { get; set; }
        public string ExpandProperties { get; set; }
    }


    public class CategoryGroupSelectModel
    {
        public string Group { get; set; }
        public string DataValueFeld { get; set; }
        public string DataTextFeld { get; set; }
    }


    public class ProductDetialByModelModel
    {
        public List<SelectModel> Select2Data { get; set; }
        /// <summary>
        /// Dung tích/ công xuất
        /// </summary>
        public string ProductCapacity { get; set; }
    }
}
