﻿using CTS.Common;

namespace CTS.Model.Manager.Signal
{
    public class VOCSignalModel
    {
        public string Content { get; set; }
        public Guid TicketId { get; set; }
        public Guid AccountId { get; set; }
        public string UserName { get; set; }
        public string TicketCode { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
    }
}
