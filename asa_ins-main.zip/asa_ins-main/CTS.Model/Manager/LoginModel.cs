﻿namespace CTS.Model.Manager
{
    public class LoginModel
    {
        /// <summary>
        /// Tài khoản
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Mật khẩu
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// Số nội bộ
        /// </summary>
        public string? Exten { get; set; }
        /// <summary>
        /// Số nội bộ phụ
        /// </summary>
        public string? Exten2 { get; set; }
    }

    public class UserLogonModel
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Position { get; set; }
        public string FullName { get; set; }
        public List<UserLogonDepartmentModel> Departments { get; set; }
        public List<string> Permissions { get; set; }
        /// <summary>
        /// Thông tin token
        /// </summary>
        public UserTokenDTO TokenData { get; set; }
        public Guid ServerId { get; set; }
        public Guid LoginKey { get; set; }
        public string? Extension { get; set; }
    }

    public class UserLogonDepartmentModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class MenuModel
    {
        public string MenuName { get; set; }
        public bool IsActive { get; set; }
        public int? ParentId { get; set; }
        public string Icon { get; set; }
        public string Path { get; set; }
        public int Id { get; set; }
    }

    public class UserTokenDTO
    {
        public string Id { get; set; }
        public string Accesstoken { get; set; }
        public DateTime? ExpiredAt { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
    }
}
