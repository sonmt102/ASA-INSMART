﻿using CTS.Common;

namespace CTS.Model.Manager.Notify
{
    public class Top20VOCNotifyModel
    {
        public int Total { get; set; }
        public List<VOCNotifyModel> Details { get; set; }
    }


    public class VOCNotifyModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public Guid TicketId { get; set; }
        public Guid AccountId { get; set; }
        public string content { get; set; }
        public string? ticketCode { get; set; }
        public DateTime Date { get; set; }
        public string dateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public NotifyModule Module { get; set; }
        public string Url { get => $"/ticket/detail/{TicketId}"; }
    }
}
