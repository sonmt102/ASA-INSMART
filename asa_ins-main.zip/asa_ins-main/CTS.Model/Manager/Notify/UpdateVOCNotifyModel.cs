﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Model.Manager.Notify
{
    public class UpdateVOCNotifyModel
    {
        public DateTime Date { get; set; }
        public Guid TicketId { get; set; }
        public string TicketCode { get; set; }
        public Guid AccountId { get; set; }
        public string Content { get; set; }
        public Guid RequestTypeId { get; set; }
    }
}
