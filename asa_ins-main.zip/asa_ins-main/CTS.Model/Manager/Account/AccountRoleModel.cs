﻿namespace CTS.Model.Manager.Account
{
    public class AccountRoleModel
    {
        public Guid AccountId { get; set; }
        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public bool IsChecked { get; set; }
    }
}
