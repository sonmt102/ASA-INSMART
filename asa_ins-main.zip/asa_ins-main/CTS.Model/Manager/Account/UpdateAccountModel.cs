﻿namespace CTS.Model.Manager.Account
{
    public class UpdateAccountModel
    {
        /// <summary>
        /// Tài khoản
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Tên đầy đủ
        /// </summary>
        public string FullName { get; set; }
        /// <summary>
        /// Số điện thoại
        /// </summary>
        public string Phone { get; set; }
        public string Email { get; set; }
        public bool IsActive { get; set; }
        public string Password { get; set; }
        public string Position { get; set; }
    }
}
