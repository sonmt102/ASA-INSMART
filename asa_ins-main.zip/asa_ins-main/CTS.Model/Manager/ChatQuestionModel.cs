﻿using CTS.Model.General;

namespace CTS.Model.Manager
{
    public class CreateQuestionRequestModel
    {
        public Guid? Id { get; set; }
        public string? QuestionDisplayName { get; set; }
        public string? QuesDetail { get; set; }
        public string? AnswerDetail { get; set; }
        public string? KeyQuestion { get; set; }

        public Guid? ParentId { get; set; }
        public int? Level { get; set; }

    }

    public class LoadDatatable
    {
        public Guid? ID { get; set; }
        public string? NameGroup { get; set; }
        public string? NameDisplay { get; set; }
        public string? NameDetail { get; set; }
        public string? AnswerDetail { get; set; }
        public int? Level { get; set; }
    }
}
    
