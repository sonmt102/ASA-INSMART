﻿using System.ComponentModel.DataAnnotations;
using CTS.Common;

namespace CTS.Model.Manager
{
    public class MailModel
    {
        public Guid Id { get; set; }
        public string Content { get; set; }
    }

    public class MailConfigModel
    {
        public Guid Id { get; set; }
        [Required]
        public string Host { get; set; }
        [Required]
        public int Port { get; set; }
        [Required]
        public string Server { get; set; }
        [Required]
        public int PortServer { get; set; }
        [Required]
        public bool SSLoTLS { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
        public bool Encode { get; set; }
        public string MailSubject { get; set; }
        public string MailContent { get; set; }
        public string CreatedBy { get; set; }
    }
    public class MailContentModel
    {
        public Guid Id { get; set; }
        public string MailSubject { get; set; }
        public string MailContent { get; set; }
        public int MailType { get; set; } // 1 - Lấy lại mật khẩu, 2 - Cảnh báo sự cố
        public int MailConfigId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsDeleted { get; set; }
    }
    public class UserOnlineModel
    {
        public int STT { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public DateTime LoginDate { get; set; }
        public string LoginDateStr { get => LoginDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
    }
}
