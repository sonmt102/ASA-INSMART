﻿using CTS.Common;

namespace CTS.Model.Manager
{
    public class LogAccessModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public LogAccess_DataType DataType { get; set; }
        public string DataTypeStr
        {
            get
            {
                return DataType switch
                {
                    LogAccess_DataType.TaiKhoan => "Tài khoản",
                    LogAccess_DataType.Quyen => "Quyền",
                    _ => string.Empty,
                };
            }
        }
        public LogAccess_Type Type { get; set; }
        public string TypeStr
        {
            get
            {
                switch (Type)
                {
                    case LogAccess_Type.TruyCap:
                        return "Truy cập";
                    case LogAccess_Type.TaoMoi:
                        return "Tạo mới";
                    case LogAccess_Type.ChinhSua:
                        return "Cập nhật";
                    case LogAccess_Type.Xoa:
                        return "Xóa";
                    default:
                        return string.Empty;
                }
            }
        }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmmss); }
        public string CreatedBy { get; set; }
        public string Content { get; set; }

    }

    public class CreateLogAccessModel
    {
        public LogAccess_DataType DataType { get; set; }
        public LogAccess_Type Type { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string Content { get; set; }
    }
}
