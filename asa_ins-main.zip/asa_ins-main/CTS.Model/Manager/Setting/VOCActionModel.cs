﻿using CTS.Common;

namespace CTS.Model.Manager.Setting
{
    public class VOCActionModel
    {
        public Guid Id { get; set; }
        public VOCActionType Type { get; set; }
    }
}
