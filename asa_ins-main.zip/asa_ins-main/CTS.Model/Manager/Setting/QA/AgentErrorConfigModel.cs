﻿using CTS.Common;

namespace CTS.Model.Manager.Setting.QA
{
    public class AgentErrorConfigModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public Guid GroupCriterialId { get; set; }
        public string Name { get; set; }
        public QALoaiTieuChi Type { get; set; }
    }
}
