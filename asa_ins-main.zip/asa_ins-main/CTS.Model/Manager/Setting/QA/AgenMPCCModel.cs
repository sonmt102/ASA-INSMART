﻿namespace CTS.Model.Manager.Setting.QA
{
    public class AgentMPCCConfigModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Exten { get; set; }
        public bool IsActive { get; set; }
    }

    public class AgentMPCCConfigUpdateModel
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string OldUserName { get; set; }
        public string FullName { get; set; }
        public string Exten { get; set; }
    }


    public class AgentMPCCConfigCreateModel
    {
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Exten { get; set; }
        public bool IsActive { get; set; }
    }

}
