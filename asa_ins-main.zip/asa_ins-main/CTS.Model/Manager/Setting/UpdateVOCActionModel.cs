﻿using CTS.Common;

namespace CTS.Model.Manager.Setting
{
    public class UpdateVOCActionModel
    {
        public Guid VOCRequestTypeId { get; set; }
        public VOCActionType Type { get; set; }
        public bool IsChecked { get; set; }
        public Guid? AccountId { get; set; }
    }
}
