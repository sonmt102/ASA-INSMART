﻿using CTS.Common;

namespace CTS.Model.Manager.Setting
{
    public class UpdateVOCRequestTypeModel
    {
        public string Name { get; set; }
        public int Time { get; set; }
        public int Index { get; set; }
        public VOCDeadlineTimeType TimeType { get; set; }
    }
}
