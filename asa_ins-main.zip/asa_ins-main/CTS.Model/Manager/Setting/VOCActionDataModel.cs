﻿namespace CTS.Model.Manager.Setting
{
    public class VOCActionDataModel
    {
        public Guid Id { get; set; }
        /// <summary>
        /// Tài khoản
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Tên đầy đủ
        /// </summary>
        public string FullName { get; set; }

        public string NameDisplay
        {
            get
            {
                return $"{UserName} - {FullName}";
            }
        }
    }
}
