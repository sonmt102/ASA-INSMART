﻿using CTS.Common;

namespace CTS.Model.Manager.Setting
{
    public class VOCRequestTypeModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Index { get; set; }
        public int Time { get; set; }
        public VOCDeadlineTimeType TimeType { get; set; }
        public string DeadlineDisplay
        {
            get
            {
                return TimeType switch
                {
                    VOCDeadlineTimeType.Phut => $"{Time} phút",
                    VOCDeadlineTimeType.Gio => $"{Time} giờ",
                    VOCDeadlineTimeType.Ngay => $"{Time} ngày",
                    _ => $"{Time} giờ",
                };
            }
        }
        public List<VOCRequestTypeActionModel> Actions { get; set; }

        public Guid? AccountId
        {
            get
            {
                if (Actions != null && Actions.Count > 0)
                {
                    var myAction = Actions.Where(x => x.Type == VOCActionType.PhanCongPhuTrach).FirstOrDefault();
                    if (myAction != null) return myAction.AccountId;

                }
                return null;

            }
        }
    }

    public class VOCRequestTypeActionModel
    {
        public VOCActionType Type { get; set; }
        public string TypeStr
        {
            get
            {
                return Type switch
                {
                    VOCActionType.ThongBao => "Thông báo đến người phụ trách",
                    VOCActionType.GuiEmail => "Gửi email đến người phụ trách",
                    VOCActionType.PhanCongPhuTrach => "Mặc định phân cho người phụ trách",
                    _ => "Thông báo đến người phụ trách",
                };
            }
        }

        public Guid? AccountId { get; set; }

    }
}
