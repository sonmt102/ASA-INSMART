﻿namespace CTS.Model.Manager
{
    public class SendEmailForgotPasswordModel
    {
        public bool SSL { get; set; }
        public string Email { get; set; }
        public string EmailPasss { get; set; }
        public string Host { get; set; }
        public int Port { get; set; }
        public string EmailTo { get; set; }
        public string Title { get; set; }
        public string Subject { get; set; }
    }
}
