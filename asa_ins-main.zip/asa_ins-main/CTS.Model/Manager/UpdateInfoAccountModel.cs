﻿namespace CTS.Model.Manager
{
    public class UpdateInfoAccountModel
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
