﻿using CTS.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Model.Dashboard
{
    public class QASummaryModel
    {
        public int InDay { get; set; }
        public int Total { get; set; }
    }

    public class QASummaryDetailModel
    {
        public string CallId { get; set; }
        public DateTime CallDate { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Phone { get; set; }
        public string Supervisor { get; set; }
        public DateTime QADate { get; set; }
        public string QADateStr { get => QADate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Mark { get; set; }
    }
}
