﻿namespace CTS.Model.Dashboard
{
    public class TicketAssignAccountModel
    {
        public int Week { get; set; }
        public int Month { get; set; }
        public int All { get; set; }

        public List<TicketAssignAccountDetailModel> Assigned { get; set; }
    }

    public class TicketAssignAccountDetailModel
    {
        public string UserName { get; set; }
        public string FullName { get; set; }
        public int Counter { get; set; }
    }
}
