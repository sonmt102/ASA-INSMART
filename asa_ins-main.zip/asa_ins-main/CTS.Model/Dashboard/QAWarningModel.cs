﻿namespace CTS.Model.Dashboard
{
    public class QAWarningModel
    {
        public int Type09 { get; set; }
        public int Type99 { get; set; }
        public int Type999 { get; set; }
        public int All { get; set; }
    }
}
