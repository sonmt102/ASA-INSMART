﻿namespace CTS.Model.Dashboard
{
    public class TicketSummaryModel
    {
        public int NEW { get; set; }
        public int HANDLER { get; set; }
        public int COMPLETE { get; set; }
        public int TBTT { get; set; }
        public int KN { get; set; }
        public int SP { get; set; }
        public int KHAC { get; set; }
        public List<TicketSummaryDetailModel> SummaryNow { get; set; }
        public List<TicketSummaryDetailModel> SummaryYesterday { get; set; }
    }

    public class TicketSummaryDetailModel
    {
        public Guid RequestTypeId { get; set; }
        public string RequestType { get; set; }
        public int Counter { get; set; }
    }
}
