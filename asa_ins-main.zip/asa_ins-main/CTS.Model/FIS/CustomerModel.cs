﻿using CTS.Model.General;

namespace CTS.Model.FIS
{
    public class CustomerModel
    {
        public int STT { get; set; }
        public Int64 Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public Int64? ToChucId { get; set; }
        public int? LevelToChuc { get; set; }
        public Int64? Tinh { get; set; }
        public Int64? DonVi { get; set; }
        public string TinhStr { get; set; }
        public string DonViStr { get; set; }
        public SelectModel? SelectCustomerDonVi { get; set; }
        public SelectModel? SelectCustomerTinh { get; set; }
    }
}
