﻿namespace CTS.Model.CIMS
{
    public class DanhMucDonViModel
    {
        public int STT { get; set; }
        public Int64 Id { get; set; }
        public Int64? ParentId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
