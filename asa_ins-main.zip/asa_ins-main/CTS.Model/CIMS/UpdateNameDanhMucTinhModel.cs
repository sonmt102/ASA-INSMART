﻿namespace CTS.Model.CIMS
{
    public class UpdateNameDanhMucTinhModel
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }

    public class UpdateNameDanhMucDonViModel
    {
        public Guid ParentId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
