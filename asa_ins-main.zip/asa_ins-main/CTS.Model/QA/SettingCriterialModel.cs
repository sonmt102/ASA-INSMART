﻿namespace CTS.Model.QA
{

    public class SettingCriterialModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int OrderIndex { get; set; }
        public virtual decimal Mark { get => Details.Count > 0 ? Details.Max(s => s.Mark) : 0; }

        public List<SettingCriterialDetailModel> Details = new();
    }

    public class SettingCriterialDetailModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public decimal Mark { get; set; }
        public int OrderIndex { get; set; }
    }
}
