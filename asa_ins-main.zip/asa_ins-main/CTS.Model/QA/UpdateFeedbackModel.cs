﻿namespace CTS.Model.QA
{
    public class UpdateFeedbackModel
    {
        public Guid MarkDetailId { get; set; }
        public string NhanVienPhanHoi { get; set; }
    }
}
