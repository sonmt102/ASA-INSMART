﻿using CTS.Common;
using System.Drawing;

namespace CTS.Model.QA.Analysis
{
    public class AnalysisResultModel
    {
        public string CallId { get; set; }
        public Image Image { get; set; }
        public string AllData { get; set; }
        public CallWarningType Type { get; set; }
        public string BaseImage { get; set; }
        public DateTime? CallDate { get; set; }
        public string? Agent { get; set; }
        public string? Phone { get; set; }
    }
}
