﻿namespace CTS.Model.QA.Analysis
{
    public class CallDetailLogModel
    {
        public string CallId { get; set; }
        public DateTime CallDate { get; set; }
        public bool HadFile { get; set; }
        public string Image { get; set; }
        public string? Agent { get; set; }
        public string? Phone { get; set; }
    }
}
