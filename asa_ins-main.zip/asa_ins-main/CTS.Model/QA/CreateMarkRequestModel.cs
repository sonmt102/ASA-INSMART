﻿namespace CTS.Model.QA
{
    public class CreateMarkRequestModel
    {
        public Guid AssignId { get; set; }
        public string CustomerPhone { get; set; }
        public string AgentUserName { get; set; }
        public string CallDirection { get; set; }
        public string AgentStation { get; set; }
        public int CallDuration { get; set; }
        public string CallDate { get; set; }
        public string CallId { get; set; }
        public string DNIS { get; set; }
        public string LocalNumber { get; set; }
        public string RecordingFileName { get; set; }
    }
}
