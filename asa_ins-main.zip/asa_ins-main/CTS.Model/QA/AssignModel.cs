﻿using CTS.Common;
using CTS.Model.General;
using System.Globalization;

namespace CTS.Model.QA
{
    public class CreateAssignRequestModel
    {
        public Guid Id { get; set; }
        public string Direction { get; set; }
        public int NumberCall { get; set; }
        public Guid QAId { get; set; }
        public string FromDateStr { get; set; }
        public DateTime? FromDate
        {
            get
            {
                if (!string.IsNullOrEmpty(FromDateStr) && DateTime.TryParseExact(FromDateStr, FormatDate.DateTime_103,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string ToDateStr { get; set; }
        public DateTime? ToDate
        {
            get
            {
                if (!string.IsNullOrEmpty(ToDateStr) && DateTime.TryParseExact(ToDateStr, FormatDate.DateTime_103,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public List<Guid> Agents = new();
    }

    public class AssignModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public List<SelectModel> SelectDirection
        {
            get
            {
                if (string.IsNullOrEmpty(Direction))
                {
                    return new List<SelectModel>()
                    {
                        new ()
                        {
                            id = "All",
                            text  ="Tất cả"
                        },
                        new ()
                        {
                            id = "IVR",
                            text  ="Gọi đến"
                        },
                        new ()
                        {
                            id = "CALLOUTBOUND",
                            text  ="Gọi đi"
                        }
                    };
                }
                else
                {
                    switch (Direction)
                    {
                        case UserEventStatusConst.IVR:
                            return new List<SelectModel>()
                            {
                                new ()
                                {
                                    id = "IVR",
                                    text  ="Gọi đến"
                                }
                            };
                        case UserEventStatusConst.CALLOUTBOUND:
                            return new List<SelectModel>()
                            {
                                new ()
                                {
                                    id = "CALLOUTBOUND",
                                    text  ="Gọi đi"
                                }
                            };
                        default:
                            return new List<SelectModel>()
                            {
                                new ()
                                {
                                    id = "All",
                                    text  ="Tất cả"
                                },
                                new ()
                                {
                                    id = "IVR",
                                    text  ="Gọi đến"
                                },
                                new ()
                                {
                                    id = "CALLOUTBOUND",
                                    text  ="Gọi đi"
                                }
                            };
                    }
                }
            }
        }
        public string Direction { get; set; }
        public string DirectionStr
        {
            get
            {
                return Direction switch
                {
                    UserEventStatusConst.CALLOUTBOUND => "Gọi đi",
                    UserEventStatusConst.IVR => "Gọi đến",
                    _ => "Tất cả",
                };
            }
        }
        public int NumberCall { get; set; }
        public DateTime FromDate { get; set; }
        public string FromDateStr { get => FromDate.ToString(FormatDate.DateTime_103); }
        public DateTime ToDate { get; set; }
        public string ToDateStr { get => ToDate.ToString(FormatDate.DateTime_103); }
        public List<SelectModel> SelectAgent { get; set; }
        public Guid QAId { get; set; }
        public string QA { get; set; }
        public int Marked { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CreatedBy { get; set; }
        public List<string> Agents { get; set; }
    }

}
