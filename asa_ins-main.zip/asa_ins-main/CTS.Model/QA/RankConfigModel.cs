﻿using System;

namespace CTS.Model.QA
{
    public class ListRankConfigModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public decimal MarkFrom { get; set; }
        public decimal MarkTo { get; set; }
    }


    public class CreateRankConfigRequestModel
    {
        public string Name { get; set; }
        public string MarkFrom { get; set; }
        public decimal MarkFromConvert
        {
            get
            {
                if (decimal.TryParse(MarkFrom.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }
        public string MarkTo { get; set; }
        public decimal MarkToConvert
        {
            get
            {
                if (decimal.TryParse(MarkTo.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }

    }

    public class RankConfigModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string MarkFrom { get; set; }
        public decimal MarkFromConvert
        {
            get
            {
                if (decimal.TryParse(MarkFrom.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }
        public string MarkTo { get; set; }
        public decimal MarkToConvert
        {
            get
            {
                if (decimal.TryParse(MarkTo.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }
    }
}
