﻿using CTS.Common;

namespace CTS.Model.QA
{
    public class MarkedModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Assigner { get; set; }
        public Guid? AssignId { get; set; }
        public string Agent { get; set; }
        public string CustomerPhone { get; set; }
        public string CallId { get; set; }
        /// <summary>
        /// Tổng điểm
        /// </summary>
        public decimal Total { get; set; }
        /// <summary>
        /// Tổng điểm khi chấm
        /// </summary>
        public decimal TotalMark { get; set; }
        //public decimal TotalChuyenMon { get; set; }
        ///// <summary>
        ///// Đạt được
        ///// </summary>
        //public decimal MarkChuyenMon { get; set; }
        //public decimal TotalNghiepVu { get; set; }
        ///// <summary>
        ///// Đạt được
        ///// </summary>
        //public decimal MarkNghiepVu { get; set; }
        public string Ranking { get; set; }
        //public string RecordingFileName { get; set; }
        public DateTime CallDate { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public bool IsFeedback { get; set; }
        public bool IsCloseFeedback { get; set; }
    }
}
