﻿using CTS.Common;

namespace CTS.Model.QA
{
    public class MarkInfoModel
    {
        public Guid Id { get; set; }
        public string CustomerPhone { get; set; }
        public int? RecordingDuration { get; set; }
        public DateTime CallDate { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Agent { get; set; }
        public string AgentFullName { get; set; }
        public Guid? Rank { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsCloseFeedback { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }

    }
}
