﻿namespace CTS.Model.QA
{
    public class RecordingFileRequestModel
    {
        public string FileName { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public string CallDate { get; set; }
    }
}
