﻿using CTS.Common;

namespace CTS.Model.QA
{
    public class DataLogModel
    {
        public int STT { get; set; }
        public string CallId { get; set; }
        public DateTime HandlerDate { get; set; }
        public string HandlerDateStr { get => HandlerDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime CallDate { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public bool HadFile { get; set; }
        public string Image { get; set; }
    }

    public class DataWarningModel
    {
        public int STT { get; set; }
        public string CallId { get; set; }
        public DateTime HandlerDate { get; set; }
        public string HandlerDateStr { get => HandlerDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime CallDate { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public CallWarningType Type { get; set; }
        public string TypeStr
        {
            get
            {
                return Type switch
                {
                    CallWarningType.None => "Không",
                    CallWarningType.CaoBatThuong => "Cao bất thường",
                    CallWarningType.NhieuCap99 => "Có nhiều đợt tần số cao cùng nhau",
                    CallWarningType.Nhieu99LienNhau => "Có nhiều tần số cao liên tiếp",
                    CallWarningType.All => "Cảnh báo bất thường",
                    _ => "Không",
                };
            }
        }
        public string? Agent { get; set; }
        public string? Phone { get; set; }
        public string? Image { get; set; }
    }
}
