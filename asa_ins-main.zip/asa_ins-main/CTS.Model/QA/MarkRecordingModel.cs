﻿using CTS.Common;

namespace CTS.Model.QA
{
    public class MarkRecordingModel
    {
        public int STT { get; set; }
        public string CallId { get; set; }
        public virtual DateTime? StartTime
        {
            get
            {
                var check = double.TryParse(CallId, out double myDoub);
                if (check) return Helper.UnixTimeStampToDateTime(myDoub);
                return null;
            }
        }

        public string CustomerPhone { get; set; }
        public string AgentExten { get; set; }
        public string AgentUserName { get; set; }
        public string AgentFullName { get; set; }
        public int? RecordingDuration { get; set; }
        public DateTime? InitiatedDate { get; set; }
        public string? InitiatedDateStr { get => InitiatedDate.HasValue ? InitiatedDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }
        public string InitiatedDateForGetRecording { get => InitiatedDate.HasValue ? InitiatedDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmmss) : String.Empty; }
        public string Direction { get; set; }
        public string DirectionStr
        {
            get
            {
                return Direction switch
                {
                    "IVR" => "Gọi đến",
                    "CALLOUTBOUND" => "Gọi đi",
                    _ => "Gọi đi **",
                };
            }
        }
        /// <summary>
        /// Khách hàng gọi đến số này
        /// </summary>
        public string Exten { get; set; }
        public string RecordingFileName { get; set; }
        public Guid AssignId { get; set; }
        public string DNIS { get; set; }
        public Guid Id { get; set; }
    }
}
