﻿namespace CTS.Model.QA
{
    public class RecordingFileModel
    {
        public DateTime StartTime { get; set; }
        public string CallId { get; set; }
    }
}
