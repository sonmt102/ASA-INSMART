﻿using CTS.Model.General;

namespace CTS.Model.QA
{
    public class MarkIndexModel
    {
        public string CreatedBy { get; set; }
        /// <summary>
        /// Xếp loại
        /// </summary>
        public List<SelectModel> RankData = new();
        public List<SelectModel> AgentErrorData = new();
        public List<SelectModel> AgentCICData = new();
        public List<SelectModel> LocalNumber = new();
    }

    public class AssignIndexModel
    {
        public List<SelectModel> GiamSatData = new();
        public List<SelectModel> LocalNumber = new();
        public List<SelectModel> RankData = new();
        public List<SelectModel> CriteriaData = new();
    }
}
