﻿namespace CTS.Model.QA
{
    public class UpdateParentCriterialModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int OrderIndex { get; set; }
    }

    public class UpdateChildCriterialModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int OrderIndex { get; set; }
        public string Mark { get; set; }
        public decimal MarkConvert
        {
            get
            {
                if (decimal.TryParse(Mark.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }
    }

    public class CreateParentCriterialModel
    {
        public int OrderIndex { get; set; }
        public string Name { get; set; }
    }

    public class CreateChildCriterialModel
    {
        public Guid CriterialId { get; set; }
        public int OrderIndex { get; set; }
        public string Name { get; set; }
        public string Mark { get; set; }
        public decimal MarkConvert
        {
            get
            {
                if (decimal.TryParse(Mark.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }
    }

    public class ChangeCriterialModel
    {
        public Guid GroupId { get; set; }
        public Guid Id { get; set; }
        public Guid CriterialParentId { get; set; }
        public string Name { get; set; }
        public int OrderIndex { get; set; }
        public string Mark { get; set; }
        public bool IsCriterialParent { get; set; }
        public decimal MarkConvert
        {
            get
            {
                if (decimal.TryParse(Mark.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }
    }
}
