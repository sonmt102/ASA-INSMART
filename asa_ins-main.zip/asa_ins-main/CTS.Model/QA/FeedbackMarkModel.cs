﻿using CTS.Common;

namespace CTS.Model.QA
{
    public class FeedbackMarkModel
    {
        public Guid Id { get; set; }
        public List<MarkDataModel> TieuChiChamDiem { get; set; }
        public string AgentUserName { get; set; }
        public Guid? AssignId { get; set; }
        public Guid? QA_RankConfigId { get; set; }
        public string CallId { get; set; }
        public string CustomerPhone { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime CallDate { get; set; }
        public string MarkBy { get; set; }
        public DateTime MarkDate { get; set; }
        public string MarkDateStr { get => MarkDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public bool IsCloseFeedback { get; set; }
    }

    public class ListFeedbackMarkModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Agent { get; set; }
        public string CallId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CustomerPhone { get; set; }
        public string GiamSat { get; set; }
        public DateTime CallDate { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Duration { get; set; }
        public decimal Mark { get; set; }
        public string Rank { get; set; }
        public bool IsCloseFeedback { get; set; }
    }
}
