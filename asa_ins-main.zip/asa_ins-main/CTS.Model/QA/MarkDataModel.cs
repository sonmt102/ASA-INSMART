﻿using CTS.Common;
using System.Globalization;

namespace CTS.Model.QA
{
    public class CreateMarkModel
    {
        public List<MarkDataModel> TieuChiChamDiem { get; set; }
        public string AgentUserName { get; set; }
        public Guid AssignId { get; set; }
        public Guid? QA_RankConfigId { get; set; }
        public string CallId { get; set; }
        public string CustomerPhone { get; set; }
        public string CallDateStr { get; set; }
        public DateTime CallDate
        {
            get
            {
                if (!string.IsNullOrEmpty(CallDateStr) && DateTime.TryParseExact(CallDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                   CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return DateTime.Now;
            }
        }
        public int CallDuration { get; set; }
        public string CallDirection { get; set; }
    }

    public class MarkDataModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int OrderIndex { get; set; }
        public decimal Mark { get => Details.Count > 0 ? Details.Max(s => s.Mark) : 0; }
        public decimal MyMark { get => Details.Count > 0 ? Details.Max(s => s.MyMark) : 0; }


        public List<MarkDetailDataModel> Details = new();
    }

    public class MarkDetailDataModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public decimal Mark { get; set; }
        public decimal MyMark { get; set; }
        public string NhanVienPhanHoi { get; set; }
        public string ChiTietLoi { get; set; }
        public string HuongDanSuaLoi { get; set; }
        public int OrderIndex { get; set; }
        public Guid MarkDetailId { get; set; }
    }

    public class MarkRequestModel
    {
        public Guid MarkId { get; set; }
        public string Note { get; set; }
        public string Mark { get; set; }
        public decimal MarkToConvert
        {
            get
            {
                if (decimal.TryParse(Mark.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }
        public string MyMark { get; set; }
        public decimal MyMarkToConvert
        {
            get
            {
                if (decimal.TryParse(MyMark.Replace(',', '.'), out decimal data))
                    return data;
                return 0;
            }
        }

        public bool AllowChangeMark { get => MarkToConvert >= MyMarkToConvert; }
    }

    public class UpdateMarkModel
    {
        public Guid Id { get; set; }
        public List<MarkDataModel> TieuChiChamDiem { get; set; }
        public string AgentUserName { get; set; }
        public Guid? AssignId { get; set; }
        public Guid? QA_RankConfigId { get; set; }
        public string CallId { get; set; }
        public string Phone { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime CallDate { get; set; }
        public string MarkBy { get; set; }
        public DateTime MarkDate { get; set; }
        public string MarkDateStr { get => MarkDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public bool IsCloseFeedback { get; set; }
    }

    public class UpdateMarkFeedbackModel
    {
        public string UserName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Content { get; set; }
        public bool IsFixed { get; set; }
    }

    public class MarkContentRequestModel
    {
        public Guid Id { get; set; }
        public List<Guid> AgentError { get; set; }
        public string RateContent { get; set; }
        public string OfferContent { get; set; }

    }
}
