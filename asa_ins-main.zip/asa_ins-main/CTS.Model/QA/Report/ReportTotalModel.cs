﻿namespace CTS.Model.QA.Report
{
    public class ReportTotal_RequestModel
    {
        public List<string>? Agent { get; set; }
        public string? FromDate { get; set; }
        public string? ToDate { get; set; }
    }


    public class ExportReportTotalModel
    {
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public List<ReportTotalModel> ListItem = new();
    }

    public class ReportTotalModel
    {
        public List<ReportTotalDataModel> Data = new();

        public List<string> ListRank = new();
    }

    public class ReportTotalDataModel
    {
        public int STT { get; set; }
        public string Agent { get; set; }
        public string AgentFullName { get; set; }
        public int Total { get; set; }
        public List<ReportTotalDetailModel> Detail { get; set; }
        public List<ReportTotal_RankModel> Ranks { get; set; }
        public object Ranks1 { get; set; }
    }

    public class ReportTotalDetailModel
    {
        public string Criterial { get; set; }
        public int Error { get; set; }

        public string Percent
        {
            get
            {
                if (Error == 0 || Total == 0) return string.Empty;
                else
                {
                    return ((Error / Total) * 100).ToString("0.##") + " %";
                }
            }
        }
        public int Total { get; set; }
    }

    public class ReportTotal_RankModel
    {
        public string Name { get; set; }
        public int Total { get; set; }
    }
}
