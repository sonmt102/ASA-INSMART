﻿using CTS.Common;

namespace CTS.Model.QA.Report
{
    public class ExportReportDetailModel
    {
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public List<ReportDetailModel> ListItem = new();
    }
    public class ReportDetailModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Agent { get; set; }
        public string AgentFullName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Phone { get; set; }
        public string GiamSat { get; set; }
        public string GSFullName { get; set; }
        public DateTime CallDate { get; set; }
        public string CallDateStr { get => CallDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Duration { get; set; }
        public decimal Mark { get; set; }
        public string Rank { get; set; }
        public List<string> LoiChuyenMon = new();
        public string LoiChuyenMonStr { get => string.Join(", ", LoiChuyenMon); }
        public List<string> LoiNghiepVu = new();
        public string LoiNghiepVuStr { get => string.Join(", ", LoiNghiepVu); }
        /// <summary>
        /// Đánh giá
        /// </summary>
        public string RateContent { get; set; }
        /// <summary>
        /// Đề xuất
        /// </summary>
        public string OfferContent { get; set; }
    }


}
