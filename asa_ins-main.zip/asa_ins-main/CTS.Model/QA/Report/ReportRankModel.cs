﻿namespace CTS.Model.QA.Report
{
    public class ExportReportRankModel
    {
        public List<ReportRankTotalModel> DataTotal = new();
        public List<ReportRankDetailModel> ListItem = new();
    }

    public class ReportRankTotalModel
    {
        public int STT { get; set; }
        public Guid Rank { get; set; }
        public string RankStr { get; set; }
        public int SoLuong { get; set; }
        public int TotalMark { get; set; }
        public decimal OrderIndex { get; set; }
        public decimal Percent
        {
            get
            {
                if (TotalMark > 0 && SoLuong > 0)
                {
                    return Math.Round((decimal)SoLuong / (decimal)TotalMark, 2);
                }
                return 0;
            }
        }
    }

    public class ReportRankDetailModel
    {
        public int STT { get; set; }
        public string Agent { get; set; }
        public string FullName { get; set; }
        public int TotalMark { get; set; }
        public List<ReportRankDetail_DetailModel> Details { get; set; }
        public string DetailStr
        {
            get
            {
                if (Details != null && Details.Count > 0)
                {
                    return string.Join("\r\n", Details.Select(s => $"{s.Counter} cuộc gọi, đạt: {s.RankStr}").ToList());
                }
                return string.Empty;
            }
        }
    }

    public class ReportRankDetail_DetailModel
    {
        public Guid Rank { get; set; }
        public string RankStr { get; set; }
        public int Counter { get; set; }
    }
}
