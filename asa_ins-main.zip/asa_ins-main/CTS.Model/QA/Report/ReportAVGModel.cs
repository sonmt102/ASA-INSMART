﻿namespace CTS.Model.QA.Report
{
    public class ExportReportAVGModel
    {
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public List<ReportAVGModel> ListItem = new();
    }
    public class ReportAVGModel
    {
        public int STT { get; set; }
        public string Agent { get; set; }
        public string AgentFullName { get; set; }
        public decimal DiemTB { get => Math.Round((TongDiem / SoCuocGoi), 1); }
        public decimal TongDiem { get; set; }
        public decimal SoCuocGoi { get; set; }
        public string TBXepLoai { get; set; }
    }
}
