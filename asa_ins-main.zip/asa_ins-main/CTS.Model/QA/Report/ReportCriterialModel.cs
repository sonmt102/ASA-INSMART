﻿using System.Globalization;

namespace CTS.Model.QA.Report
{
    public class ExportReportCriterialModel
    {
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public List<ReportCriterialModel> ListItem = new();
        public List<ReportCriterialModel> ListItem2 = new();
    }
    public class ReportCriterialModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int OrderIndex { get; set; }
        public int OrderParent { get; set; }
        public List<ReportCriterialDetailModel> Details { get; set; }

    }
    public class ReportCriterialDetailModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int SoLuongDaCham { get; set; }
        public int TongSo { get; set; }
        public int OrderIndex { get; set; }
        public string ThanhCongOnDaCham { get => $"{SoLuongDaCham}/{TongSo}"; }
        public string TiLe { get => TongSo > 0 && SoLuongDaCham > 0 ? $"{Math.Round((decimal)SoLuongDaCham / (decimal)TongSo)}" : "0"; }
        public string TiLeDiem { get => TongSo > 0 && SoLuongDaCham > 0 ? ((decimal)SoLuongDaCham * 100 / TongSo).ToString("0.00", CultureInfo.InvariantCulture) : "0"; }
        public decimal Percent { get => TongSo > 0 && SoLuongDaCham > 0 ? Math.Round((decimal)SoLuongDaCham / (decimal)TongSo) : 0; }
    }

    public class ReportCriterialDTOModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string GroupName { get; set; }
        public decimal Mark { get; set; }
        public decimal Marked { get; set; }
        public int ParentIndex { get; set; }
        public int Index { get; set; }
    }
}
