﻿namespace CTS.Model.Agent
{
    public class AgentLeaveJoinQueueModel
    {
        public Guid QueueId { get; set; }

    }
}
