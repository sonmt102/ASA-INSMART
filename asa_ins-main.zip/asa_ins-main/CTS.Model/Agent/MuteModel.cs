﻿namespace CTS.Model.Agent
{
    public class MuteModel
    {
        public string Channel { get; set; }
        public bool IsPrimary { get; set; }
    }
}
