﻿namespace CTS.Model.Agent
{
    public class TransferActionModel
    {
        public string Channel { get; set; }
        /// <summary>
        /// Số nội bộ nhận transfer
        /// </summary>
        public string TranToExten { get; set; }
    }

    public class BlindTransferActionModel
    {
        /// <summary>
        /// Kênh của mình
        /// </summary>
        public string Channel { get; set; }
        /// <summary>
        /// Số nội bộ của mình
        /// </summary>
        public string MyAgentExten { get; set; }
    }

}
