﻿using CTS.Common;

namespace CTS.Model.Agent
{
    public class AgentStatusCallModel
    {
        public DateTime? CallTime { get; set; }
        public CallCoreDirection Direction { get; set; }
        public string CusPhone { get; set; }
        public AgentStatusCall StatusCall { get; set; }
        public string Channel { get; set; }
        public bool IsMute { get; set; }
    }
}
