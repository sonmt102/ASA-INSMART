﻿namespace CTS.Model.Agent
{
    public class AgentsToTransferModel
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Extension { get; set; }
        public int Online { get; set; }
        public bool IsLogin { get; set; }
        public bool IsBusy { get; set; }
    }
}
