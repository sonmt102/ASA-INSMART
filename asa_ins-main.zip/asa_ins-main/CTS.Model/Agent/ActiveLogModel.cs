﻿using CTS.Common;

namespace CTS.Model.Agent
{
    public class ActiveLogModel
    {
        public DateTime StartTime { get; set; }
        public string StartTimeStr { get => StartTime.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string? Extension { get; set; }
        public string? StatusCode { get; set; }
        public string? StatusCodeStr { get; set; }
        public string Queues { get; set; }
    }

    public class CreateActiveLogModel
    {
        public Guid AccountId { get; set; }
        public string? Extension { get; set; }
        public string? StatusCode { get; set; }
        public string? Queues { get; set; }
        public Guid MatchingId { get; set; }
        private DateTime? _StartTime;
        public DateTime StartTime { get => _StartTime.HasValue ? _StartTime.Value : DateTime.Now; set => _StartTime = value; }
        public bool HadPause { get; set; }
        public bool HadUnPause { get; set; }
        public bool IsPrimary { get; set; }
        /// <summary>
        /// Nếu true thì update tất cả bản ghi có matchingid với trạng thái HadPause và HadUnPause
        /// </summary>
        public bool NeedUpdateStatus { get; set; }

        private DateTime? _LoginDate;
        public DateTime LoginDate { get => _LoginDate.HasValue ? _LoginDate.Value : DateTime.Now; set => _LoginDate = value; }
        private DateTime? _UnPauseDate;
        public DateTime UnPauseDate { get => _UnPauseDate.HasValue ? _UnPauseDate.Value : DateTime.Now; set => _UnPauseDate = value; }
        public double TotalTime { get; set; }

    }
}
