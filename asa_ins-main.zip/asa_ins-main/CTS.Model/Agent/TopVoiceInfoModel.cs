﻿using CTS.Common;

namespace CTS.Model.Agent
{
    public class TopVoiceInfoModel
    {
        public string FullName { get; set; }
        public bool IsLogin { get; set; }
        public bool IsLoginExtension { get; set; }
        public string Extension { get; set; }
        public bool GeneralStatusBool
        {
            get => Queues != null && Queues.Count > 0 && Queues.Any(x => x.StatusCode == AgentStatusConst.SanSang);
        }
        public string GeneralStatus
        {
            get
            {
                if (Queues != null && Queues.Count > 0)
                {
                    var g = Queues.GroupBy(x => x.StatusCode).Select(s => s.Key).ToList();
                    if (g.Count > 1)
                    {
                        if (Queues.Any(x => x.StatusCode == AgentStatusConst.SanSang))
                            return AgentStatusConst.SanSang;
                        else
                            return AgentStatusConst.ChuaSanSang;
                    }
                    else
                    {
                        return g.FirstOrDefault();
                    }
                }
                return AgentStatusConst.ChuaSanSang;
            }
        }
        public string GeneralStatusStr
        {
            get
            {
                return GeneralStatus switch
                {
                    AgentStatusConst.DangNhap => "Đăng nhập",
                    AgentStatusConst.SanSang => "Sẵn sàng",
                    AgentStatusConst.ChuaSanSang => "Chưa sẵn sàng",
                    AgentStatusConst.NghiTrua => "Nghỉ trưa",
                    AgentStatusConst.Email => "Email",
                    AgentStatusConst.Hop => "Đi họp",
                    AgentStatusConst.RaNgoai => "Ra ngoài",
                    AgentStatusConst.ViecRieng => "Việc riêng",
                    AgentStatusConst.AnToi => "Ăn tối",
                    AgentStatusConst.NhapLieu => "Nhập liệu",
                    AgentStatusConst.SUP_Logout => "Supervisor loại khỏi nhóm",
                    AgentStatusConst.RoiNhom => "Rời nhóm",
                    AgentStatusConst.VaoNhom => "Vào nhóm",
                    AgentStatusConst.RequestLogout => "Người dùng yêu cầu logout",
                    AgentStatusConst.SUP_Pause => "Supervisor đặt trạng thái tạm dừng",
                    AgentStatusConst.SUP_UnPause => "Supervisor đặt trạng thái sẵn sàng",
                    _ => "Chưa sẵn sàng",
                };
            }
        }
        public List<TopVoiceQueueInfoModel> Queues { get; set; }
    }

    public class TopVoiceQueueInfoModel
    {
        public Guid QueueId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string StatusCode { get; set; }
        public bool IsJoin { get; set; }
        public bool StatusCodeBool
        {
            get
            {
                return StatusCode switch
                {
                    AgentStatusConst.SanSang => true,
                    _ => false,
                };
            }
        }
        public string StatusCodeStr
        {
            get
            {
                return StatusCode switch
                {
                    AgentStatusConst.DangNhap => "Đăng nhập",
                    AgentStatusConst.SanSang => "Sẵn sàng",
                    AgentStatusConst.ChuaSanSang => "Chưa sẵn sàng",
                    _ => "Chưa sẵn sàng",
                };
            }
        }
    }
}
