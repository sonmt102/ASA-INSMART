﻿namespace CTS.Model.Agent
{
    public class CallOutBoundModel
    {
        public string Phone { get; set; }
        public Guid QueueId { get; set; }
        /// <summary>
        /// Đầu số gọi ra
        /// </summary>
        public Guid ExtensionId { get; set; }
        /// <summary>
        /// Số chính
        /// </summary>
        public bool IsPrimary { get; set; }
    }
}
