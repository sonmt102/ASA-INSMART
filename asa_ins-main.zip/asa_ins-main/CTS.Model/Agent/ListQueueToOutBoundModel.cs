﻿namespace CTS.Model.Agent
{
    public class ListQueueToOutBoundModel
    {
        public Guid QueueId { get; set; }
        public string QueueName { get; set; }
        public string QueueCode { get; set; }
        /// <summary>
        /// Danh sách đầu số được cấu hình trong queue
        /// </summary>
        public List<ListQueueToOutBoundExtensionModel> ExtensionIds { get; set; }
    }


    public class ListQueueToOutBoundExtensionModel
    {
        public Guid ExtensionId { get; set; }
        public string Phone { get; set; }
    }
}
