﻿using System.Globalization;
using CTS.Common;

namespace CTS.Model.Agent
{
    public class AgentCallCalendarModel
    {
        public int STT { get; set; }
        public string Id { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string? Note { get; set; }
        public string? CusPhone { get; set; }
    }

    public class UpdateAgentCallCalendarModel
    {
        public string Id { get; set; }
        public string DateStr { get; set; }
        public DateTime? Date
        {
            get
            {
                if (!string.IsNullOrEmpty(DateStr) && DateTime.TryParseExact(DateStr,
                              FormatDate.DateTime_ddMMyyyyHHmm, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fDate))
                {
                    return fDate;
                }
                return null;
            }
        }
        public string? Note { get; set; }
    }
}
