﻿namespace CTS.Model.Agent
{
    public class CallHistoryAgentModel
    {
        public int STT { get; set; }
        public string CallId { get; set; }
        public string? CallDirection { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Extension { get; set; }
        public string? Queue { get; set; }
        public string? Agent { get; set; }
        public DateTime? CallStartTime { get; set; }
        public DateTime? PickupTime { get; set; }
        /// <summary>
        /// Tổng số
        /// </summary>
        public int? LineDuration { get; set; }
        public int? HandleDuration { get; set; }
        public string? CallStatus { get; set; }
        public bool IsAnswer { get; set; }

        #region Lịch hẹn

        public CallHistoryAgentCalendarModel Calendar { get; set; }

        #endregion
    }

    public class CallHistoryAgentCalendarModel
    {
        public string CalendarDate { get; set; }
        public string CalendarNote { get; set; }
    }
}
