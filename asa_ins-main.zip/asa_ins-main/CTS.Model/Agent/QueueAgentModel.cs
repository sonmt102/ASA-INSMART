﻿namespace CTS.Model.Agent
{
    public class QueueAgentModel
    {
        public Guid QueueId { get; set; }
        public string QueueName { get; set; }
        public string QueueCode { get; set; }
        public int? Priority { get; set; }
        public string StatusCode { get; set; }
        public string StatusCodeStr { get; set; }
        public bool IsPause { get; set; }
    }
}
