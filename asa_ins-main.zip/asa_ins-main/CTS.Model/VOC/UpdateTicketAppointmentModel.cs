﻿using CTS.Common;
using System.Globalization;

namespace CTS.Model.VOC
{
    public class UpdateTicketAppointmentModel
    {
        public string DateStr { get; set; }
        public DateTime? Date
        {
            get
            {
                if (!string.IsNullOrEmpty(DateStr) && DateTime.TryParseExact(DateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string JobId { get; set; }
        public string Content { get; set; }
        public Guid TicketId { get; set; }
    }
}
