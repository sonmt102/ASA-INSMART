﻿namespace CTS.Model.VOC.Popup
{
    public class PopupIndexModel
    {
        public string Phone { get; set; }
        public string From { get; set; }
        public string Queue { get; set; }
    }
}
