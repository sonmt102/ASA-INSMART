﻿namespace CTS.Model.VOC.Popup
{
    public class CustomerModel
    {
        public Int64 Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Relation { get; set; }
        public Int64? ToChucId { get; set; }
        public int? LevelToChuc { get; set; }
        public bool IsCheck { get; set; }
    }

    public class CustomerDataLakeModel
    {
        public Int64 Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Relation { get; set; }
        public bool IsCheck { get; set; }
    }
}
