﻿using CTS.Common;
using CTS.Common.TAT;
using System.Net.NetworkInformation;

namespace CTS.Model.VOC.OP
{
    public class TicketOPDetail
    {
        public Guid Id { get; set; }
        public string MaSV { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerPhone { get; set; }

        public string CongTy { get; set; }
        public string CongTyStr { get; set; }
        public string CongTyMoiGioi { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiSuVuStr { get; set; }
        public string LoaiYeuCau { get; set; }
        public string LoaiYeuCauStr { get; set; }
        public string YeuCau { get; set; }
        public string YeuCauStr { get; set; }
        public bool Urgent { get; set; }

        public string LoaiHoSo { get; set; }
        public string LoaiHoSoStr { get; set; }
        public string LoaiKhieuNai { get; set; }
        public string LoaiKhieuNaiStr { get; set; }
        public string NguoiDuocBH { get; set; }
        public string BenMuaBH { get; set; }
        public DateTime? DOB { get; set; }
        public string DOBStr { get => DOB.HasValue ? DOB.Value.ToString(FormatDate.DateTime_103) : string.Empty; }
        public string CMND { get; set; }
        public string SoHopDong { get; set; }
        public string SoHoSo { get; set; }
        public string ClaimID { get; set; }

        public string NoiDungSV { get; set; }
        public string NoiDungCS { get; set; }
        public List<TicketDetail_ContentModel> CSHandlerContents { get; set; }
        public List<TicketDetail_ContentModel> Contents { get; set; }

        public List<TicketOPDetail_TransferOPModel> TransferOPs { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> CS_Attachs { get; set; }

    }


    public class TicketOPDetail_TransferOPModel
    {
        public Guid Id { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public string CTSV_BoPhanTLStr { get; set; }
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }

        public bool Urgent { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public string? PhuongAnGiaiQuyet { get; set; }
        public string? CSComment { get; set; }

        public string CongTyBH { get; set; }
        public string Ticket_KenhTiepNhan { get; set; }
        public string Ticket_LoaiKhieuNai { get; set; }
        public string Ticket_LoaiSuVu { get; set; }
        public string Ticket_LoaiYeuCau { get; set; }
        public string Ticket_YeuCau { get; set; }

        public OPHandler_Status Status { get; set; }
        public DateTime? OPHandlerDate { get; set; }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }

        public List<TicketOPDetail_TransferOP_ContentModel> Contents { get; set; }
        public List<TicketOPDetail_TransferOP_ContentModel> OP_Contents { get; set; }
        public List<TicketOPDetail_TransferOP_ContentModel> CTBH_Contents { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> OP_Attachs { get; set; }

        public string? OPContent_AddMore { get; set; }
        public string? CTBHContent_AddMore { get; set; }
        public int TATCounter
        {
            get
            {
                if (TransDate < new DateTime(2023, 09, 01))
                {
                    if (CTSV_BoPhanTL == CategoryConst.VOC_BoPhanThuLy_BLVP) return (int)VOC_TAT_Minute.OP_TAT_BLVP;
                    else return 240;
                }
                else
                {
                    return TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTyBH,
                        KenhTiepNhan = Ticket_KenhTiepNhan,
                        LoaiKhieuNai = Ticket_LoaiKhieuNai,
                        LoaiSuVu = Ticket_LoaiSuVu,
                        LoaiYeuCau = Ticket_LoaiYeuCau,
                        YeuCau = Ticket_YeuCau
                    }).OP;
                }
            }
        }

        public bool TAT
        {
            get
            {
                var timeToTAT = Status == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now) : DateTime.Now;
                return TATHelper.GetTATMinute(TransDate, timeToTAT, TATCounter);
            }
        }

        public string TATStr
        {
            get
            {
                if (Status == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                else
                {
                    return TAT ? "" : "Không đạt";
                }
            }
        }

        public string? InTimeTAT
        {
            get
            {
                if (TAT && Status != OPHandler_Status.DaXuLy)
                    return TATHelper.GetInTimeTAT(TransDate, TATCounter).ToString("yyyy/MM/dd HH:mm:ss");
                return null;
            }
        }
    }

    public class TicketOPDetail_TransferOP_ContentModel
    {
        public string Content { get; set; }
        public Guid TransferOPId { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CreatedBy { get; set; }
    }

    public class TicketOPDetail_TransferOP_AttachModel
    {
        public Guid Id { get; set; }
        public string RealName { get; set; }
        public string Name { get; set; }
        public string Extension { get; set; }
        public string Size { get; set; }
        public string Type { get; set; }
        public string TypeStr
        {
            get
            {
                switch (Type)
                {
                    case "application/pdf":
                        return "icon-file-pdf";
                    case "application/msword":
                        return "icon-file-word";
                    case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                        return "icon-file-excel";
                    case "image/png":
                        return "icon-image2";
                    default:
                        {
                            if (Type.Contains("image")) return "icon-image2";
                            else return "icon-attachment";
                        }
                }
            }
        }
        public Guid TransferId { get; set; }
    }
}
