﻿using CTS.Common;
using CTS.Common.TAT;
using CTS.Model.VOC.CS;
using System.Text.RegularExpressions;

namespace CTS.Model.VOC.OP
{
    public class OPHandlerModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string MaSV { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerPhone { get; set; }
        public string SoHS { get; set; }
        public string ClaimID { get; set; }
        public string NguoiDuocBH { get; set; }
        public string SoHD { get; set; }
        public string CongTy { get; set; }
        public string CongTyStr { get; set; }
        public string CongTyMoiGioi { get; set; }
        public string LoaiHoSo { get; set; }
        public string LoaiHoSoStr { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiSuVuStr { get; set; }
        public string LoaiYeuCau { get; set; }
        public string LoaiYeuCauStr { get; set; }
        public bool Urgent { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<OPHandlerTransferModel> TransferOPs { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
    }

    public class OPHandlerTransferModel
    {
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public OPHandler_Status Status { get; set; }
        public string StatusStr
        {
            get
            {
                switch (Status)
                {
                    case OPHandler_Status.ChuaXuLy:
                        return "Chưa xử lý";
                    case OPHandler_Status.DangXuLy:
                        {
                            var data = new List<string>();
                            if (CheckCTBH) data.Add("Trao đổi công ty bảo hiểm");
                            if (CheckCSYT) data.Add("Chờ xác nhận cơ sở y tế");
                            if (CheckBank) data.Add("Chờ xác nhận ngân hàng");
                            if (CheckHDCM) data.Add("Chờ xác nhận hội đồng chuyên môn");
                            if (data.Count > 0) return string.Join(", ", data);
                            return "Đang xử lý";
                        }
                    case OPHandler_Status.DaXuLy:
                        return "Đã xử lý";
                    case OPHandler_Status.PhuongAnChuaDayDu:
                        return "Phương án chưa đầy đủ";
                    case OPHandler_Status.KhongPhanHoi:
                        return "Không phản hồi";
                    default:
                        return "Trạng thái";
                }
            }
        }
        public bool CheckCSYT { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public string BoPhan { get; set; }
        public string BoPhanStr { get; set; }
        public DateTime? OPHandlerDate { get; set; }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool TAT
        {
            get => TATHelper.GetTATMinute(TransDate, Status == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now)
            : DateTime.Now, 240);
        }
        public string TATStr
        {
            get
            {
                if (Status == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                else
                {
                    return TAT ? "" : "Không đạt";
                }
            }
        }
    }

    public class OPTicketModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public Guid TicketId { get; set; }
        public string Code { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public bool Urgent { get; set; }
        public bool OPUrgent { get; set; }
        public string BoPhanThuLy { get; set; }
        public string BoPhanThuLyStr { get; set; }
        public string NguoiXuLy { get; set; }
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public OPHandler_Status OPStatus { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public string OPStatusStr
        {
            get
            {
                switch (OPStatus)
                {
                    case OPHandler_Status.ChuaXuLy:
                        return "Chưa xử lý";
                    case OPHandler_Status.DangXuLy:
                        {
                            var data = new List<string>();
                            if (CheckCTBH) data.Add("Trao đổi công ty bảo hiểm");
                            if (CheckCSYT) data.Add("Chờ xác nhận cơ sở y tế");
                            if (CheckBank) data.Add("Chờ xác nhận ngân hàng");
                            if (CheckHDCM) data.Add("Chờ xác nhận hội đồng chuyên môn");
                            if (data.Count > 0) return string.Join(", ", data);
                            return "Đang xử lý";
                        }
                    case OPHandler_Status.DaXuLy:
                        return "Đã xử lý";
                    case OPHandler_Status.PhuongAnChuaDayDu:
                        return "Phương án chưa đầy đủ";
                    case OPHandler_Status.KhongPhanHoi:
                        return "Không phản hồi";
                    default:
                        return "Trạng thái";
                }
            }
        }
        public string NDBH { get; set; }
        public string LoaiKhieuNai { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiYeuCau { get; set; }
        public string YeuCau { get; set; }
        public string LoaiHoSo { get; set; }
        public string SoHoSo { get; set; }
        public string TenChuHopDong { get; set; }
        public string SoHopDong { get; set; }
        public string CongTyBH { get; set; }
        public string CongTyBHStr { get; set; }
        public DateTime? OPHandlerDate { get; set; }
        public List<CSExportTicketContentModel> NoiDungSVs { get; set; }
        public string NoiDungSV
        {
            get
            {
                if (NoiDungSVs == null || NoiDungSVs.Count == 0) return string.Empty;
                var items = NoiDungSVs.Select(s => $"- {s.Content}\r\n").ToList();
                items = items.Select(s => System.Web.HttpUtility.HtmlDecode(s).Replace("<br/>", "\r\n").Replace("<br>", "\r\n")).ToList();
                for (int i = 0; i < items.Count; i++)
                {
                    var match = Regex.Match(items[i], "(?<=data:image\\/[a-zA-Z]+;base64,)[^\"]*");
                    if (!string.IsNullOrEmpty(match.Value))
                        items[i] = items[i].Replace(match.Value, "");
                    items[i] = Regex.Replace(items[i], "<.[^@]*?>", String.Empty);
                }
                var data = string.Join("\r\n\r\n", items);
                return data.Length > 10000 ? data[..10000] : data;
            }
        }

        public string Ticket_KenhTiepNhan { get; set; }
        public string Ticket_LoaiKhieuNai { get; set; }
        public string Ticket_LoaiSuVu { get; set; }
        public string Ticket_LoaiYeuCau { get; set; }
        public string Ticket_YeuCau { get; set; }

        public int TATCounter
        {
            get
            {
                if (TransDate < new DateTime(2023, 09, 01))
                {
                    if (BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) return (int)VOC_TAT_Minute.OP_TAT_BLVP;
                    else return 240;
                }
                else
                {
                    return TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTyBH,
                        KenhTiepNhan = Ticket_KenhTiepNhan,
                        LoaiKhieuNai = Ticket_LoaiKhieuNai,
                        LoaiSuVu = Ticket_LoaiSuVu,
                        LoaiYeuCau = Ticket_LoaiYeuCau,
                        YeuCau = Ticket_YeuCau
                    }).OP;
                }
            }
        }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool TAT
        {
            get
            {
                var timeToTAT = OPStatus == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now) : DateTime.Now;
                return TATHelper.GetTATMinute(TransDate, timeToTAT, TATCounter);
            }
        }
        public string TATStr
        {
            get
            {
                if (OPStatus == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                else
                {
                    return TAT ? "" : "Không đạt";
                }
            }
        }
        public string? InTimeTAT
        {
            get
            {
                if (TAT && OPStatus != OPHandler_Status.DaXuLy)
                    return TATHelper.GetInTimeTAT(TransDate, TATCounter).ToString("yyyy/MM/dd HH:mm:ss");
                return null;
            }
        }
        public int OrderStatus { get; set; }

        public List<CSExportTicketContentModel> NoiDungOPPhanHois { get; set; }
        public string NoiDungOPPhanHoi
        {
            get
            {
                if (NoiDungOPPhanHois == null || NoiDungOPPhanHois.Count == 0) return string.Empty;
                var items = NoiDungOPPhanHois.Select(s => $"- {s.Content}\r\n").ToList();
                items = items.Select(s => System.Web.HttpUtility.HtmlDecode(s).Replace("<br/>", "\r\n").Replace("<br>", "\r\n")).ToList();
                for (int i = 0; i < items.Count; i++)
                {
                    var match = Regex.Match(items[i], "(?<=data:image\\/[a-zA-Z]+;base64,)[^\"]*");
                    if (!string.IsNullOrEmpty(match.Value))
                        items[i] = items[i].Replace(match.Value, "");
                    items[i] = Regex.Replace(items[i], "<.[^@]*?>", String.Empty);
                }
                var data = string.Join("\r\n\r\n", items);
                return data.Length > 10000 ? data[..10000] : data;
            }
        }
        public string NguoiTiepNhanXuLy
        {
            get
            {
                if (NoiDungOPPhanHois == null || NoiDungOPPhanHois.Count == 0) return string.Empty;
                var d = NoiDungOPPhanHois.Select(s => s.CreatedBy).ToList();
                return string.Join("\n", d);
            }
        }

    }

    public class OPTicketV2Model
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public Guid TicketId { get; set; }
        public string Code { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public bool Urgent { get; set; }
        public bool OPUrgent { get; set; }
        public string BoPhanThuLy { get; set; }
        public string BoPhanThuLyStr { get; set; }
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public OPHandler_Status OPStatus { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public string OPStatusStr
        {
            get
            {
                switch (OPStatus)
                {
                    case OPHandler_Status.ChuaXuLy:
                        return "Chưa xử lý";
                    case OPHandler_Status.DangXuLy:
                        {
                            var data = new List<string>();
                            if (CheckCTBH) data.Add("Trao đổi công ty bảo hiểm");
                            if (CheckCSYT) data.Add("Chờ xác nhận cơ sở y tế");
                            if (CheckBank) data.Add("Chờ xác nhận ngân hàng");
                            if (CheckHDCM) data.Add("Chờ xác nhận hội đồng chuyên môn");
                            if (data.Count > 0) return string.Join(", ", data);
                            return "Đang xử lý";
                        }
                    case OPHandler_Status.DaXuLy:
                        return "Đã xử lý";
                    case OPHandler_Status.PhuongAnChuaDayDu:
                        return "Phương án chưa đầy đủ";
                    case OPHandler_Status.KhongPhanHoi:
                        return "Không phản hồi";
                    default:
                        return "Trạng thái";
                }
            }
        }
        public string NDBH { get; set; }
        public string LoaiKhieuNai { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiYeuCau { get; set; }
        public string YeuCau { get; set; }
        public string LoaiHoSo { get; set; }
        public string SoHoSo { get; set; }
        public string TenChuHopDong { get; set; }
        public string SoHopDong { get; set; }
        public string CongTyBH { get; set; }
        public DateTime? OPHandlerDate { get; set; }

        public string NoiDungSV { get; set; }

        public string Ticket_KenhTiepNhan { get; set; }
        public string Ticket_LoaiKhieuNai { get; set; }
        public string Ticket_LoaiSuVu { get; set; }
        public string Ticket_LoaiYeuCau { get; set; }
        public string Ticket_YeuCau { get; set; }

        public int TATCounter
        {
            get
            {
                if (TransDate < new DateTime(2023, 09, 01))
                {
                    if (BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) return (int)VOC_TAT_Minute.OP_TAT_BLVP;
                    else return 240;
                }
                else
                {
                    return TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTyBH,
                        KenhTiepNhan = Ticket_KenhTiepNhan,
                        LoaiKhieuNai = Ticket_LoaiKhieuNai,
                        LoaiSuVu = Ticket_LoaiSuVu,
                        LoaiYeuCau = Ticket_LoaiYeuCau,
                        YeuCau = Ticket_YeuCau
                    }).OP;
                }
            }
        }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool TAT
        {
            get => TATHelper.GetTATMinute(TransDate,
            OPStatus == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now) : DateTime.Now, TATCounter);
        }
        public string TATStr
        {
            get
            {
                if (OPStatus == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                else
                {
                    return TAT ? "" : "Không đạt";
                }
            }
        }
        public string? InTimeTAT
        {
            get
            {
                if (TAT && OPStatus != OPHandler_Status.DaXuLy)
                    return TATHelper.GetInTimeTAT(TransDate, TATCounter).ToString("yyyy/MM/dd HH:mm:ss");
                return null;
            }
        }
        public int OrderStatus { get; set; }

        public string NoiDungOPPhanHoi { get; set; }
        public List<string> NguoiTiepNhanXuLys { get; set; }
        public string NguoiTiepNhanXuLy { get => string.Join("; ", NguoiTiepNhanXuLys.GroupBy(x => x).Select(s => s.Key).ToList()); }
    }
}
