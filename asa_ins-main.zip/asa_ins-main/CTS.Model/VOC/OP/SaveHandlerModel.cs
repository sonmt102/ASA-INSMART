﻿using CTS.Common;
using System.Globalization;

namespace CTS.Model.VOC.OP
{
    public class SaveHandlerModel
    {
        public Guid Id { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public string? OPContent_AddMore { get; set; }
        public string? CTBHContent_AddMore { get; set; }
        public bool Urgent { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public OPHandler_Status Status { get; set; }
        public string PhuongAnGiaiQuyet { get; set; }
        public string OPHandlerDateStr { get; set; }
        public DateTime? OPHandlerDate
        {
            get
            {
                if (!string.IsNullOrEmpty(OPHandlerDateStr) && DateTime.TryParseExact(OPHandlerDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }

    }
}
