﻿using System.Globalization;

namespace CTS.Model.VOC.OP
{
    public class OPSummaryModel
    {
        public int Total { get; set; }
        public string TotalStr
        {
            get
            {
                if (Total == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return Total.ToString("#,###", cul.NumberFormat);
            }
        }
        public int ChuaXuLy { get; set; }
        public string ChuaXuLyStr
        {
            get
            {
                if (ChuaXuLy == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return ChuaXuLy.ToString("#,###", cul.NumberFormat);
            }
        }
        public int DaXuLy { get; set; }
        public string DaXuLyStr
        {
            get
            {
                if (DaXuLy == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return DaXuLy.ToString("#,###", cul.NumberFormat);
            }
        }
        public int DangXuLy { get; set; }
        public string DangXuLyStr
        {
            get
            {
                if (DangXuLy == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return DangXuLy.ToString("#,###", cul.NumberFormat);
            }
        }
        public int PhuongAnChuaDayDu { get; set; }
        public string PhuongAnChuaDayDuStr
        {
            get
            {
                if (PhuongAnChuaDayDu == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return PhuongAnChuaDayDu.ToString("#,###", cul.NumberFormat);
            }
        }
        public int KhongPhanHoi { get; set; }
        public string KhongPhanHoiStr
        {
            get
            {
                if (KhongPhanHoi == 0) return "0";
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");   // try with "en-US"
                return KhongPhanHoi.ToString("#,###", cul.NumberFormat);
            }
        }
        public object? Details { get; set; }
    }
}
