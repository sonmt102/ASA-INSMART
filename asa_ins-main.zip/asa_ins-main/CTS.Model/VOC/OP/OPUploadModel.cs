﻿namespace CTS.Model.VOC.OP
{
    public class OPUploadModel
    {
        public string Name { set; get; }
        public string RealName { set; get; }
        public string Type { set; get; }
        public string ExtensionFile { set; get; }
        public string Size { set; get; }
    }

    public class OPDownloadFileModel
    {
        public string Name { set; get; }
        public string RealName { set; get; }
        public string Type { set; get; }
        public string ExtensionFile { set; get; }
        
    }
}
