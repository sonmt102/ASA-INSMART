﻿using CTS.Common;
using System.Globalization;

namespace CTS.Model.VOC
{
    public class UpdateTicketStatusModel
    {
        public Guid TicketId { get; set; }
        public string HandlerDateStr { get; set; }
        public DateTime? HandlerDate
        {
            get
            {
                if (!string.IsNullOrEmpty(HandlerDateStr) && DateTime.TryParseExact(HandlerDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public VOCTicketStatus StatusStr { get; set; }
    }
}
