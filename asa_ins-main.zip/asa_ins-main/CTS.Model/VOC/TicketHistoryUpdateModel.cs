﻿using CTS.Common;

namespace CTS.Model.VOC
{
    public class TicketHistoryUpdateModel
    {
        public Guid Id { get; set; }
        public string MaSV { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerName { get; set; }
        public string CustomerRelation { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Hoàn thành",
                    _ => "Đóng",
                };
            }
        }
        public Guid AccountId { get; set; }
        public string AccountUserName { get; set; }
        public string VOCRequestTypeName { get; set; }
        public bool IsImportant { get; set; }
        public DateTime? HandlerDate { get; set; }
        public string HandlerDateStr { get => HandlerDate.HasValue ? HandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }
        public DateTime? CompleteDate { get; set; }
        public string CompleteDateStr { get => CompleteDate.HasValue ? CompleteDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
    }
}
