﻿using CTS.Common;
using CTS.Common.TAT;
using Newtonsoft.Json.Linq;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;

namespace CTS.Model.VOC.CS
{
    public class CSExportTicketModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string KenhTiepNhan { get; set; }
        public string Phone { get; set; }
        public string CustomerName { get; set; }
        public string CustomerType { get; set; }
        public string CustomerEmail { get; set; }
        public string CongTy { get; set; }
        public string MoiGioi { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiYeuCau { get; set; }
        public string YeuCau { get; set; }
        public string SoHD { get; set; }
        public string SoHS { get; set; }
        public string ClaimId { get; set; }
        public string LoaiHoSo { get; set; }
        public string NguoiDuocBH { get; set; }
        public string BenMuaBH { get; set; }
        public string NguyenNhanDTKN { get; set; }
        public List<CSExportTicketContentModel> NoiDungSVs { get; set; }
        public string NoiDungSV
        {
            get
            {
                if (NoiDungSVs == null || NoiDungSVs.Count == 0) return string.Empty;
                var items = NoiDungSVs.Select(s => $"- {s.CreatedDateStr} - {s.CreatedBy} \r\n{s.Content}").ToList();
                items = items.Select(s => System.Web.HttpUtility.HtmlDecode(s).Replace("<br/>", "\r\n").Replace("<br>", "\r\n")).ToList();
                for (int i = 0; i < items.Count; i++)
                {
                    var match = Regex.Match(items[i], "(?<=data:image\\/[a-zA-Z]+;base64,)[^\"]*");
                    if (!string.IsNullOrEmpty(match.Value))
                        items[i] = items[i].Replace(match.Value, "");
                    items[i] = Regex.Replace(items[i], "<.[^@]*?>", String.Empty);
                }
                var data = string.Join("\r\n\r\n", items);
                return data.Length > 10000 ? data[..10000] : data;
            }
        }
        public bool Urgent { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public List<string> UpdatedBys { get; set; }
        public string UpdatedByStr { get => string.Join(", ", UpdatedBys); }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime? CompleteDate { get; set; }
        public string CompleteDateStr { get => CompleteDate.HasValue ? CompleteDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool IsComplete { get; set; }
        public string CSContent { get; set; }
        public string NguoiXuLy { get; set; }
        public string TongThoiGianCSPhanHoiKH { get; set; }
        public int SoLanChuyenOP { get; set; }
        public List<CSExportTicketTransOPModel> TransferOPs { get; set; }
        public string TAT
        {
            get
            {
                if (TransferOPs != null && TransferOPs.Count > 0)
                {
                    if (TransferOPs.Count > 1)
                    {
                        var lastTrans = TransferOPs.OrderByDescending(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (lastTrans == null) return "Không đạt";
                        if (lastTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(lastTrans.TransDate, lastTrans.CSPhanHoiKH ?? DateTime.Now, 480);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            var check = TATHelper.GetTATMinute(lastTrans.TransDate, DateTime.Now, 480);
                            return check ? "" : "Không đạt";
                        }

                    }
                    else
                    {
                        if (TransferOPs[0].Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(CreatedDate, TransferOPs[0].CSPhanHoiKH ?? DateTime.Now, 480);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, 480);
                            return check ? "" : "Không đạt";
                        }
                    }

                }

                if (IsComplete)
                {
                    var check = TATHelper.GetTATMinute(CreatedDate, CompleteDate ?? DateTime.Now, 480);
                    return check ? "Đạt" : "Không đạt";
                }
                else
                {
                    var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, 480);
                    return check ? "" : "Không đạt";
                }
            }
        }

    }



    public class CSExportTicketContentModel
    {
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CreatedBy { get; set; }
        public string Content { get; set; }
    }

    public class CSExportTicketTransOP_V2Model
    {
        public DateTime? CSPhanHoiKH { get; set; }
        public string CSPhanHoiKHStr { get => CSPhanHoiKH.HasValue ? CSPhanHoiKH.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public DateTime TransDate { get; set; }
        public OPHandler_Status Status { get; set; }
        public string BoPhanTL { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }








        #region NÁT

        public string CongTyBH { get; set; }
        public string Ticket_KenhTiepNhan { get; set; }
        public string Ticket_LoaiKhieuNai { get; set; }
        public string Ticket_LoaiSuVu { get; set; }
        public string Ticket_LoaiYeuCau { get; set; }
        public string Ticket_YeuCau { get; set; }
        public DateTime? OPHandlerDate { get; set; }
        public OPHandler_Status OPStatus { get; set; }
        public int TATCounter
        {
            get
            {
                if (TransDate < new DateTime(2023, 09, 01))
                {
                    if (BoPhanTL == CategoryConst.VOC_BoPhanThuLy_BLVP) return (int)VOC_TAT_Minute.OP_TAT_BLVP;
                    else return 240;
                }
                else
                {
                    return TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTyBH,
                        KenhTiepNhan = Ticket_KenhTiepNhan,
                        LoaiKhieuNai = Ticket_LoaiKhieuNai,
                        LoaiSuVu = Ticket_LoaiSuVu,
                        LoaiYeuCau = Ticket_LoaiYeuCau,
                        YeuCau = Ticket_YeuCau
                    }).OP;
                }
            }
        }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool TAT
        {
            get => TATHelper.GetTATMinute(TransDate,
            OPStatus == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now) : DateTime.Now, TATCounter);
        }
        public string TATStr
        {
            get
            {
                if (OPStatus == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                else
                {
                    return TAT ? "" : "Không đạt";
                }
            }
        }

        #endregion
    }

    public class CSExportTicketTransOPModel
    {
        public string BoPhanThuLy { get; set; }
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string TongThoiGianOPPhanHoi { get; set; }
        public string TongThoiGianCSPhanHoi { get; set; }
        public string PhuongAnGiaiQuyet { get; set; }
        public bool CheckCTBH { get; set; }
        public string CheckCTBHStr { get => CheckCTBH ? "Có" : "Không"; }
        public bool CheckBank { get; set; }
        public string CheckBankStr { get => CheckBank ? "Có" : "Không"; }
        public bool CheckCSYT { get; set; }
        public string CheckCSYTStr { get => CheckCSYT ? "Có" : "Không"; }
        public bool CheckHDCM { get; set; }
        public string CheckHDCMStr { get => CheckHDCM ? "Có" : "Không"; }
        public DateTime? CSPhanHoiKH { get; set; }
        public string CSPhanHoiKHStr
        {
            get =>
                CSPhanHoiKH.HasValue ? CSPhanHoiKH.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty;
        }
        public OPHandler_Status Status { get; set; }
        public string StatusStr
        {
            get
            {
                switch (Status)
                {
                    case OPHandler_Status.ChuaXuLy:
                        return "Chưa xử lý";
                    case OPHandler_Status.DangXuLy:
                        {
                            var data = new List<string>();
                            if (CheckCTBH) data.Add("Trao đổi CTBH");
                            if (CheckCSYT) data.Add("Chờ xác nhận CSYT");
                            if (CheckBank) data.Add("Chờ xác nhận NH");
                            if (data.Count > 0) return string.Join(", ", data);
                            return "Đang xử lý";
                        }
                    case OPHandler_Status.DaXuLy:
                        return "Đã xử lý";
                    case OPHandler_Status.PhuongAnChuaDayDu:
                        return "PA chưa đầy đủ";
                    case OPHandler_Status.KhongPhanHoi:
                        return "Không phản hồi";
                    default:
                        return "Trạng thái";
                }
            }
        }
        public DateTime? OPHandlerDate { get; set; }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }

        public string Ticket_CongTy { get; set; }
        public string Ticket_KenhTiepNhan { get; set; }
        public string Ticket_LoaiKhieuNai { get; set; }
        public string Ticket_LoaiSuVu { get; set; }
        public string Ticket_LoaiYeuCau { get; set; }
        public string Ticket_YeuCau { get; set; }


        public bool TAT
        {
            get
            {
                int minute;
                if (TransDate < new DateTime(2023, 09, 01))
                    minute = BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP ? (int)VOC_TAT_Minute.OP_TAT_BLVP : (int)VOC_TAT_Minute.OP_TAT_NO_BLVP;
                else
                    minute = TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = Ticket_CongTy,
                        KenhTiepNhan = Ticket_KenhTiepNhan,
                        LoaiKhieuNai = Ticket_LoaiKhieuNai,
                        LoaiSuVu = Ticket_LoaiSuVu,
                        LoaiYeuCau = Ticket_LoaiYeuCau,
                        YeuCau = Ticket_YeuCau
                    }).OP;
                return TATHelper.GetTATMinute(TransDate, Status == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now) : DateTime.Now, minute);
            }
        }
        public string TATStr
        {
            get
            {
                if (Status == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                else
                {
                    return TAT ? "" : "Không đạt";
                }
            }
        }
        public List<CSExportTicketContentModel> OPContents { get; set; }
        public string OPContent
        {
            get
            {
                if (OPContents == null || OPContents.Count == 0) return string.Empty;
                var items = OPContents.Select(s => $"- {s.CreatedDateStr} - {s.CreatedBy} \r\n{s.Content}").ToList();
                items = items.Select(s => System.Web.HttpUtility.HtmlDecode(s).Replace("<br/>", "\r\n").Replace("<br>", "\r\n")).ToList();
                for (int i = 0; i < items.Count; i++)
                {
                    var match = Regex.Match(items[i], "(?<=data:image\\/[a-zA-Z]+;base64,)[^\"]*");
                    if (!string.IsNullOrEmpty(match.Value))
                        items[i] = items[i].Replace(match.Value, "");
                    items[i] = Regex.Replace(items[i], "<.[^@]*?>", String.Empty);
                }
                var data = string.Join("\r\n\r\n", items);
                //return data.Length > 20000 ? data[..20000] : data;
                #region Xử lý gộp nội dung

                var sp = "\n";
                return $@"Bộ phận thụ lý: {BoPhanThuLy}{sp}
Thời gian chuyển: {TransDateStr}{sp}
Nội dung OP phản hồi:{sp} {(data.Length > 20000 ? data[..20000] : data)}
Thời gian OP phản hồi phương án: {OPHandlerDateStr}{sp}
Tổng Thời gian OP phản hồi: {TongThoiGianOPPhanHoi}{sp}
Tổng Thời gian CS phản hồi: {TongThoiGianCSPhanHoi}{sp}
TAT: {TATStr}{sp}
Trạng thái: {StatusStr}{sp}
Phương án giải quyết: {PhuongAnGiaiQuyet}{sp}
Thời gian CS phản hồi KH: {CSPhanHoiKHStr}{sp}
Tổng thời gian CS phản hồi: {CSPhanHoiKHStr}{sp}
Trao đổi CTBH: {CheckCTBHStr}{sp}
Chờ xác nhận CSYT: {CheckCSYTStr}{sp}
Chờ xác nhận Ngân hàng: {CheckBankStr}{sp}
Chờ ý kiến HĐCM: {CheckHDCMStr}
                        ";

                #endregion


            }
        }


    }

    public class CSExportTicketTransOP_NoContentModel
    {
        public string BoPhanThuLy { get; set; }
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string TongThoiGianOPPhanHoi { get; set; }
        public string TongThoiGianCSPhanHoi { get; set; }
        public string PhuongAnGiaiQuyet { get; set; }
        public bool CheckCTBH { get; set; }
        public string CheckCTBHStr { get => CheckCTBH ? "Có" : "Không"; }
        public bool CheckBank { get; set; }
        public string CheckBankStr { get => CheckBank ? "Có" : "Không"; }
        public bool CheckCSYT { get; set; }
        public string CheckCSYTStr { get => CheckCSYT ? "Có" : "Không"; }
        public bool CheckHDCM { get; set; }
        public string CheckHDCMStr { get => CheckHDCM ? "Có" : "Không"; }

        public string Ticket_CongTy { get; set; }
        public string Ticket_KenhTiepNhan { get; set; }
        public string Ticket_LoaiKhieuNai { get; set; }
        public string Ticket_LoaiSuVu { get; set; }
        public string Ticket_LoaiYeuCau { get; set; }
        public string Ticket_YeuCau { get; set; }

        public DateTime? CSPhanHoiKH { get; set; }
        public string CSPhanHoiKHStr
        {
            get =>
                CSPhanHoiKH.HasValue ? CSPhanHoiKH.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty;
        }
        public OPHandler_Status Status { get; set; }
        public string StatusStr
        {
            get
            {
                switch (Status)
                {
                    case OPHandler_Status.ChuaXuLy:
                        return "Chưa xử lý";
                    case OPHandler_Status.DangXuLy:
                        {
                            var data = new List<string>();
                            if (CheckCTBH) data.Add("Trao đổi CTBH");
                            if (CheckCSYT) data.Add("Chờ xác nhận CSYT");
                            if (CheckBank) data.Add("Chờ xác nhận NH");
                            if (CheckHDCM) data.Add("Chờ xác nhận HĐCM");
                            if (data.Count > 0) return string.Join(", ", data);
                            return "Đang xử lý";
                        }
                    case OPHandler_Status.DaXuLy:
                        return "Đã xử lý";
                    case OPHandler_Status.PhuongAnChuaDayDu:
                        return "PA chưa đầy đủ";
                    case OPHandler_Status.KhongPhanHoi:
                        return "Không phản hồi";
                    default:
                        return "Trạng thái";
                }
            }
        }
        public DateTime? OPHandlerDate { get; set; }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool TAT
        {
            get
            {
                int minute;
                if (TransDate < new DateTime(2023, 09, 01))
                    minute = BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP ? (int)VOC_TAT_Minute.OP_TAT_BLVP : (int)VOC_TAT_Minute.OP_TAT_NO_BLVP;
                else
                    minute = TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = Ticket_CongTy,
                        KenhTiepNhan = Ticket_KenhTiepNhan,
                        LoaiKhieuNai = Ticket_LoaiKhieuNai,
                        LoaiSuVu = Ticket_LoaiSuVu,
                        LoaiYeuCau = Ticket_LoaiYeuCau,
                        YeuCau = Ticket_YeuCau
                    }).OP;
                return TATHelper.GetTATMinute(TransDate, Status == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now) : DateTime.Now, minute);
            }
        }
        public string TATStr
        {
            get
            {
                if (Status == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                else
                {
                    return TAT ? "" : "Không đạt";
                }
            }
        }

        public string OPContent
        {
            get
            {
                #region Xử lý gộp nội dung

                var sp = "\n";
                return $@"Bộ phận thụ lý: {BoPhanThuLy}{sp}
Thời gian chuyển: {TransDateStr}{sp}
Thời gian OP phản hồi phương án: {OPHandlerDateStr}{sp}
Tổng Thời gian OP phản hồi: {TongThoiGianOPPhanHoi}{sp}
Tổng Thời gian CS phản hồi: {TongThoiGianCSPhanHoi}{sp}
TAT: {TATStr}{sp}
Trạng thái: {StatusStr}{sp}
Phương án giải quyết: {PhuongAnGiaiQuyet}{sp}
Thời gian CS phản hồi KH: {CSPhanHoiKHStr}{sp}
Tổng thời gian CS phản hồi: {CSPhanHoiKHStr}{sp}
Trao đổi CTBH: {CheckCTBHStr}{sp}
Chờ xác nhận CSYT: {CheckCSYTStr}{sp}
Chờ xác nhận Ngân hàng: {CheckBankStr}{sp}
Chờ ý kiến HĐCM: {CheckHDCMStr}
                        ";

                #endregion


            }
        }

    }

}
