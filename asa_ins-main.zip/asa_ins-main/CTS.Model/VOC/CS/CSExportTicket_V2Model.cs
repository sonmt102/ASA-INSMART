﻿using CTS.Common;
using CTS.Common.TAT;

namespace CTS.Model.VOC.CS
{
    public class CSExportTicket_V2Model
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string KenhTiepNhan { get; set; }
        public string KenhTiepNhanStr { get; set; }
        public DateTime? ThoiGianTiepNhanEmail { get; set; }
        public string Phone { get; set; }
        public string CustomerName { get; set; }
        public string CustomerType { get; set; }
        public string CustomerEmail { get; set; }
        public DateTime? NextReminderDate { get; set; }
        public string? NextReminderDateStr { get => NextReminderDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CongTy { get; set; }
        public string CongTyStr { get; set; }
        public string MoiGioi { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiSuVuStr { get; set; }
        public string LoaiYeuCau { get; set; }
        public string LoaiYeuCauStr { get; set; }
        public string YeuCau { get; set; }
        public string YeuCauStr { get; set; }
        public string LoaiKhieuNai { get; set; }
        public string LoaiKhieuNaiStr { get; set; }
        public string SoHD { get; set; }
        public string SoHS { get; set; }
        public string ClaimId { get; set; }
        public string LoaiHoSo { get; set; }
        public string NguoiDuocBH { get; set; }
        public string BenMuaBH { get; set; }
        public string NguyenNhanDTKN { get; set; }
        public string NoiDungSV { get; set; }
        public bool Urgent { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public string UpdatedByStr { get; set; }
        //public string LastUpdateByStr { get => UpdatedByStr.Split(",")[0].Trim(); }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime? CompleteDate { get; set; }
        public string CompleteDateStr { get => CompleteDate.HasValue ? CompleteDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool IsComplete { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public string CSPhanHoiKHStr
        {
            get
            {
                if (TransferOPs != null && TransferOPs.Count > 0)
                {
                    var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                    var myDate = firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? CompleteDate;
                    return myDate.HasValue ? myDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty;
                }
                else
                {
                    var myDate = CSPhanHoiKH ?? CompleteDate;
                    return myDate.HasValue ? myDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty;
                }
            }
        }
        public string CSContent { get; set; }
        public string NguoiXuLy { get; set; }
        public string TongThoiGianCSPhanHoiKH { get; set; }
        public int SoLanChuyenOP { get; set; }
        public string BoPhanThuLy { get; set; }
        public List<CSExportTicketTransOP_V2Model> TransferOPs { get; set; }
        public string TAT
        {
            get
            {
                #region Trước 1/9/2023
                if (CreatedDate < new DateTime(2023, 09, 01))
                {
                    var _TATCounter = 480;
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        if (TransferOPs.Count > 1)
                        {
                            var lastTrans = TransferOPs.OrderByDescending(s => s.TransDate).Select(s => s).FirstOrDefault();
                            if (lastTrans == null) return "Không đạt";
                            if (lastTrans.BoPhanTL == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = 60;

                            if (lastTrans.Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, lastTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }

                        }
                        else
                        {
                            if (TransferOPs[0].BoPhanTL == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = 60;
                            if (TransferOPs[0].Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, TransferOPs[0].CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }

                    }

                    if (IsComplete)
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }
                #endregion

                #region Bắt đầu từ 1/9/20223
                else
                {
                    var _TATCounter = TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTy,
                        KenhTiepNhan = KenhTiepNhan,
                        LoaiKhieuNai = LoaiKhieuNai,
                        LoaiSuVu = LoaiSuVu,
                        LoaiYeuCau = LoaiYeuCau,
                        YeuCau = YeuCau
                    }).CS;

                    var myStartDate = TATKenhTiepNhanConst.KenhEmails.Contains(KenhTiepNhan) ? (ThoiGianTiepNhanEmail ?? CreatedDate) : CreatedDate;

                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (firstTrans == null) return "Không đạt";

                        if (firstTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            if (firstTrans.CSPhanHoiKH.HasValue || CSPhanHoiKH.HasValue || CompleteDate.HasValue)
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }
                    }
                    else if ((IsComplete && CompleteDate.HasValue) || CSPhanHoiKH.HasValue)
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, CSPhanHoiKH ?? CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }
                #endregion
            }
        }

        #region Check CTBH
        public bool CheckCTBH1 { get; set; }
        public string CheckCTBH1Str { get => !string.IsNullOrEmpty(LanChuyen1) ? (CheckCTBH1 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH2 { get; set; }
        public string CheckCTBH2Str { get => !string.IsNullOrEmpty(LanChuyen2) ? (CheckCTBH2 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH3 { get; set; }
        public string CheckCTBH3Str { get => !string.IsNullOrEmpty(LanChuyen3) ? (CheckCTBH3 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH4 { get; set; }
        public string CheckCTBH4Str { get => !string.IsNullOrEmpty(LanChuyen4) ? (CheckCTBH4 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH5 { get; set; }
        public string CheckCTBH5Str { get => !string.IsNullOrEmpty(LanChuyen5) ? (CheckCTBH5 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH6 { get; set; }
        public string CheckCTBH6Str { get => !string.IsNullOrEmpty(LanChuyen6) ? (CheckCTBH6 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH7 { get; set; }
        public string CheckCTBH7Str { get => !string.IsNullOrEmpty(LanChuyen7) ? (CheckCTBH7 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH8 { get; set; }
        public string CheckCTBH8Str { get => !string.IsNullOrEmpty(LanChuyen8) ? (CheckCTBH8 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH9 { get; set; }
        public string CheckCTBH9Str { get => !string.IsNullOrEmpty(LanChuyen9) ? (CheckCTBH9 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH10 { get; set; }
        public string CheckCTBH10Str { get => !string.IsNullOrEmpty(LanChuyen10) ? (CheckCTBH10 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH11 { get; set; }
        public string CheckCTBH11Str { get => !string.IsNullOrEmpty(LanChuyen11) ? (CheckCTBH11 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH12 { get; set; }
        public string CheckCTBH12Str { get => !string.IsNullOrEmpty(LanChuyen12) ? (CheckCTBH12 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH13 { get; set; }
        public string CheckCTBH13Str { get => !string.IsNullOrEmpty(LanChuyen13) ? (CheckCTBH13 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH14 { get; set; }
        public string CheckCTBH14Str { get => !string.IsNullOrEmpty(LanChuyen14) ? (CheckCTBH14 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH15 { get; set; }
        public string CheckCTBH15Str { get => !string.IsNullOrEmpty(LanChuyen15) ? (CheckCTBH15 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH16 { get; set; }
        public string CheckCTBH16Str { get => !string.IsNullOrEmpty(LanChuyen16) ? (CheckCTBH16 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH17 { get; set; }
        public string CheckCTBH17Str { get => !string.IsNullOrEmpty(LanChuyen17) ? (CheckCTBH17 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH18 { get; set; }
        public string CheckCTBH18Str { get => !string.IsNullOrEmpty(LanChuyen18) ? (CheckCTBH18 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH19 { get; set; }
        public string CheckCTBH19Str { get => !string.IsNullOrEmpty(LanChuyen19) ? (CheckCTBH19 ? "Có" : "Không") : string.Empty; }
        public bool CheckCTBH20 { get; set; }
        public string CheckCTBH20Str { get => !string.IsNullOrEmpty(LanChuyen20) ? (CheckCTBH20 ? "Có" : "Không") : string.Empty; }
        #endregion

        #region Check CSYT

        public bool CheckCSYT1 { get; set; }
        public string CheckCSYT1Str { get => !string.IsNullOrEmpty(LanChuyen1) ? (CheckCSYT1 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT2 { get; set; }
        public string CheckCSYT2Str { get => !string.IsNullOrEmpty(LanChuyen2) ? (CheckCSYT2 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT3 { get; set; }
        public string CheckCSYT3Str { get => !string.IsNullOrEmpty(LanChuyen3) ? (CheckCSYT3 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT4 { get; set; }
        public string CheckCSYT4Str { get => !string.IsNullOrEmpty(LanChuyen4) ? (CheckCSYT4 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT5 { get; set; }
        public string CheckCSYT5Str { get => !string.IsNullOrEmpty(LanChuyen5) ? (CheckCSYT5 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT6 { get; set; }
        public string CheckCSYT6Str { get => !string.IsNullOrEmpty(LanChuyen6) ? (CheckCSYT6 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT7 { get; set; }
        public string CheckCSYT7Str { get => !string.IsNullOrEmpty(LanChuyen7) ? (CheckCSYT7 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT8 { get; set; }
        public string CheckCSYT8Str { get => !string.IsNullOrEmpty(LanChuyen8) ? (CheckCSYT8 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT9 { get; set; }
        public string CheckCSYT9Str { get => !string.IsNullOrEmpty(LanChuyen9) ? (CheckCSYT9 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT10 { get; set; }
        public string CheckCSYT10Str { get => !string.IsNullOrEmpty(LanChuyen10) ? (CheckCSYT10 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT11 { get; set; }
        public string CheckCSYT11Str { get => !string.IsNullOrEmpty(LanChuyen11) ? (CheckCSYT11 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT12 { get; set; }
        public string CheckCSYT12Str { get => !string.IsNullOrEmpty(LanChuyen12) ? (CheckCSYT12 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT13 { get; set; }
        public string CheckCSYT13Str { get => !string.IsNullOrEmpty(LanChuyen13) ? (CheckCSYT13 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT14 { get; set; }
        public string CheckCSYT14Str { get => !string.IsNullOrEmpty(LanChuyen14) ? (CheckCSYT14 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT15 { get; set; }
        public string CheckCSYT15Str { get => !string.IsNullOrEmpty(LanChuyen15) ? (CheckCSYT15 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT16 { get; set; }
        public string CheckCSYT16Str { get => !string.IsNullOrEmpty(LanChuyen16) ? (CheckCSYT16 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT17 { get; set; }
        public string CheckCSYT17Str { get => !string.IsNullOrEmpty(LanChuyen17) ? (CheckCSYT17 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT18 { get; set; }
        public string CheckCSYT18Str { get => !string.IsNullOrEmpty(LanChuyen18) ? (CheckCSYT18 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT19 { get; set; }
        public string CheckCSYT19Str { get => !string.IsNullOrEmpty(LanChuyen19) ? (CheckCSYT19 ? "Có" : "Không") : string.Empty; }
        public bool CheckCSYT20 { get; set; }
        public string CheckCSYT20Str { get => !string.IsNullOrEmpty(LanChuyen20) ? (CheckCSYT20 ? "Có" : "Không") : string.Empty; }

        #endregion

        #region Check Bank

        public bool CheckBank1 { get; set; }
        public string CheckBank1Str { get => !string.IsNullOrEmpty(LanChuyen1) ? (CheckBank1 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank2 { get; set; }
        public string CheckBank2Str { get => !string.IsNullOrEmpty(LanChuyen2) ? (CheckBank2 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank3 { get; set; }
        public string CheckBank3Str { get => !string.IsNullOrEmpty(LanChuyen3) ? (CheckBank3 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank4 { get; set; }
        public string CheckBank4Str { get => !string.IsNullOrEmpty(LanChuyen4) ? (CheckBank4 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank5 { get; set; }
        public string CheckBank5Str { get => !string.IsNullOrEmpty(LanChuyen5) ? (CheckBank5 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank6 { get; set; }
        public string CheckBank6Str { get => !string.IsNullOrEmpty(LanChuyen6) ? (CheckBank6 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank7 { get; set; }
        public string CheckBank7Str { get => !string.IsNullOrEmpty(LanChuyen7) ? (CheckBank7 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank8 { get; set; }
        public string CheckBank8Str { get => !string.IsNullOrEmpty(LanChuyen8) ? (CheckBank8 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank9 { get; set; }
        public string CheckBank9Str { get => !string.IsNullOrEmpty(LanChuyen9) ? (CheckBank9 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank10 { get; set; }
        public string CheckBank10Str { get => !string.IsNullOrEmpty(LanChuyen10) ? (CheckBank10 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank11 { get; set; }
        public string CheckBank11Str { get => !string.IsNullOrEmpty(LanChuyen11) ? (CheckBank11 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank12 { get; set; }
        public string CheckBank12Str { get => !string.IsNullOrEmpty(LanChuyen12) ? (CheckBank12 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank13 { get; set; }
        public string CheckBank13Str { get => !string.IsNullOrEmpty(LanChuyen13) ? (CheckBank13 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank14 { get; set; }
        public string CheckBank14Str { get => !string.IsNullOrEmpty(LanChuyen14) ? (CheckBank14 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank15 { get; set; }
        public string CheckBank15Str { get => !string.IsNullOrEmpty(LanChuyen15) ? (CheckBank15 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank16 { get; set; }
        public string CheckBank16Str { get => !string.IsNullOrEmpty(LanChuyen16) ? (CheckBank16 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank17 { get; set; }
        public string CheckBank17Str { get => !string.IsNullOrEmpty(LanChuyen17) ? (CheckBank17 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank18 { get; set; }
        public string CheckBank18Str { get => !string.IsNullOrEmpty(LanChuyen18) ? (CheckBank18 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank19 { get; set; }
        public string CheckBank19Str { get => !string.IsNullOrEmpty(LanChuyen19) ? (CheckBank19 ? "Có" : "Không") : string.Empty; }
        public bool CheckBank20 { get; set; }
        public string CheckBank20Str { get => !string.IsNullOrEmpty(LanChuyen20) ? (CheckBank20 ? "Có" : "Không") : string.Empty; }

        #endregion

        #region Check HĐCM

        public bool CheckHDCM1 { get; set; }
        public string CheckHDCM1Str { get => !string.IsNullOrEmpty(LanChuyen1) ? (CheckHDCM1 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM2 { get; set; }
        public string CheckHDCM2Str { get => !string.IsNullOrEmpty(LanChuyen2) ? (CheckHDCM2 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM3 { get; set; }
        public string CheckHDCM3Str { get => !string.IsNullOrEmpty(LanChuyen3) ? (CheckHDCM3 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM4 { get; set; }
        public string CheckHDCM4Str { get => !string.IsNullOrEmpty(LanChuyen4) ? (CheckHDCM4 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM5 { get; set; }
        public string CheckHDCM5Str { get => !string.IsNullOrEmpty(LanChuyen5) ? (CheckHDCM5 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM6 { get; set; }
        public string CheckHDCM6Str { get => !string.IsNullOrEmpty(LanChuyen6) ? (CheckHDCM6 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM7 { get; set; }
        public string CheckHDCM7Str { get => !string.IsNullOrEmpty(LanChuyen7) ? (CheckHDCM7 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM8 { get; set; }
        public string CheckHDCM8Str { get => !string.IsNullOrEmpty(LanChuyen8) ? (CheckHDCM8 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM9 { get; set; }
        public string CheckHDCM9Str { get => !string.IsNullOrEmpty(LanChuyen9) ? (CheckHDCM9 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM10 { get; set; }
        public string CheckHDCM10Str { get => !string.IsNullOrEmpty(LanChuyen10) ? (CheckHDCM10 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM11 { get; set; }
        public string CheckHDCM11Str { get => !string.IsNullOrEmpty(LanChuyen11) ? (CheckHDCM11 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM12 { get; set; }
        public string CheckHDCM12Str { get => !string.IsNullOrEmpty(LanChuyen12) ? (CheckHDCM12 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM13 { get; set; }
        public string CheckHDCM13Str { get => !string.IsNullOrEmpty(LanChuyen13) ? (CheckHDCM13 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM14 { get; set; }
        public string CheckHDCM14Str { get => !string.IsNullOrEmpty(LanChuyen14) ? (CheckHDCM14 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM15 { get; set; }
        public string CheckHDCM15Str { get => !string.IsNullOrEmpty(LanChuyen15) ? (CheckHDCM15 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM16 { get; set; }
        public string CheckHDCM16Str { get => !string.IsNullOrEmpty(LanChuyen16) ? (CheckHDCM16 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM17 { get; set; }
        public string CheckHDCM17Str { get => !string.IsNullOrEmpty(LanChuyen17) ? (CheckHDCM17 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM18 { get; set; }
        public string CheckHDCM18Str { get => !string.IsNullOrEmpty(LanChuyen18) ? (CheckHDCM18 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM19 { get; set; }
        public string CheckHDCM19Str { get => !string.IsNullOrEmpty(LanChuyen19) ? (CheckHDCM19 ? "Có" : "Không") : string.Empty; }
        public bool CheckHDCM20 { get; set; }
        public string CheckHDCM20Str { get => !string.IsNullOrEmpty(LanChuyen20) ? (CheckHDCM20 ? "Có" : "Không") : string.Empty; }

        #endregion




        public string? TATLanChuyen1Str { get; set; }
        public string? TATLanChuyen2Str { get; set; }
        public string? TATLanChuyen3Str { get; set; }
        public string? TATLanChuyen4Str { get; set; }
        public string? TATLanChuyen5Str { get; set; }
        public string? TATLanChuyen6Str { get; set; }
        public string? TATLanChuyen7Str { get; set; }
        public string? TATLanChuyen8Str { get; set; }
        public string? TATLanChuyen9Str { get; set; }
        public string? TATLanChuyen10Str { get; set; }
        public string? TATLanChuyen11Str { get; set; }
        public string? TATLanChuyen12Str { get; set; }
        public string? TATLanChuyen13Str { get; set; }
        public string? TATLanChuyen14Str { get; set; }
        public string? TATLanChuyen15Str { get; set; }
        public string? TATLanChuyen16Str { get; set; }
        public string? TATLanChuyen17Str { get; set; }
        public string? TATLanChuyen18Str { get; set; }
        public string? TATLanChuyen19Str { get; set; }
        public string? TATLanChuyen20Str { get; set; }


        public string? CSPhanHoiKH1Str { get; set; }
        public string? CSPhanHoiKH2Str { get; set; }
        public string? CSPhanHoiKH3Str { get; set; }
        public string? CSPhanHoiKH4Str { get; set; }
        public string? CSPhanHoiKH5Str { get; set; }
        public string? CSPhanHoiKH6Str { get; set; }
        public string? CSPhanHoiKH7Str { get; set; }
        public string? CSPhanHoiKH8Str { get; set; }
        public string? CSPhanHoiKH9Str { get; set; }
        public string? CSPhanHoiKH10Str { get; set; }
        public string? CSPhanHoiKH11Str { get; set; }
        public string? CSPhanHoiKH12Str { get; set; }
        public string? CSPhanHoiKH13Str { get; set; }
        public string? CSPhanHoiKH14Str { get; set; }
        public string? CSPhanHoiKH15Str { get; set; }
        public string? CSPhanHoiKH16Str { get; set; }
        public string? CSPhanHoiKH17Str { get; set; }
        public string? CSPhanHoiKH18Str { get; set; }
        public string? CSPhanHoiKH19Str { get; set; }
        public string? CSPhanHoiKH20Str { get; set; }
        public string? LanChuyen1 { get; set; }
        public string? LanChuyen2 { get; set; }
        public string? LanChuyen3 { get; set; }
        public string? LanChuyen4 { get; set; }
        public string? LanChuyen5 { get; set; }
        public string? LanChuyen6 { get; set; }
        public string? LanChuyen7 { get; set; }
        public string? LanChuyen8 { get; set; }
        public string? LanChuyen9 { get; set; }
        public string? LanChuyen10 { get; set; }
        public string? LanChuyen11 { get; set; }
        public string? LanChuyen12 { get; set; }
        public string? LanChuyen13 { get; set; }
        public string? LanChuyen14 { get; set; }
        public string? LanChuyen15 { get; set; }
        public string? LanChuyen16 { get; set; }
        public string? LanChuyen17 { get; set; }
        public string? LanChuyen18 { get; set; }
        public string? LanChuyen19 { get; set; }
        public string? LanChuyen20 { get; set; }

    }
}
