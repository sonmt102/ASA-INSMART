﻿using CTS.Common;
using CTS.Common.TAT;

namespace CTS.Model.VOC.CS
{
    public class CSExportListTicketModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiSuVuStr { get; set; }
        public string LoaiYeuCau { get; set; }
        public string LoaiYeuCauStr { get; set; }
        public string KenhTiepNhan { get; set; }
        public string KenhTiepNhanStr { get; set; }
        public string LoaiKhieuNai { get; set; }
        public string LoaiKhieuNaiStr { get; set; }
        public string YeuCau { get; set; }
        public string YeuCauStr { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public DateTime? ThoiGianTiepNhanEmail { get; set; }
        public bool Urgent { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public string CongTy { get; set; }
        public string CongTyStr { get; set; }
        public string MoiGioi { get; set; }
        public string SoHopDong { get; set; }
        public string SoHoSo { get; set; }
        public string NguoiTiepNhan { get; set; }
        public string NguoiXuLy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime? CompleteDate { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public bool IsComplete { get; set; }
        public List<CSExportTicketTransOP_NoContentModel> TransferOPs { get; set; }
        public int SoLanChuyenOP
        {
            get
            {
                return TransferOPs.Count;
            }
        }
        public string TAT
        {
            get
            {
                #region Sau 1/9/20203

                if (CreatedDate < new DateTime(2023 / 09 / 01))
                {
                    var _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_NO_BLVP;
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        if (TransferOPs.Count > 1)
                        {
                            var lastTrans = TransferOPs.OrderByDescending(s => s.TransDate).Select(s => s).FirstOrDefault();
                            if (lastTrans == null) return "Không đạt";
                            if (lastTrans.BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_BLVP;

                            if (lastTrans.Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, lastTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }

                        }
                        else
                        {
                            if (TransferOPs[0].BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_BLVP;
                            if (TransferOPs[0].Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, TransferOPs[0].CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }

                    }

                    if (IsComplete)
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }

                #endregion

                #region Bắt đầu 1/9/2023
                else
                {
                    var _TATCounter = TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTy,
                        KenhTiepNhan = KenhTiepNhan,
                        LoaiKhieuNai = LoaiKhieuNai,
                        LoaiSuVu = LoaiSuVu,
                        LoaiYeuCau = LoaiYeuCau,
                        YeuCau = YeuCau
                    }).CS;

                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (firstTrans == null) return "Không đạt";

                        if (firstTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(firstTrans.TransDate, firstTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            var check = TATHelper.GetTATMinute(firstTrans.TransDate, DateTime.Now, _TATCounter);
                            return check ? "" : "Không đạt";
                        }
                    }
                    else if ((IsComplete && CompleteDate.HasValue) || CSPhanHoiKH.HasValue)
                    {

                        var check = TATHelper.GetTATMinute(CreatedDate, CSPhanHoiKH ?? CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }

                #endregion
            }
        }
    }

    public class CSExportListTicketV2Model
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiSuVuStr { get; set; }
        public string KenhTiepNhan { get; set; }
        public string KenhTiepNhanStr { get; set; }
        public string LoaiKhieuNai { get; set; }
        public string LoaiKhieuNaiStr { get; set; }
        public string LoaiYeuCau { get; set; }
        public string LoaiYeuCauStr { get; set; }
        public string YeuCau { get; set; }
        public string YeuCauStr { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public DateTime? ThoiGianTiepNhanEmail { get; set; }
        public DateTime? NextReminderDate { get; set; }
        public string? NextReminderDateStr { get => NextReminderDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public bool Urgent { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public string CongTy { get; set; }
        public string CongTyStr { get; set; }
        public string MoiGioi { get; set; }
        public string SoHopDong { get; set; }
        public string BenMuaBH { get; set; }
        public string SoHoSo { get; set; }
        public string NguoiTiepNhan { get; set; }
        public string NguoiXuLy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime? CSPhanHoiKH { get; set; }
        public DateTime? CompleteDate { get; set; }
        public string? CompleteDateStr { get => CompleteDate.HasValue ? CompleteDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool IsComplete { get; set; }
        public List<CSExportTicketTransOP_NoContentModel> TransferOPs { get; set; }
        public int SoLanChuyenOP { get; set; }
        public string TAT
        {
            get
            {
                #region Sau 1/9/20203

                if (CreatedDate < new DateTime(2023 / 09 / 01))
                {
                    var _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_NO_BLVP;
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        if (TransferOPs.Count > 1)
                        {
                            var lastTrans = TransferOPs.OrderByDescending(s => s.TransDate).Select(s => s).FirstOrDefault();
                            if (lastTrans == null) return "Không đạt";
                            if (lastTrans.BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_BLVP;

                            if (lastTrans.Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, lastTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }

                        }
                        else
                        {
                            if (TransferOPs[0].BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_BLVP;
                            if (TransferOPs[0].Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, TransferOPs[0].CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }

                    }

                    if (IsComplete)
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }

                #endregion

                #region Bắt đầu 1/9/2023
                else
                {
                    var _TATCounter = TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTy,
                        KenhTiepNhan = KenhTiepNhan,
                        LoaiKhieuNai = LoaiKhieuNai,
                        LoaiSuVu = LoaiSuVu,
                        LoaiYeuCau = LoaiYeuCau,
                        YeuCau = YeuCau
                    }).CS;

                    var myStartDate = TATKenhTiepNhanConst.KenhEmails.Contains(KenhTiepNhan) ? (ThoiGianTiepNhanEmail ?? CreatedDate) : CreatedDate;

                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (firstTrans == null) return "Không đạt";

                        if (firstTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            if (firstTrans.CSPhanHoiKH.HasValue || CSPhanHoiKH.HasValue || CompleteDate.HasValue)
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }
                    }
                    else if ((IsComplete && CompleteDate.HasValue) || CSPhanHoiKH.HasValue)
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, CSPhanHoiKH ?? CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }

                #endregion
            }
        }

        public string? LanChuyen1 { get; set; }
        public string? LanChuyen2 { get; set; }
        public string? LanChuyen3 { get; set; }
        public string? LanChuyen4 { get; set; }
        public string? LanChuyen5 { get; set; }
        public string? LanChuyen6 { get; set; }
        public string? LanChuyen7 { get; set; }
        public string? LanChuyen8 { get; set; }
        public string? LanChuyen9 { get; set; }
        public string? LanChuyen10 { get; set; }
        public string? LanChuyen11 { get; set; }
        public string? LanChuyen12 { get; set; }
        public string? LanChuyen13 { get; set; }
        public string? LanChuyen14 { get; set; }
        public string? LanChuyen15 { get; set; }
        public string? LanChuyen16 { get; set; }
        public string? LanChuyen17 { get; set; }
        public string? LanChuyen18 { get; set; }
        public string? LanChuyen19 { get; set; }
        public string? LanChuyen20 { get; set; }
    }
}
