﻿namespace CTS.Model.VOC
{
    public class SendMailTicketModel
    {
        public List<string> To { get; set; }
        public List<string> CC { get; set; }
        public List<string> BCC { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
    }
}
