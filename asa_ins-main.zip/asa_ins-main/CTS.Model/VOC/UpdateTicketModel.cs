﻿using CTS.Common;
using CTS.Model.VOC.OP;
using System.Globalization;

namespace CTS.Model.VOC
{

    public class CSCreateTicketModel
    {
        public Guid Id { get; set; }
        public string? KenhTiepNhan { get; set; }
        public string MaSV { get; set; }
        public string? TTSV_CongTy_MoiGioi { get; set; }
        public string? CustomerPhone { get; set; }
        public string? CustomerName { get; set; }
        public string? DoiTuongGoiDen { get; set; }
        public string? Email { get; set; }
        public string? Hotline { get; set; }
        public Guid? MAIL_INBOXId { get; set; }
        public List<TicketCallDataModel>? CallIds { get; set; }

        public string? TTSV_CongTy { get; set; }
        public string? TTSV_LoaiSV { get; set; }
        public string? TTSV_LoaiYeuCau { get; set; }
        public string? TTSV_YeuCau { get; set; }

        public string? TTHS_NguoiDuocBH { get; set; }
        public bool Urgent { get; set; }
        public bool IsFollow { get; set; }
        public string? TTHS_DBOStr { get; set; }
        public DateTime? TTHS_DBO
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_DBOStr) && DateTime.TryParseExact(TTHS_DBOStr, FormatDate.DateTime_103,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? TTHS_CMND { get; set; }
        public string? TTHS_BenMuaBH { get; set; }
        public string? TTHS_SoHD { get; set; }
        public string? TTHS_SoHS { get; set; }
        public string? ClaimID { get; set; }
        public string? TTHS_LoaiHS { get; set; }
        public string? TTHS_LoaiKL { get; set; }
        public string? TTHS_NgayGioTNEmailStr { get; set; }
        public DateTime? TTHS_NgayGioTNEmail
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_NgayGioTNEmailStr) && DateTime.TryParseExact(TTHS_NgayGioTNEmailStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? NextReminderDateStr { get; set; }
        public DateTime? NextReminderDate
        {
            get
            {
                if (!string.IsNullOrEmpty(NextReminderDateStr) && DateTime.TryParseExact(NextReminderDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? TTHS_HanXuLyStr { get; set; }
        public DateTime? TTHS_HanXuLy
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_HanXuLyStr) && DateTime.TryParseExact(TTHS_HanXuLyStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }

        public string? CTSV_NoiDungSV { get; set; }
        public string? NoiDungSV_AddMore { get; set; }
        public string? XuLyCS_AddMore { get; set; }

        #region 2. QTXL
        public bool? IsCheckCTBH { get; set; }
        public bool? IsCheckCSYT { get; set; }
        public string? QTXL_NoiDungCustomerService { get; set; }
        public string? QTXL_NoiDungDonViTL { get; set; }
        public string? QTXL_NoiDungCTBH { get; set; }
        public string? QTXL_PhuongAnGQ { get; set; }
        public string? QTXL_PhoiHopGQKN { get; set; }
        public string? QTXL_OPPhanHoiPA { get; set; }
        public string? QTXL_ThoiGianPHKHStr { get; set; }
        public DateTime? QTXL_ThoiGianPHKH
        {
            get
            {
                if (!string.IsNullOrEmpty(QTXL_ThoiGianPHKHStr) && DateTime.TryParseExact(QTXL_ThoiGianPHKHStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? QTXL_CSPhanHoiTTKH { get; set; }
        public string? QTXL_ThoiGianCTLStr { get; set; }
        public DateTime? QTXL_ThoiGianCTL
        {
            get
            {
                if (!string.IsNullOrEmpty(QTXL_ThoiGianCTLStr) && DateTime.TryParseExact(QTXL_ThoiGianCTLStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? QTXL_ThoiGianTLPHStr { get; set; }
        public DateTime? QTXL_ThoiGianTLPH
        {
            get
            {
                if (!string.IsNullOrEmpty(QTXL_ThoiGianTLPHStr) && DateTime.TryParseExact(QTXL_ThoiGianTLPHStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? QTXL_NguyenNhanDTKN { get; set; }
        public string? ChiTietNguyenNhanKN { get; set; }

        #endregion

        public string? FromEmail { get; set; }
        public string? Tos { get; set; }
        public string? CCs { get; set; }
        public List<CSCreateTransferOPModel> TransferOPs { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> CS_Attachs { get; set; }
        public string? CallStatus { get; set; }
        public VOCTicketStatus Status { get; set; }
        public Guid? AccountId { get; set; }
        public Guid? CRM_CustomerId { get; set; }
        public bool IsHandler { get; set; }
        public string? HandlerDateStr { get; set; }
        public DateTime? HandlerDate
        {
            get
            {
                if (!string.IsNullOrEmpty(HandlerDateStr) && DateTime.TryParseExact(HandlerDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }

        public string? CSPhanHoiKHStr { get; set; }
        public DateTime? CSPhanHoiKH
        {
            get
            {
                if (!string.IsNullOrEmpty(CSPhanHoiKHStr) && DateTime.TryParseExact(CSPhanHoiKHStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }

        public bool IsComplete { get; set; }
        public string? CompleteDateStr { get; set; }
        public DateTime? CompleteDate
        {
            get
            {
                if (!string.IsNullOrEmpty(CompleteDateStr) && DateTime.TryParseExact(CompleteDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? ZaloId { get; set; }
    }

    public class CSCreateTransferOPModel
    {
        public string Content_AddMore { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public string? NguoiXuLy { get; set; }
    }

    public class UpdateTicketModel
    {
        public Guid Id { get; set; }
        public string? KenhTiepNhan { get; set; }
        public string? MaSV { get; set; }
        public string? CustomerPhone { get; set; }
        public string? CustomerName { get; set; }
        public string? DoiTuongGoiDen { get; set; }
        public string? Email { get; set; }
        public List<TicketCallDataModel>? CallIds { get; set; }

        #region 1. TTSV

        public string? TTSV_CongTy { get; set; }
        public string? TTSV_LoaiSV { get; set; }
        public string? TTSV_LoaiYeuCau { get; set; }
        public string? TTSV_YeuCau { get; set; }

        public string? TTHS_NguoiDuocBH { get; set; }
        public string? TTHS_DBOStr { get; set; }
        public DateTime? TTHS_DBO
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_DBOStr) && DateTime.TryParseExact(TTHS_DBOStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? TTHS_CMND { get; set; }
        public string? TTHS_BenMuaBH { get; set; }
        public string? TTHS_SoHD { get; set; }
        public string? TTHS_SoHS { get; set; }
        public string? TTHS_LoaiHS { get; set; }
        public string? TTHS_LoaiKL { get; set; }
        public string? TTHS_NgayGioTNEmailStr { get; set; }
        public DateTime? TTHS_NgayGioTNEmail
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_NgayGioTNEmailStr) && DateTime.TryParseExact(TTHS_NgayGioTNEmailStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? TTHS_HanXuLyStr { get; set; }
        public DateTime? TTHS_HanXuLy
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_HanXuLyStr) && DateTime.TryParseExact(TTHS_HanXuLyStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }

        public string? CTSV_NoiDungSV { get; set; }
        public string? CTSV_BoPhanTL { get; set; }
        public string? CTSV_DonViTN { get; set; }



        #endregion

        #region 2. QTXL
        public bool? IsCheckCTBH { get; set; }
        public bool? IsCheckCSYT { get; set; }
        public string? QTXL_NoiDungCustomerService { get; set; }
        public string? QTXL_NoiDungDonViTL { get; set; }
        public string? QTXL_NoiDungCTBH { get; set; }
        public string? QTXL_PhuongAnGQ { get; set; }
        public string? QTXL_PhoiHopGQKN { get; set; }
        public string? QTXL_OPPhanHoiPA { get; set; }
        public string? QTXL_ThoiGianPHKHStr { get; set; }
        public DateTime? QTXL_ThoiGianPHKH
        {
            get
            {
                if (!string.IsNullOrEmpty(QTXL_ThoiGianPHKHStr) && DateTime.TryParseExact(QTXL_ThoiGianPHKHStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? QTXL_CSPhanHoiTTKH { get; set; }
        public string? QTXL_ThoiGianCTLStr { get; set; }
        public DateTime? QTXL_ThoiGianCTL
        {
            get
            {
                if (!string.IsNullOrEmpty(QTXL_ThoiGianCTLStr) && DateTime.TryParseExact(QTXL_ThoiGianCTLStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? QTXL_ThoiGianTLPHStr { get; set; }
        public DateTime? QTXL_ThoiGianTLPH
        {
            get
            {
                if (!string.IsNullOrEmpty(QTXL_ThoiGianTLPHStr) && DateTime.TryParseExact(QTXL_ThoiGianTLPHStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? QTXL_NguyenNhanDTKN { get; set; }
        #endregion

        public bool IsTTSV { get; set; }
        public bool IsQTXL { get; set; }

        public string? CallStatus { get; set; }
        public VOCTicketStatus Status { get; set; }
        public Guid? AccountId { get; set; }
        public Guid? CRM_CustomerId { get; set; }
        public bool IsHandler { get; set; }
        public string? HandlerDateStr { get; set; }
        public DateTime? HandlerDate
        {
            get
            {
                if (!string.IsNullOrEmpty(HandlerDateStr) && DateTime.TryParseExact(HandlerDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public bool IsComplete { get; set; }
        public string? CompleteDateStr { get; set; }
        public DateTime? CompleteDate
        {
            get
            {
                if (!string.IsNullOrEmpty(CompleteDateStr) && DateTime.TryParseExact(CompleteDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
    }


    public class ChangeRequestTypeResultModel
    {
        public DateTime Deadline { get; set; }
        public string DeadlineStr { get => Deadline.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public Guid? AccountId { get; set; }
    }

    public class ChangeRequestTypeRequestModel
    {
        public string ReceiveDateStr { get; set; }
        public DateTime? ReceiveDate
        {
            get
            {
                if (!string.IsNullOrEmpty(ReceiveDateStr) && DateTime.TryParseExact(ReceiveDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public Guid VOCRequestTypeId { get; set; }
    }



}
