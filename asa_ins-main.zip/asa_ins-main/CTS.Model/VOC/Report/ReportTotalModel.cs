﻿using CTS.Common;

namespace CTS.Model.VOC.Report
{

    public class ReportTotalModel
    {
        public List<ReportTotalDetailModel> LoaiYeuCau { get; set; }
        public List<ReportTotalDetailModel> KenhTiepNhan { get; set; }
        public List<ReportTotalDetailModel> TinhTrang { get; set; }
        public List<ReportTotalDetailModel> Total { get; set; }
    }

    public class ReportTotalDetailModel
    {
        public ReportTotalDetailModel(string name, int stt)
        {
            this.STT = stt;
            this.Name = name;
        }
        public ReportTotalDetailModel()
        {
        }

        public int STT { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Hoàn thành",
                    _ => "Đóng",
                };
            }
        }
        public string Name { get; set; }
        public int? T1 { get; set; }
        public int? T2 { get; set; }
        public int? T3 { get; set; }
        public int? T4 { get; set; }
        public int? T5 { get; set; }
        public int? T6 { get; set; }
        public int? T7 { get; set; }
        public int? T8 { get; set; }
        public int? T9 { get; set; }
        public int? T10 { get; set; }
        public int? T11 { get; set; }
        public int? T12 { get; set; }
        public string Order_Text
        {
            get
            {
                if (Name == "Khác") return "zzzzzz";
                else return Name;
            }
        }
    }


    public class ReportTotalTemModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string NameStr { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Hoàn thành",
                    _ => "Đóng",
                };
            }
        }
        public int Month { get; set; }
        public int SL { get; set; }
    }



}
