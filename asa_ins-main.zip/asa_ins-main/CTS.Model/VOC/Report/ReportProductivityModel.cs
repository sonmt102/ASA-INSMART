﻿namespace CTS.Model.VOC.Report
{

    public class ReportProductivityModel
    {
        public List<ReportProductivityDetailModel> TiepNhan { get; set; }
        public List<ReportProductivityDetailModel> PhuTrach { get; set; }
    }
    public class ReportProductivityDetailModel
    {
        public int STT { get; set; }
        public Guid? AccountId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public int New { get; set; }
        public int Handler { get; set; }
        public int Complete { get; set; }
    }
}
