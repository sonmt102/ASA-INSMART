﻿using CTS.Common;
using CTS.Common.TAT;
using CTS.Model.VOC.CS;

namespace CTS.Model.VOC.Report
{
    public class ReportTATModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string KenhTiepNhan { get; set; }
        public string KenhTiepNhanStr { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public DateTime? ThoiGianTiepNhanEmail { get; set; }
        public DateTime? NextReminderDate { get; set; }
        public string? NextReminderDateStr { get => NextReminderDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Name { get; set; }
        public string CustomerType { get; set; }
        public string CongTyBH { get; set; }
        public string CongTyBHStr { get; set; }
        public string MoiGioi { get; set; }
        public string LoaiSuVu { get; set; }
        public string LoaiSuVuStr { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public string LoaiKhieuNai { get; set; }
        public string LoaiKhieuNaiStr { get; set; }
        public string LoaiYeuCau { get; set; }
        public string LoaiYeuCauStr { get; set; }
        public string YeuCau { get; set; }
        public string YeuCauStr { get; set; }
        public string SoHopDong { get; set; }
        public string LoaiHoSo { get; set; }
        public string SoHoSo { get; set; }
        public string ClaimId { get; set; }
        public string NDBH { get; set; }
        public string BenMuaBH { get; set; }
        public string NguoiXuLy { get; set; }
        public string TongThoiGianCSPhanHoiKH { get; set; }
        public int SoLanChuyenOP { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime? CSPhanHoiKH { get; set; }
        public DateTime? CompleteDate { get; set; }
        public bool IsComplete { get; set; }
        public List<CSExportTicketTransOP_NoContentModel> TransferOPs { get; set; }
        public string TAT
        {
            get
            {
                #region Sau 1/9/20203

                if (CreatedDate < new DateTime(2023 / 09 / 01))
                {
                    var _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_NO_BLVP;
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        if (TransferOPs.Count > 1)
                        {
                            var lastTrans = TransferOPs.OrderByDescending(s => s.TransDate).Select(s => s).FirstOrDefault();
                            if (lastTrans == null) return "Không đạt";
                            if (lastTrans.BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_BLVP;

                            if (lastTrans.Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, lastTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }
                        else
                        {
                            if (TransferOPs[0].BoPhanThuLy == CategoryConst.VOC_BoPhanThuLy_BLVP) _TATCounter = (int)VOC_TAT_Minute.Customer_TAT_BLVP;
                            if (TransferOPs[0].Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, TransferOPs[0].CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }

                    }

                    if (IsComplete)
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }

                #endregion

                #region Bắt đầu 1/9/2023
                else
                {
                    var _TATCounter = TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = CongTyBH,
                        KenhTiepNhan = KenhTiepNhan,
                        LoaiKhieuNai = LoaiKhieuNai,
                        LoaiSuVu = LoaiSuVu,
                        LoaiYeuCau = LoaiYeuCau,
                        YeuCau = YeuCau
                    }).CS;

                    var myStartDate = TATKenhTiepNhanConst.KenhEmails.Contains(KenhTiepNhan) ? (ThoiGianTiepNhanEmail ?? CreatedDate) : CreatedDate;
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (firstTrans == null) return "Không đạt";

                        if (firstTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            if (firstTrans.CSPhanHoiKH.HasValue || CSPhanHoiKH.HasValue || CompleteDate.HasValue)
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }
                    }
                    else if ((IsComplete && CompleteDate.HasValue) || CSPhanHoiKH.HasValue)
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, CSPhanHoiKH ?? CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }

                #endregion
            }
        }

        public DateTime ThoiGianTiepNhan
        {
            get
            {
                if (CreatedDate < new DateTime(2023 / 09 / 01)) return CreatedDate;
                else return TATKenhTiepNhanConst.KenhEmails.Contains(KenhTiepNhan) ? (ThoiGianTiepNhanEmail ?? CreatedDate) : CreatedDate;
            }
        }
        public string ThoiGianTiepNhanStr { get => ThoiGianTiepNhan.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }

        #region 29/11/2023 trên báo cáo TAT em có lấy đc cho chị 1 cột "Thời gian nhận", 1 cột là "Thời gian phản hồi", 1 cột là tính ra số ngày-giờ phản hồi không?

        /// <summary>
        /// trên báo cáo TAT em có lấy đc cho chị 1 cột "Thời gian nhận", 1 cột là "Thời gian phản hồi", 1 cột là tính ra số ngày-giờ phản hồi không?
        /// </summary>
        public DateTime? CSPhanHoiKH_Counter
        {
            get
            {
                #region Trước 1/9/20203

                if (CreatedDate < new DateTime(2023 / 09 / 01))
                {
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        if (TransferOPs.Count > 1)
                        {
                            var lastTrans = TransferOPs.OrderByDescending(s => s.TransDate).Select(s => s).FirstOrDefault();
                            if (lastTrans == null) return null;

                            if (lastTrans.Status == OPHandler_Status.DaXuLy)
                            {
                                //var check = TATHelper.GetTATMinute(lastTrans.TransDate, lastTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return lastTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now);
                            }
                            else
                            {
                                //var check = TATHelper.GetTATMinute(lastTrans.TransDate, DateTime.Now, _TATCounter);
                                return null;
                            }

                        }
                        else
                        {
                            if (TransferOPs[0].Status == OPHandler_Status.DaXuLy)
                            {
                                return TransferOPs[0].CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now);
                            }
                            else
                            {
                                //var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                                return null;
                            }
                        }

                    }

                    if (IsComplete)
                    {
                        //var check = TATHelper.GetTATMinute(CreatedDate, CompleteDate ?? DateTime.Now, _TATCounter);
                        return CompleteDate ?? DateTime.Now;
                    }
                    else
                    {
                        //var check = TATHelper.GetTATMinute(CreatedDate, DateTime.Now, _TATCounter);
                        return null;
                    }
                }

                #endregion

                #region Bắt đầu 1/9/2023
                else
                {
                    var myStartDate = TATKenhTiepNhanConst.KenhEmails.Contains(KenhTiepNhan) ? (ThoiGianTiepNhanEmail ?? CreatedDate) : CreatedDate;
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (firstTrans == null) return null;

                        if (firstTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            //var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                            return firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now);
                        }
                        else
                        {
                            if (firstTrans.CSPhanHoiKH.HasValue || CSPhanHoiKH.HasValue || CompleteDate.HasValue)
                            {
                                //var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now);
                            }
                            else
                            {
                                //var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now);
                            }
                        }
                    }
                    else if ((IsComplete && CompleteDate.HasValue) || CSPhanHoiKH.HasValue)
                    {
                        //var check = TATHelper.GetTATMinute(myStartDate, CSPhanHoiKH ?? CompleteDate ?? DateTime.Now, _TATCounter);
                        return CSPhanHoiKH ?? CompleteDate ?? DateTime.Now;
                    }
                    else
                    {
                        //var check = TATHelper.GetTATMinute(myStartDate, DateTime.Now, _TATCounter);
                        return null;
                    }
                }

                #endregion
            }
        }
        public string CSPhanHoiKH_CounterStr { get => CSPhanHoiKH_Counter.HasValue ? CSPhanHoiKH_Counter.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public string SoGioPhanHoi
        {
            get
            {
                if (!CSPhanHoiKH_Counter.HasValue) return string.Empty;
                if (CSPhanHoiKH_Counter.Value <= ThoiGianTiepNhan) return "0";

                double minutes = TATHelper.GetTATTotal(ThoiGianTiepNhan, CSPhanHoiKH_Counter.Value);
                return (minutes / (double)60).ToString("0.##");
                //return (CSPhanHoiKH_Counter.Value - CreatedDate).TotalHours.ToString("0.##");
            }
        }

        #endregion




    }
}
