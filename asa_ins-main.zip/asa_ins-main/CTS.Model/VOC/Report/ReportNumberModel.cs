﻿namespace CTS.Model.VOC.Report
{
    public class ReportNumberModel
    {
        public List<ReportNumberDetailModel> TiepNhan { get; set; }
        public List<ReportNumberDetailModel> Total { get; set; }
    }
    public class ReportNumberDetailModel
    {
        public int STT { get; set; }
        public string? RequestType { get; set; }
        public string RequestName { get; set; }
        public int Total { get => New + Handler + Complete; }

        #region + Tình trạng xử lý

        public int New { get; set; }
        public int Handler { get; set; }
        public int Complete { get; set; }

        #endregion

        //#region + Kênh tiếp nhận

        //public int Callbot { get; set; }
        //public int Chatbot { get; set; }
        //public int Phone { get; set; }
        //public int Email { get; set; }
        //public int Zalo { get; set; }
        //public int Jira { get; set; }
        //public int HTTT { get; set; }
        //public int Channel_Khac { get; set; }

        //#endregion

        //#region + Loại yêu cầu
        ///// <summary>
        ///// Hỗ trợ phần mềm bên trong
        ///// </summary>
        //public int HoTroPhanMemBenTrong { get; set; }
        ///// <summary>
        ///// Hỗ trợ pháp lý, quy định
        ///// </summary>
        //public int HoTroPhapLyQuyDinh { get; set; }
        ///// <summary>
        ///// Hỗ trợ huấn luyện, tập huấn
        ///// </summary>
        //public int HoTroTapHuan { get; set; }
        ///// <summary>
        ///// Hỗ trợ phần mềm bên ngoài
        ///// </summary>
        //public int HoTroPhanMemBenNgoai { get; set; }
        ///// <summary>
        ///// Hỗ trợ cấu hình hạ tầng
        ///// </summary>
        //public int HoTroCauHinhHaTang { get; set; }
        ///// <summary>
        ///// Mở khoá thiết bị
        ///// </summary>
        //public int MoKhoaThietBi { get; set; }
        ///// <summary>
        ///// Khác
        ///// </summary>
        //public int Request_Khac { get; set; }

        //#endregion


        public string Order_Text
        {
            get
            {
                if (RequestName == "Khác") return "zzzzzz";
                else return RequestName;
            }
        }
    }
}
