﻿using CTS.Common;
using CTS.Model.General;
using CTS.Model.VOC.OP;

namespace CTS.Model.VOC
{
    public class TicketDetailModel
    {
        public Guid Id { get; set; }
        public string KenhTiepNhan { get; set; }
        public string MaSV { get; set; }
        public string? CustomerPhone { get; set; }
        public string CustomerName { get; set; }
        public string DoiTuongGoiDen { get; set; }
        public string? Email { get; set; }
        public string? Hotline { get; set; }
        public string? TTSV_CongTy { get; set; }
        public string? TTSV_CongTy_MoiGioi { get; set; }
        public string? TTSV_LoaiSV { get; set; }
        public List<SelectModel> SelectLoaiYeuCau { get; set; }
        public string? TTSV_LoaiYeuCau { get; set; }
        public List<SelectModel> SelectYeuCau { get; set; }
        public string? TTSV_YeuCau { get; set; }
        public string? TTHS_NguoiDuocBH { get; set; }
        public DateTime? TTHS_DBO { get; set; }
        public string? TTHS_DBOStr => TTHS_DBO?.ToString(FormatDate.DateTime_103);
        public string? TTHS_CMND { get; set; }
        public string? TTHS_BenMuaBH { get; set; }
        public string? TTHS_SoHD { get; set; }
        public string? TTHS_SoHS { get; set; }
        public string? ClaimID { get; set; }
        public string? TTHS_LoaiHS { get; set; }
        public string? TTHS_LoaiKL { get; set; }
        public bool Urgent { get; set; }
        public bool IsFollow { get; set; }

        public DateTime? TTHS_NgayGioTNEmail { get; set; }
        public string? TTHS_NgayGioTNEmailStr => TTHS_NgayGioTNEmail?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
        public DateTime? NextReminderDate { get; set; }
        public string? NextReminderDateStr => NextReminderDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);

        public string? CTSV_NoiDungSV { get; set; }
        public string? NoiDungSV_AddMore { get; set; }
        public string? XuLyCS_AddMore { get; set; }


        #region 2. QTXL
        public string? QTXL_NoiDungCustomerService { get; set; }
        public string? QTXL_PhoiHopGQKN { get; set; }
        public string? QTXL_NguyenNhanDTKN { get; set; }
        public string? ChiTietNguyenNhanKN { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public string CSPhanHoiKHStr { get => CSPhanHoiKH.HasValue ? CSPhanHoiKH.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }
        #endregion

        public string? ZaloId { get; set; }
        public VOCTicketStatus Status { get; set; }
        public Guid? AccountId { get; set; }
        public Guid? CRM_CustomerId { get; set; }
        public DateTime? CompleteDate { get; set; }
        public string CompleteDateStr { get => CompleteDate.HasValue ? CompleteDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }
        public bool IsComplete { get => CompleteDate.HasValue; }
        public List<TicketCallDataModel>? CallIds { get; set; }
        public List<TicketHistoryPhoneModel> TicketHistories { get; set; }
        public List<TicketDetail_TransferOPModel> TransferOPs { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> CS_Attachs { get; set; }
        public List<TicketDetail_ContentModel> Contents { get; set; }
        public List<TicketDetail_ContentModel> CSHandlerContents { get; set; }
        public List<TicketDetail_TransferOP_ReplyModel> ReplyEmails { get; set; }
        public List<TicketDetailLogModel> Logs { get; set; }
        public bool IsUpdateTicket { get; set; }
        public DateTime CreatedDate { get; set; }
        public TicketCheckHistoryModel HistoryModel { get; set; }
        public bool IsShowSendMailInTicket { get; set; }
    }

    public class TicketDetailLogModel
    {
        public Guid Id { get; set; }
        public string Content { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public int Type { get; set; }
        public string CreatedBy { get; set; }
    }

    public class TicketDetail_TransferOPModel
    {
        public Guid Id { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string NguoiXuLy { get; set; }
        public bool Urgent { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }
        public string? PhuongAnGiaiQuyet { get; set; }
        public string? PhuongAnGiaiQuyetStr { get; set; }
        public string? CSComment { get; set; }
        public bool IsShowSendMailInTicket { get; set; } = false;
        public DateTime? CSPhanHoiKH { get; set; }
        public string? CSPhanHoiKHStr { get => CSPhanHoiKH?.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }

        public OPHandler_Status Status { get; set; }

        public List<TicketDetail_TransferOP_ContentModel> Contents { get; set; }
        public List<TicketDetail_TransferOP_ContentModel> OP_Contents { get; set; }
        public List<TicketDetail_TransferOP_ContentModel> CTBH_Contents { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> OP_Attachs { get; set; }
        public List<TicketDetail_TransferOP_ReplyModel> OP_Replies { get; set; }

    }

    public class TicketDetail_TransferOP_ReplyModel
    {
        public Guid Id { get; set; }
        public TransferOP_ReplyType Type { get; set; }
        public string To { get; set; }
        public string? Cc { get; set; }
        public string? Bcc { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        public bool IsSeen { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
    }

    public class TicketDetail_ContentModel
    {
        public Guid Id { get; set; }
        public Guid VOC_TicketId { get; set; }
        public string Content { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedDateStr { get => CreatedDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CreatedBy { get; set; }
    }

    public class TicketDetail_TransferOP_ContentModel
    {
        public string Content { get; set; }
        public string? Content_AddMore { get; set; }
        public Guid TransferOPId { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
    }

    public class ExportExcelLogModel
    {
        public Guid Id { get; set; }
        public int STT { get; set; }
        public string TypeStr
        {
            get
            {
                return Type switch
                {
                    ExportExcelLogType.VOC_CS_List => "Danh sách ticket",
                    ExportExcelLogType.VOC_CS_Detail => "Danh sách chi tiết ticket",
                    ExportExcelLogType.VOC_CS_TAT => "Danh sách TAT",
                    ExportExcelLogType.VOC_OP_List => "Danh sách chuyển thụ lý",
                    ExportExcelLogType.VOC_OP_Detail => "Danh sách chuyển thụ lý chi tiết",
                    ExportExcelLogType.VOC_OP_TAT => "Danh sách TAT chuyển thụ lý",
                    _ => string.Empty,
                };
            }
        }
        public ExportExcelLogType Type { get; set; }
        public string CreateBy { get; set; }
        public DateTime CreateDate { get; set; }
        public string CreatedDateStr { get => CreateDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string Time { get; set; }
        public string FileName { get; set; }
        public string Status { get; set; }
    }
    public class ListFileOPExportModel
    {
        public Guid Id { get; set; }
        public int STT { get; set; }

        public DateTime CreateDate { get; set; }
        public string CreatedDateStr { get => CreateDate.AddDays(-1).ToString("dd/MM/yyyy"); }
        public string UrlFile { get => CreateDate.AddDays(-1).ToString("yyyyMMdd") + "/" + FileName; }
        public string FileName { get; set; }
        public string TotalData { get; set; }
        public string DeparmentName { get; set; }

    }
}
