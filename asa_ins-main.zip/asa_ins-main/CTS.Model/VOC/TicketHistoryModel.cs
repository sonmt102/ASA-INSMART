﻿using CTS.Common;

namespace CTS.Model.VOC
{
    public class TicketHistoryModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string RequestTypeName { get; set; }
        public string Code { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Hoàn thành",
                    _ => "Đóng",
                };
            }
        }
        public string AccountUserName { get; set; }
        public string AccountFullName { get; set; }
        public DateTime ReceiveDate { get; set; }
        public string ReceiveDateStr { get => ReceiveDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string ReceiveBy { get; set; }
        public DateTime Deadline { get; set; }
        public string DeadlineStr { get => Deadline.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public bool IsOutOfDate { get => DateTime.Now >= Deadline; }
    }

    public class GetTicketHistoryModel
    {
        public VOCHistoryType Type { get; set; }
        public string Data { get; set; }
    }
}
