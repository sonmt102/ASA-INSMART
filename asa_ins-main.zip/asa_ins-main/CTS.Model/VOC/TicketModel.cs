using CTS.Common;
using CTS.Common.TAT;
using CTS.Model.General;
using CTS.Model.VOC.OP;

namespace CTS.Model.VOC
{
    public class TicketCheckHistoryModel
    {
        public VOCHistoryType Type { get; set; }
        public string Data { get; set; }
    }
    public class AddTicketTabModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string KenhTiepNhan { get; set; }
        public string MaSV { get; set; }
        public string? CustomerPhone { get; set; }
        public string CustomerName { get; set; }
        public string DoiTuongGoiDen { get; set; }
        public Guid? MAIL_INBOXId { get; set; }
        public string? Email { get; set; }
        public string? TTSV_CongTy { get; set; }
        public string? TTSV_CongTy_MoiGioi { get; set; }
        public string? TTSV_LoaiSV { get; set; }
        public List<SelectModel> SelectLoaiYeuCau { get; set; }
        public string? TTSV_LoaiYeuCau { get; set; }
        public List<SelectModel> SelectYeuCau { get; set; }
        public string? TTSV_YeuCau { get; set; }
        /// <summary>
        ///  Tiếp nhận sự vụ
        /// </summary>
        #region 2. TNSV
        public string? TTHS_NguoiDuocBH { get; set; }
        public DateTime? TTHS_DBO { get; set; }
        public string? TTHS_DBOStr => TTHS_DBO?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
        public string? TTHS_CMND { get; set; }
        public string? TTHS_BenMuaBH { get; set; }
        public string? TTHS_SoHD { get; set; }
        public string? TTHS_SoHS { get; set; }
        public string? ClaimID { get; set; }
        public string? TTHS_LoaiHS { get; set; }
        public string? TTHS_LoaiKL { get; set; }

        public DateTime? TTHS_NgayGioTNEmail { get; set; }
        public string? TTHS_NgayGioTNEmailStr => TTHS_NgayGioTNEmail?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
        public DateTime? NextReminderDate { get; set; }
        public string? NextReminderDateStr => NextReminderDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);

        public DateTime? TTHS_HanXuLy { get; set; }
        public string? TTHS_HanXuLyStr => TTHS_HanXuLy?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);

        public string? CTSV_NoiDungSV { get; set; }
        public string? CTSV_BoPhanTL { get; set; }
        public string? CTSV_DonViTN { get; set; }
        public bool Urgent { get; set; }
        #endregion

        /// <summary>
        /// Quá trình xử lý
        /// </summary>
        #region 2. QTXL
        public int? IsCheckCTBH { get; set; }
        public int? IsCheckCSYT { get; set; }
        public string? QTXL_NoiDungCustomerService { get; set; }
        public string? QTXL_NoiDungDonViTL { get; set; }
        public string? QTXL_NoiDungCTBH { get; set; }
        public string? QTXL_PhuongAnGQ { get; set; }
        public string? QTXL_PhoiHopGQKN { get; set; }
        public string? QTXL_OPPhanHoiPA { get; set; }
        public DateTime? QTXL_ThoiGianPHKH { get; set; }
        public string? QTXL_ThoiGianPHKHStr => QTXL_ThoiGianPHKH?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);

        public string? QTXL_CSPhanHoiTTKH { get; set; }
        public DateTime? QTXL_ThoiGianCTL { get; set; }
        public string? QTXL_ThoiGianCTLStr => QTXL_ThoiGianCTL?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);

        public DateTime? QTXL_ThoiGianTLPH { get; set; }
        public string? QTXL_ThoiGianTLPHStr => QTXL_ThoiGianTLPH?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);

        public string? QTXL_NguyenNhanDTKN { get; set; }
        public string? ChiTietNguyenNhanKN { get; set; }

        #endregion

        public bool IsUpdateTicket { get; set; } = false;
        public string? NoiDungSV_AddMore { get; set; }
        public string? XuLyCS_AddMore { get; set; }
        public string? CallStatus { get; set; }
        public VOCTicketStatus Status { get; set; }
        public Guid? AccountId { get; set; }
        public Guid? CRM_CustomerId { get; set; }
        public bool IsHandler { get; set; }
        public DateTime? HandlerDate { get; set; }
        public string? HandlerDateStr => QTXL_ThoiGianTLPH?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
        public DateTime? CSPhanHoiKH { get; set; }
        public string? CSPhanHoiKHStr => CSPhanHoiKH.HasValue ? CSPhanHoiKH.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty;

        public string? ZaloId { get; set; }

        public bool IsComplete { get; set; }
        public DateTime? CompleteDate { get; set; }
        public string? CompleteDateStr => QTXL_ThoiGianTLPH?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);

        public List<TicketHistoryPhoneModel> TicketHistories { get; set; }
        public List<TicketCallDataModel>? CallIds { get; set; }
        public List<TransferOPModel>? TransferOPs { get; set; }
        public List<TicketOPDetail_TransferOP_AttachModel> CS_Attachs { get; set; }
        public TicketCheckHistoryModel HistoryModel { get; set; }
    }

    public class TransferOPModel
    {
        public Guid Id { get; set; }
        public Guid VOC_TicketId { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public DateTime TransDate { get; set; }
        public string TransDateStr => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
        public List<TransferOPContentModel> Contents { get; set; }
    }

    public class TransferOPContentModel
    {
        public Guid Id { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public string? Content { get; set; }
        public DateTime Date { get; set; }
        public string DateStr => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
    }


    public class EmailTicketModel
    {
        public List<string> To { get; set; }
        public List<string> CC { get; set; }
        public List<string> BCC { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
    }


    public class ListTicketModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string KenhTiepNhan { get; set; }
        public string Hotline { get; set; }
        public string KenhTiepNhanStr { get; set; }
        public string MaSV { get; set; }
        public string? CustomerName { get; set; }
        public string? CustomerPhone { get; set; }
        public string? Email { get; set; }
        public DateTime? ThoiGianTiepNhanEmail { get; set; }
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đóng",
                };
            }
        }
        public DateTime CreateDate { get; set; }
        public string CreateDateStr { get => CreateDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public DateTime? NextReminderDate { get; set; }
        public string? NextReminderDateStr { get => NextReminderDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string CreateBy { get; set; }
        public string? TTSV_CongTy { get; set; }
        public string? TTSV_CongTyStr { get; set; }
        public string? TTSV_LoaiSV { get; set; }
        public string? TTSV_LoaiSVStr { get; set; }
        public string? TTSV_LoaiYeuCau { get; set; }
        public string? TTSV_LoaiYeuCauStr { get; set; }
        public string? TTSV_YeuCau { get; set; }
        public string? TTSV_YeuCauStr { get; set; }
        public string? TTHS_SoHD { get; set; }
        public string? TTHS_SoHS { get; set; }
        public string LoaiKhieuNai { get; set; }
        public bool Urgent { get; set; }
        public bool IsFollow { get; set; }
        public string? NguoiXuLy { get; set; }
        public bool IsComplete { get; set; }
        public DateTime? CompleteDate { get; set; }
        public string? CompleteDateStr => CompleteDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
        public DateTime? CSPhanHoiKH { get; set; }
        public string? ZaloId { get; set; }
        public List<ListTicketOPModel> TransferOPs { get; set; }
        public string TAT
        {
            get
            {
                #region Trước 1/9/2023
                if (CreateDate < new DateTime(2023, 09, 01))
                {
                    var blvp = "VBPTL-07";
                    var _TATCounter = 480;
                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        if (TransferOPs.Count > 1)
                        {
                            var lastTrans = TransferOPs.OrderByDescending(s => s.TransDate).Select(s => s).FirstOrDefault();
                            if (lastTrans == null) return "Không đạt";
                            if (lastTrans.BoPhan == blvp) _TATCounter = 60;

                            if (lastTrans.Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, lastTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(lastTrans.TransDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }

                        }
                        else
                        {
                            if (TransferOPs[0].BoPhan == blvp) _TATCounter = 60;
                            if (TransferOPs[0].Status == OPHandler_Status.DaXuLy)
                            {
                                var check = TATHelper.GetTATMinute(CreateDate, TransferOPs[0].CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(CreateDate, DateTime.Now, _TATCounter);
                                return check ? "" : "Không đạt";
                            }
                        }

                    }

                    if (IsComplete)
                    {
                        var check = TATHelper.GetTATMinute(CreateDate, CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(CreateDate, DateTime.Now, _TATCounter);
                        return check ? "" : "Không đạt";
                    }
                }
                #endregion

                #region Bắt đầu từ 1/9/2023
                else
                {
                    var _TATCounter = TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = TTSV_CongTy,
                        KenhTiepNhan = KenhTiepNhan,
                        LoaiKhieuNai = LoaiKhieuNai,
                        LoaiSuVu = TTSV_LoaiSV,
                        LoaiYeuCau = TTSV_LoaiYeuCau,
                        YeuCau = TTSV_YeuCau
                    }).CS;

                    var myStartDate = TATKenhTiepNhanConst.KenhEmails.Contains(KenhTiepNhan) ? (ThoiGianTiepNhanEmail ?? CreateDate) : CreateDate;

                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (firstTrans == null) return "Không đạt";

                        if (firstTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            if (firstTrans.CSPhanHoiKH.HasValue || CSPhanHoiKH.HasValue || CompleteDate.HasValue)
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? TATHelper.GetInTimeTAT(myStartDate, _TATCounter).ToString("yyyy/MM/dd HH:mm:ss") : "Không đạt";
                            }
                        }
                    }
                    else if ((IsComplete && CompleteDate.HasValue) || CSPhanHoiKH.HasValue)
                    {

                        var check = TATHelper.GetTATMinute(myStartDate, CSPhanHoiKH ?? CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, DateTime.Now, _TATCounter);
                        return check ? TATHelper.GetInTimeTAT(myStartDate, _TATCounter).ToString("yyyy/MM/dd HH:mm:ss") : "Không đạt";
                    }
                }

                #endregion
            }
        }


        public string? InTimeTAT
        {
            get
            {
                var _TATCounter = TATHelper.GetTATTimeToCounter(new TATModel
                {
                    CongTy = TTSV_CongTy,
                    KenhTiepNhan = KenhTiepNhan,
                    LoaiKhieuNai = LoaiKhieuNai,
                    LoaiSuVu = TTSV_LoaiSV,
                    LoaiYeuCau = TTSV_LoaiYeuCau,
                    YeuCau = TTSV_YeuCau
                }).CS;


                if (string.IsNullOrEmpty(TAT) && Status != VOCTicketStatus.COMPLETE)
                {
                    var myStartDate = TATKenhTiepNhanConst.KenhEmails.Contains(KenhTiepNhan) ? (ThoiGianTiepNhanEmail ?? CreateDate) : CreateDate;

                    if (TransferOPs != null && TransferOPs.Count > 0)
                    {
                        var firstTrans = TransferOPs.OrderBy(s => s.TransDate).Select(s => s).FirstOrDefault();
                        if (firstTrans == null) return "Không đạt";

                        if (firstTrans.Status == OPHandler_Status.DaXuLy)
                        {
                            var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                            return check ? "Đạt" : "Không đạt";
                        }
                        else
                        {
                            if (firstTrans.CSPhanHoiKH.HasValue || CompleteDate.HasValue)
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? "Đạt" : "Không đạt";
                            }
                            else
                            {
                                var check = TATHelper.GetTATMinute(myStartDate, firstTrans.CSPhanHoiKH ?? (CompleteDate ?? DateTime.Now), _TATCounter);
                                return check ? TATHelper.GetInTimeTAT(myStartDate, _TATCounter).ToString("yyyy/MM/dd HH:mm:ss") : "Không đạt";
                            }
                        }
                    }
                    else if ((IsComplete && CompleteDate.HasValue) || CSPhanHoiKH.HasValue)
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, CSPhanHoiKH ?? CompleteDate ?? DateTime.Now, _TATCounter);
                        return check ? "Đạt" : "Không đạt";
                    }
                    else
                    {
                        var check = TATHelper.GetTATMinute(myStartDate, DateTime.Now, _TATCounter);
                        return check ? TATHelper.GetInTimeTAT(myStartDate, _TATCounter).ToString("yyyy/MM/dd HH:mm:ss") : "Không đạt";
                    }
                }

                return null;
            }
        }

        /// <summary>
        /// 04/10/2023 sau cuộc họp
        /// </summary>
        public bool StatusHanlder
        {
            get => CSPhanHoiKH.HasValue || (TransferOPs != null && TransferOPs.Any(x => x.CSPhanHoiKH.HasValue));
        }
    }

    public class ListTicketOPModel
    {
        public DateTime TransDate { get; set; }
        public string TransDateStr { get => TransDate.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public string BoPhan { get; set; }
        public string BoPhanStr { get; set; }
        public OPHandler_Status Status { get; set; }
        public DateTime? CSPhanHoiKH { get; set; }
        public bool CheckCTBH { get; set; }
        public bool CheckCSYT { get; set; }
        public bool CheckBank { get; set; }
        public bool CheckHDCM { get; set; }

        public string Ticket_CongTy { get; set; }
        public string Ticket_KenhTiepNhan { get; set; }
        public string Ticket_LoaiKhieuNai { get; set; }
        public string Ticket_LoaiSuVu { get; set; }
        public string Ticket_LoaiYeuCau { get; set; }
        public string Ticket_YeuCau { get; set; }

        public bool IsHadUpdate { get; set; }

        public string StatusStr
        {
            get
            {
                switch (Status)
                {
                    case OPHandler_Status.ChuaXuLy:
                        return "Chưa xử lý";
                    case OPHandler_Status.DangXuLy:
                        {
                            var data = new List<string>();
                            if (CheckCTBH) data.Add("Trao đổi CTBH");
                            if (CheckCSYT) data.Add("Chờ xác nhận CSYT");
                            if (CheckBank) data.Add("Chờ xác nhận NH");
                            if (data.Count > 0) return string.Join(", ", data);
                            return "Đang xử lý";
                        }
                    case OPHandler_Status.DaXuLy:
                        return "Đã xử lý";
                    case OPHandler_Status.PhuongAnChuaDayDu:
                        return "PA chưa đầy đủ";
                    case OPHandler_Status.KhongPhanHoi:
                        return "Không phản hồi";
                    default:
                        return "Trạng thái";
                }
            }
        }
        public DateTime? OPHandlerDate { get; set; }
        public string OPHandlerDateStr { get => OPHandlerDate.HasValue ? OPHandlerDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : string.Empty; }
        public bool TAT
        {
            get => TATHelper.GetTATMinute(TransDate,
            Status == OPHandler_Status.DaXuLy ? (OPHandlerDate ?? DateTime.Now) : DateTime.Now, TATCounter);
        }
        public string TATStr
        {
            get
            {
                if (Status == OPHandler_Status.DaXuLy)
                {
                    return TAT ? "Đạt" : "Không đạt";
                }
                return "";
            }
        }
        public int TATCounter
        {
            get
            {
                if (TransDate < new DateTime(2023, 09, 01))
                {
                    if (BoPhan == "VBPTL-07") return 30;
                    else return 240;
                }
                else
                {
                    return TATHelper.GetTATTimeToCounter(new TATModel
                    {
                        CongTy = Ticket_CongTy,
                        KenhTiepNhan = Ticket_KenhTiepNhan,
                        LoaiKhieuNai = Ticket_LoaiKhieuNai,
                        LoaiSuVu = Ticket_LoaiSuVu,
                        LoaiYeuCau = Ticket_LoaiYeuCau,
                        YeuCau = Ticket_YeuCau
                    }).OP;
                }

            }
        }
        public string? InTimeTAT
        {
            get
            {
                if (TAT && Status != OPHandler_Status.DaXuLy)
                    return TATHelper.GetInTimeTAT(TransDate, TATCounter).ToString("yyyy/MM/dd HH:mm:ss");
                return null;
            }
        }
    }

    public class TicketHistoryPhoneModel
    {
        public int STT { get; set; }
        public Guid Id { get; set; }
        public string? MaSV { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerName { get; set; }
        public string? CustomerEmail { get; set; }
        public string? KenhTiepNhan { get; set; }
        public string? LoaiSuVu { get; set; }
        public string? LoaiYeuCau { get; set; }
        public string? YeuCau { get; set; }
        public string? LoaiKhieuNai { get; set; }
        public string? CreateBy { get; set; }
        public DateTime? CreateDate { get; set; }
        public string? CreateDateStr => CreateDate?.ToString(FormatDate.DateTime_ddMMyyyyHHmm);
        public VOCTicketStatus Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    VOCTicketStatus.NEW => "Tiếp nhận mới",
                    VOCTicketStatus.TRANSFER_OP => "Chuyển thụ lý",
                    VOCTicketStatus.COMPLETE => "Sự vụ đã đóng",
                    _ => "Đang xử lý",
                };
            }
        }
        public DateTime? CompleteDate { get; set; }
        public string CompleteDateStr { get => CompleteDate.HasValue ? CompleteDate.Value.ToString(FormatDate.DateTime_ddMMyyyyHHmm) : String.Empty; }
        public bool IsComplete { get => CompleteDate.HasValue; }
        public bool IsTransferOP { get; set; }


    }


}
