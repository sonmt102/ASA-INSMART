﻿using CTS.Common;
using System.Globalization;

namespace CTS.Model.VOC
{
    public class UpdateTicketDetailModel
    {
        public Guid Id { get; set; }
        public string? KenhTiepNhan { get; set; }
        public string? MaSV { get; set; }
        public string? CustomerPhone { get; set; }
        public string? CustomerName { get; set; }
        public string? DoiTuongGoiDen { get; set; }
        public string? Email { get; set; }
        public string? Hotline { get; set; }
        public List<TicketCallDataModel>? CallIds { get; set; }


        public string? TTSV_CongTy { get; set; }
        public string? TTSV_CongTy_MoiGioi { get; set; }
        public string? TTSV_LoaiSV { get; set; }
        public string? TTSV_LoaiYeuCau { get; set; }
        public string? TTSV_YeuCau { get; set; }
        public bool Urgent { get; set; }
        public bool IsFollow { get; set; }

        public string? TTHS_NguoiDuocBH { get; set; }
        public string? TTHS_DBOStr { get; set; }

        public DateTime? TTHS_DBO
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_DBOStr) && DateTime.TryParseExact(TTHS_DBOStr, FormatDate.DateTime_103,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? TTHS_CMND { get; set; }
        public string? TTHS_BenMuaBH { get; set; }
        public string? TTHS_SoHD { get; set; }
        public string? TTHS_SoHS { get; set; }
        public string? ClaimID { get; set; }
        public string? TTHS_LoaiHS { get; set; }
        public string? TTHS_LoaiKL { get; set; }
        public string? TTHS_NgayGioTNEmailStr { get; set; }
        public DateTime? TTHS_NgayGioTNEmail
        {
            get
            {
                if (!string.IsNullOrEmpty(TTHS_NgayGioTNEmailStr) && DateTime.TryParseExact(TTHS_NgayGioTNEmailStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? NextReminderDateStr { get; set; }
        public DateTime? NextReminderDate
        {
            get
            {
                if (!string.IsNullOrEmpty(NextReminderDateStr) && DateTime.TryParseExact(NextReminderDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }

        public string? CTSV_NoiDungSV { get; set; }
        public string? NoiDungSV_AddMore { get; set; }
        public string? XuLyCS_AddMore { get; set; }


        #region 2. QTXL

        public string? QTXL_NoiDungCustomerService { get; set; }
        public string? QTXL_PhoiHopGQKN { get; set; }
        public string? QTXL_NguyenNhanDTKN { get; set; }
        public string? ChiTietNguyenNhanKN { get; set; }

        #endregion
        public string? FromEmail { get; set; }
        public string? Tos { get; set; }
        public string? CCs { get; set; }
        public string? CallStatus { get; set; }
        public VOCTicketStatus Status { get; set; }
        public Guid? AccountId { get; set; }
        public Guid? CRM_CustomerId { get; set; }
        public string? CSPhanHoiKHStr { get; set; }
        public DateTime? CSPhanHoiKH
        {
            get
            {
                if (!string.IsNullOrEmpty(CSPhanHoiKHStr) && DateTime.TryParseExact(CSPhanHoiKHStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public bool IsComplete { get; set; }
        public string? CompleteDateStr { get; set; }
        public DateTime? CompleteDate
        {
            get
            {
                if (!string.IsNullOrEmpty(CompleteDateStr) && DateTime.TryParseExact(CompleteDateStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }

        public List<UpdateTicketDetail_TransferOPModel> TransferOPs { get; set; }
        public string? ZaloId { get; set; }
    }

    public class TicketCallDataModel
    {
        public Guid? CallId { get; set; }
        public bool IsNew { get; set; }
    }



    public class UpdateTicketDetail_TransferOPModel
    {
        public Guid? Id { get; set; }
        public string CTSV_BoPhanTL { get; set; }
        public string? CSComment { get; set; }
        public string? NguoiXuLy { get; set; }
        public OPHandler_Status Status { get; set; }
        public string StatusStr
        {
            get
            {
                return Status switch
                {
                    OPHandler_Status.ChuaXuLy => "Chưa xử lý",
                    OPHandler_Status.DangXuLy => "Đang xử lý",
                    OPHandler_Status.DaXuLy => "Đã xử lý",
                    OPHandler_Status.PhuongAnChuaDayDu => "Phương án chưa đầy đủ",
                    _ => "Trạng thái",
                };
            }
        }
        public string? CSPhanHoiKHStr { get; set; }
        public DateTime? CSPhanHoiKH
        {
            get
            {
                if (!string.IsNullOrEmpty(CSPhanHoiKHStr) && DateTime.TryParseExact(CSPhanHoiKHStr, FormatDate.DateTime_ddMMyyyyHHmm,
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                    return date;
                else return null;
            }
        }
        public string? Content_AddMore { get; set; }
    }
}
