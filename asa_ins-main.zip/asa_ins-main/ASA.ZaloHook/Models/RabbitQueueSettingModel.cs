﻿namespace ASA.ZaloHook.Models
{
    public class RabbitQueueSettingModel
    {
        public string HostName { get; set; }
        public string VirtualHost { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public ushort Port { get; set; }
        public string QueueName_CustomIVR { get; set; }
        public string QueueName_Data { get; set; }
        public string Exchange { get; set; }
        public string RoutingKey_CustomIVR { get; set; }
        public string RoutingKey_Data { get; set; }
        public ClaimSubmission ClaimSubmission { get; set; }
    }

    public class ClaimSubmission
    {
        public int RetryCount { get; set; }
        public int Interval { get; set; }
    }
}
