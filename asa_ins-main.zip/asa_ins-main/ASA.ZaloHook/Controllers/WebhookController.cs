﻿using ASA.ZaloHook.Services;
using CTS.Model.General;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RabbitMQ.Client;

namespace ASA.ZaloHook.Controllers
{
    /// <summary>
    /// Webhook
    /// </summary>
    public class WebhookController : Controller
    {
        private readonly ILogger<WebhookController> _logger;
        private readonly RabbitQueueSettingModel _RabbitSettings;
        private readonly IRabbitServices _RabbitServices;


        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="RabbitServices"></param>
        /// <param name="RabbitQueueSettingModel"></param>
        public WebhookController(ILogger<WebhookController> logger, IRabbitServices RabbitServices,
            IOptions<RabbitQueueSettingModel> RabbitQueueSettingModel)
        {
            _RabbitServices = RabbitServices;
            _RabbitSettings = RabbitQueueSettingModel.Value;
            _logger = logger;
        }

        /// <summary>
        /// Tiếp nhận
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Zalo/Webhook")]
        public IActionResult Webhook([FromBody] JObject model)
        {
            try
            {

                _logger.LogError(JsonConvert.SerializeObject(model));
                //JToken? token = model["event_name"];
                //var t = token != null ? token.ToString() : null;

                _RabbitServices.Publish(model, _RabbitSettings.Exchange, ExchangeType.Topic, _RabbitSettings.RoutingKey_ZaloData);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return StatusCode(500, ex.Message);
            }

        }


        /// <summary>
        /// Tiếp nhận
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Zalo/TestWebhook")]
        public IActionResult TestWebhook([FromBody] JObject model)
        {
            try
            {

                _logger.LogError(JsonConvert.SerializeObject(model));

                //JToken? token = model["event_name"];
                //var t = token != null ? token.ToString() : null;

                //_RabbitServices.Publish(model, _RabbitSettings.Exchange, ExchangeType.Topic, _RabbitSettings.RoutingKey_CustomIVR);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return StatusCode(500, ex.Message);
            }

        }
    }
}
