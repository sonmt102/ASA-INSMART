﻿using CTS.Infra;
using CTS.Service.Dashboard;
using CTS.Service.General;
using CTS.Service.Intergration;
using CTS.Service.KMS;
using CTS.Service.Mail;
using CTS.Service.Manager;
using CTS.Service.VOC;
using CTS.Service.Voice;
using CTS.Service.Zalo;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CTS.Installer
{
    public static class EFInstaller
    {
        public static IServiceCollection AddEFConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            var connectionString = configuration.GetConnectionString("DBConnection");
            services.AddDbContext<CTSContext>(options =>
            {
                options.UseLazyLoadingProxies().UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
            });

            var asteriskConnectionString = configuration.GetConnectionString("AsteriskConnection");
            services.AddDbContext<AsteriskContext>(options =>
            {
                options.UseLazyLoadingProxies().UseMySql(asteriskConnectionString, ServerVersion.AutoDetect(asteriskConnectionString));
            });

            services.AddDbContext<MMContext>(opt =>
            {
                opt.ConfigureWarnings(builder =>
                {
                    builder.Ignore(CoreEventId.PossibleIncorrectRequiredNavigationWithQueryFilterInteractionWarning);
                });
                opt.UseInMemoryDatabase(databaseName: "INSInMemoryDb");
            }, ServiceLifetime.Scoped, ServiceLifetime.Scoped);

            #region MANAGE


            services.AddSingleton<IStaticServices, StaticServices>();
            services.AddTransient<IUserServices, UserServices>();
            services.AddTransient<IDepartmentServices, DepartmentServices>();
            services.AddTransient<IRoleServices, RoleServices>();
            services.AddTransient<ISettingServices, SettingServices>();
            services.AddTransient<ICategoryServices, CategoryServices>();
            services.AddTransient<Service.Manager.StartUpServices, Service.Manager.StartUpServices>();
            services.AddTransient<ISignalServices, SignalServices>();
            services.AddTransient<INotifyServices, NotifyServices>();
            services.AddTransient<ICalendarServices, CalendarServices>();
            services.AddTransient<IUserOnlineServices, UserOnlineServices>();
            services.AddTransient<ILogAccessServices, LogAccessServices>();

            #endregion

            #region VOICE
            services.AddSingleton<ASA.Static.IStaticServices, ASA.Static.StaticServices>();
            services.AddSingleton<ICoreServices, CoreServices>();
            services.AddTransient<IMemoryServices, MemoryServices>();
            services.AddTransient<IActiveLogServices, ActiveLogServices>();
            services.AddTransient<IExtensionServices, ExtensionServices>();
            services.AddTransient<ICalendarServices, CalendarServices>();
            services.AddTransient<IInternalNumberServices, InternalNumberServices>();
            services.AddTransient<IVipBlackListServices, VipBlackListServices>();
            services.AddTransient<CTS.Service.Voice.IReportServices, Service.Voice.ReportServices>();
            services.AddTransient<IQueueServices, QueueServices>();
            services.AddTransient<Service.Voice.IVoiceServices, Service.Voice.VoiceServices>();
            services.AddTransient<IAgentServices, AgentServices>();
            services.AddTransient<IAgentNewServices, AgentNewServices>();
            services.AddTransient<Service.Voice.IStartUpServices, Service.Voice.StartUpServices>();
            services.AddTransient<Service.Voice.ISUPServices, Service.Voice.SUPServices>();
            services.AddTransient<ICoreMemoryServices, CoreMemoryServices>();
            services.AddTransient<IAgentNotifyMissCallServices, AgentNotifyMissCallServices>();
            services.AddTransient<IAgentCallCalendarServices, AgentCallCalendarServices>();
            services.AddTransient<IRecordingServices, RecordingServices>();

            services.AddTransient<IAgentActivityLogService, AgentActivityLogService>();

            #endregion

            #region VOC

            services.AddTransient<ITicketServices, TicketServices>();
            services.AddTransient<IOPServices, OPServices>();
            services.AddTransient<ICSServices, CSServices>();
            services.AddTransient<ITicketReportServices, TicketReportServices>();
            services.AddTransient<ITicketNotifyServices, TicketNotifyServices>();


            services.AddTransient<IExportTicketServices, ExportTicketServices>();




            #endregion

            #region CIMS

            services.AddTransient<Service.CIMS.ICustomerServices, Service.CIMS.CustomerServices>();
            #endregion

            #region Intergration

            services.AddTransient<IVOCServices, VOCServices>();
            services.AddTransient<Service.Intergration.ICustomerServices, Service.Intergration.CustomerServices>();

            #endregion

            #region MAIL
            services.AddTransient<ISignMailServices, SignMailServices>();
            services.AddTransient<ISentMailServices, SentMailServices>();

            services.AddTransient<IAgentMailServices, AgentMailServices>();
            services.AddTransient<IMailQueueServices, MailQueueServices>();
            services.AddTransient<Service.Mail.ISUPServices, Service.Mail.SUPServices>();
            services.AddTransient<IAssignServices, AssignServices>();
            services.AddTransient<Service.Mail.IMailConfigServices, Service.Mail.MailConfigServices>();

            #endregion

            #region Dashboard

            services.AddTransient<IDashboardServices, DashboardServices>();

            #endregion

            #region QA

            services.AddTransient<Service.QA.IMarkServices, Service.QA.MarkServices>();
            services.AddTransient<Service.QA.IAssignServices, Service.QA.AssignServices>();
            services.AddTransient<Service.QA.IJobServices, Service.QA.JobServices>();
            services.AddTransient<Service.QA.IFeedbackServices, Service.QA.FeedbackServices>();
            services.AddTransient<Service.QA.IReportServices, Service.QA.ReportServices>();
            services.AddTransient<Service.QA.IConfigServices, Service.QA.ConfigServices>();
            services.AddTransient<Service.QA.IVoiceServices, Service.QA.VoiceServices>();

            #endregion

            #region KMS
            services.AddTransient<IKMSServices, KMSServices>();
            services.AddTransient<IKMSCategoryServices, KMSCategoryServices>();
            services.AddTransient<IKMSPostServices, KMSPostServices>();
            #endregion

            #region ZALO

            services.AddTransient<IConfigServices, ConfigServices>();
            services.AddTransient<IOA_SDKServices, OA_SDKServices>();
            services.AddTransient<Service.Zalo.IVoiceServices, Service.Zalo.VoiceServices>();
            services.AddTransient<IZaloQueueServices, ZaloQueueServices>();
            services.AddTransient<IZaloChatReceiveDataServices, ZaloChatReceiveDataServices>();
            services.AddTransient<IOATagsServices, OATagsServices>();
            services.AddTransient<IChatServices, ChatServices>();
            services.AddTransient<IChatQuestionServices, ChatQuestionServices>();
            services.AddTransient<IZaloReportServices, ZaloReportServices>();
            #endregion

            return services;
        }
    }
}
