﻿using AutoMapper;
using ASA.ZaloData.Domain;
using CTS.Model.Zalo.Webhook;

namespace ASA.ZaloData
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {

            CreateMap<OA_send_consentModel, Domain.ZW_OA_send_consent>()
                .ForMember(
                    dest => dest.Event_name,
                    opt => opt.MapFrom(src => src.Event_name)
                ).ForMember(
                    dest => dest.Expired_time,
                    opt => opt.MapFrom(src => src.Expired_time)
                ).ForMember(
                    dest => dest.OA_id,
                    opt => opt.MapFrom(src => src.OA_id)
                ).ForMember(
                    dest => dest.Create_time,
                    opt => opt.MapFrom(src => src.Create_time)
                ).ForMember(
                    dest => dest.App_id,
                    opt => opt.MapFrom(src => src.App_id)
                ).ForMember(
                    dest => dest.Phone,
                    opt => opt.MapFrom(src => src.Phone)
                ).ForMember(
                    dest => dest.Request_type,
                    opt => opt.MapFrom(src => src.Request_type)
                ).ForMember(
                    dest => dest.Timestamp,
                    opt => opt.MapFrom(src => src.Timestamp)
                );

            CreateMap<User_reply_consentModel, Domain.ZW_User_reply_consent>()
                .ForMember(
                    dest => dest.Event_name,
                    opt => opt.MapFrom(src => src.Event_name)
                ).ForMember(
                    dest => dest.Expired_time,
                    opt => opt.MapFrom(src => src.Expired_time)
                ).ForMember(
                    dest => dest.OA_id,
                    opt => opt.MapFrom(src => src.OA_id)
                ).ForMember(
                    dest => dest.Confirmed_time,
                    opt => opt.MapFrom(src => src.Confirmed_time)
                ).ForMember(
                    dest => dest.App_id,
                    opt => opt.MapFrom(src => src.App_id)
                ).ForMember(
                    dest => dest.Phone,
                    opt => opt.MapFrom(src => src.Phone)
                ).ForMember(
                    dest => dest.Timestamp,
                    opt => opt.MapFrom(src => src.Timestamp)
                ).ForMember(
                    dest => dest.User_consent,
                    opt => opt.MapFrom(src => src.User_consent)
                );


            CreateMap<ZW_User_send_text, ZW_User_send_textModel>()
                 .ForMember(
                     dest => dest.Details,
                     opt => opt.MapFrom(src => src.ZW_User_send_text_details)
                 );
            CreateMap<ZW_User_send_text_detail, ZW_User_send_text_detailModel>();


            CreateMap<ZW_User_send_textModel, ZW_User_send_text>()
                .ForMember(
                    dest => dest.ZW_User_send_text_details,
                    opt => opt.MapFrom(src => src.Details)
                ); ;
            CreateMap<ZW_User_send_text_detailModel, ZW_User_send_text_detail>();

        }
    }
}
