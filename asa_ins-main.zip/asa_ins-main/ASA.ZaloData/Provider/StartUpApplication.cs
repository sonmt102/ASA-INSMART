﻿using ASA.ZaloData.Services;

namespace ASA.ZaloData.Provider
{
    public class StartUpApplication : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpApplication> _logger;
        public StartUpApplication(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpApplication> logger)
        {
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _ZaloConfigServices = scope.ServiceProvider.GetRequiredService<IZaloConfigServices>();
                //Refresh token
                {
                    //_ZaloConfigServices.SetCalendar();
                }

                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

    }
}
