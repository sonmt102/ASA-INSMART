﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using ASA.ZaloData.Infra;
using ASA.ZaloData.Services;

namespace ASA.ZaloData.Installer
{
    public static class ZaloInstaller
    {
        public static IServiceCollection AddEFZaloConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            var mySQLConnectionString = configuration.GetConnectionString("ZaloConnection");
            services.AddDbContext<ZaloContext>(options =>
            {
                options.UseLazyLoadingProxies().UseMySql(mySQLConnectionString, ServerVersion.AutoDetect(mySQLConnectionString));
                options.ConfigureWarnings(builder =>
                {
                    builder.Ignore(CoreEventId.PossibleIncorrectRequiredNavigationWithQueryFilterInteractionWarning);
                });
            });
            services.AddTransient<IWebhookServices, WebhookServices>();
            services.AddTransient<IOAServices, OAServices>();
            services.AddTransient<IZaloConfigServices, ZaloConfigServices>();


            return services;
        }
    }
}
