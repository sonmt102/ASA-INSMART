﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASA.ZaloData.Domain
{
    public class ZW_Follow_Unfollow
    {
        public Guid Id { get; set; }
        public string? OA_id { get; set; }

        public string? App_id { get; set; }

        public string? Event_name { get; set; }

        public string? Timestamp { get; set; }

        public string? User_id_by_app { get; set; }

        public string? Source { get; set; }

        public string? FollowerId { get; set; }
    }
}
