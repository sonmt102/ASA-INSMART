﻿namespace ASA.ZaloData.Domain
{
    public class ZW_OA_send_consent
    {
        public Guid Id { get; set; }
        public string? Event_name { get; set; }
        public string? OA_id { get; set; }
        public string? Phone { get; set; }
        public string? Request_type { get; set; }
        public string? Create_time { get; set; }
        public string? Expired_time { get; set; }
        public string? App_id { get; set; }
        public string? Timestamp { get; set; }
    }
}
