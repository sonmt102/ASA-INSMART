﻿namespace ASA.ZaloData.Domain
{
    public class Z_AccountTakecareLog
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public string ZaloUserId { get; set; }
        public Guid AssignBy { get; set; }
        public DateTime BeginDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}
