﻿using System.Text.Json.Serialization;

namespace ASA.ZaloData.Domain
{
    public class ZW_User_send_text
    {
        public Guid Id { get; set; }
        public string? SenderId { get; set; }
        public string? App_id { get; set; }
        public string? User_id_by_app { get; set; }
        public string? RecipientId { get; set; }
        public string? Event_name { get; set; }
        public string? Timestamp { get; set; }
        public DateTime CreatedDate { get; set; }
        public virtual ICollection<ZW_User_send_text_detail> ZW_User_send_text_details { get; set; }
    }

    public class ZW_User_send_text_detail
    {
        public Guid Id { get; set; }
        public Guid ZW_User_send_textId { get; set; }
        public string? Type { get; set; }
        public virtual ZW_User_send_text ZW_User_send_text { get; set; }

        //tin nhẵn chữ
        public string? Text { get; set; }
        public string? Msg_id { get; set; }

        //ảnh
        public string? Thumbnail { get; set; }
        public string? Url { get; set; }


        public string? Description { get; set; }
        public string? StickerId { get; set; }

        //File
        public string? Size { get; set; }
        public string? Name { get; set; }
        public string? Checksum { get; set; }
        public string? FileExtension { get; set; }

        //Vị trí
        public string? Latitude { get; set; }
        public string? Longitude { get; set; }
    }
}
