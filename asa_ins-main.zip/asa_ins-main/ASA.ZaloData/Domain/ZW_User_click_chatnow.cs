﻿namespace ASA.ZaloData.Domain
{
    public class ZW_User_click_chatnow
    {
        public Guid Id { get; set; }
        public string? App_id { get; set; }
        public string? Event_name { get; set; }
        public string? OA_id { get; set; }
        public string? User_id { get; set; }
        public string? User_id_by_app { get; set; }
        public string? Timestamp { get; set; }
    }
}
