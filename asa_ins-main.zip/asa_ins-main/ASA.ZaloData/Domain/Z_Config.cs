﻿using CTS.Model;

namespace ASA.ZaloData.Domain
{
    public class Z_Config : DefaultEntity
    {
        public Guid Id { get; set; }
        public string App_Id { get; set; }
        public string Secret_Key { get; set; }
        public string Code_Verifier { get; set; }
        public string? Authorization_Code { get; set; }
        public string? Access_Token { get; set; }
        public string? Refresh_Token { get; set; }
        public int? Expires_In { get; set; }
        public DateTime? ExpiredDate { get; set; }

    }
}
