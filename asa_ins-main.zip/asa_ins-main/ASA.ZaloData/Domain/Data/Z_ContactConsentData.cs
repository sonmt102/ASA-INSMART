﻿namespace ASA.ZaloData.Domain.Data
{
    public class Z_ContactConsentData
    {
        public Guid Id { get; set; }
        public string Phonenumber { get; set; }
        public string? Expired_time { get; set; }
        public string? Confirmed_time { get; set; }
        public DateTime? ExpiredDateTime { get; set; }
        public string? Result { get; set; }
        public string? UserId { get; set; }
    }
}
