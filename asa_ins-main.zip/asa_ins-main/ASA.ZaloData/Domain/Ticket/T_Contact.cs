﻿using CTS.Model;

namespace ASA.ZaloData.Domain.Ticket
{
    public class T_Contact : DefaultEntity
    {
        public Guid Id { get; set; }
        public string? FullName { get; set; }
        public string? MobilePhone { get; set; }
        public string? Facebook { get; set; }
        public string? Zalo { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
        public string? Note { get; set; }
        public string? CustomField1 { get; set; }
        public string? CustomField2 { get; set; }
        public string? CustomField3 { get; set; }
        public string? CustomField4 { get; set; }
        public string? CustomField5 { get; set; }
        public string? CustomField6 { get; set; }
        public string? CustomField7 { get; set; }
        public string? CustomField8 { get; set; }
        public string? CustomField9 { get; set; }
        public string? CustomField10 { get; set; }
        public string? CustomField11 { get; set; }
        public string? CustomField12 { get; set; }
        public string? CustomField13 { get; set; }
        public string? CustomField14 { get; set; }
        public string? CustomField15 { get; set; }
        public string? CustomField16 { get; set; }
        public string? CustomField17 { get; set; }
        public string? CustomField18 { get; set; }
        public string? CustomField19 { get; set; }
        public string? CustomField20 { get; set; }
        public string? CustomField21 { get; set; }
        public string? CustomField22 { get; set; }
        public string? CustomField23 { get; set; }
        public string? CustomField24 { get; set; }
        public string? CustomField25 { get; set; }
        public string? CustomField26 { get; set; }
        public string? CustomField27 { get; set; }
        public string? CustomField28 { get; set; }
        public string? CustomField29 { get; set; }
        public string? CustomField30 { get; set; }
        public string? CustomField31 { get; set; }
        public string? CustomField32 { get; set; }
        public string? CustomField33 { get; set; }
        public string? CustomField34 { get; set; }
        public string? CustomField35 { get; set; }
        public string? CustomField36 { get; set; }
        public string? CustomField37 { get; set; }
        public string? CustomField38 { get; set; }
        public string? CustomField39 { get; set; }
        public string? CustomField40 { get; set; }
        public Guid? TrackingId { get; set; }
        public Guid? VIPBlackListId { get; set; }
        public bool? IsVIP { get; set; }
    }
}
