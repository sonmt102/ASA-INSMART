﻿namespace ASA.ZaloData.Domain
{
    public class ZW_Change_oa_daily_quota
    {
        public Guid Id { get; set; }
        public string? OaId { get; set; }

        public string? Event_name { get; set; }

        public string? Timestamp { get; set; }

        public string? Quota { get; set; }
    }
}
