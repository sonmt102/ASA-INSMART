﻿using Hangfire;
using Hangfire.MemoryStorage;
using Serilog;
using CTS.Model.General;
using ASA.ZaloData;
using ASA.ZaloData.Installer;
using ASA.ZaloData.Provider;
using ASA.ZaloData.Services;

IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((ctx, services) =>
    {
        //services.AddEFDataConfiguration(ctx.Configuration);

        #region RabbitMQ

        var data = ctx.Configuration.GetSection("RabbitMQ:QueueSettings");
        services.Configure<RabbitQueueSettingModel>(data);
        services.AddHostedService<ConsumeRabbitMQServices>();
        services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        services.AddEFZaloConfiguration(ctx.Configuration);
        services.AddRabbitConfiguration(ctx.Configuration);
        services.AddHangfire(c => c.UseMemoryStorage());
        services.AddHangfireServer();
        services.AddHostedService<StartUpApplication>();
        #endregion

    }).UseSerilog((ctx, lc) => lc
        .WriteTo.Console(restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Verbose)
        .WriteTo.File("Logs/ASA.ZaloData-.txt", Serilog.Events.LogEventLevel.Error,
         "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} {CorrelationId} {Level:u3}] {Username} {Message:lj}{NewLine}{Exception}",
         encoding: System.Text.Encoding.UTF8, rollingInterval: RollingInterval.Day)
        .ReadFrom.Configuration(ctx.Configuration))
    .Build();

await host.RunAsync();
