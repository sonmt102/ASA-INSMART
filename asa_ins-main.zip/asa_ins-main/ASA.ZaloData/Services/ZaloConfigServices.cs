﻿using ASA.ZaloData.Domain;
using ASA.ZaloData.Infra;
using CTS.Model.Zalo.Config;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RestSharp;


namespace ASA.ZaloData.Services
{
    public interface IZaloConfigServices
    {
        Task UpdateAccessToken();
        void SetCalendar();
    }
    public class ZaloConfigServices : IZaloConfigServices
    {
        private readonly ILogger<ZaloConfigServices> _logger;
        private readonly IBackgroundJobClient _BackgroundJobClient;
        private readonly IRecurringJobManager _RecurringJobManager;
        private readonly ZaloContext _ZaloContext;

        public ZaloConfigServices(ILogger<ZaloConfigServices> logger, IBackgroundJobClient BackgroundJobClient, ZaloContext ZaloContext,
            IRecurringJobManager RecurringJobManager)
        {
            _RecurringJobManager = RecurringJobManager;
            _BackgroundJobClient = BackgroundJobClient;
            _logger = logger;
            _ZaloContext = ZaloContext;
        }

        public void SetCalendar()
        {
            _RecurringJobManager.AddOrUpdate("Lich_Chay_Lay_Lai_AccessToken_Zalo", () => UpdateAccessToken(), "*/15 * * * *");
        }


        public async Task UpdateAccessToken()
        {
            _logger.LogError("Mỗi 15 phút");
            try
            {
                var item = await _ZaloContext.Z_Configs.ToListAsync();
                if (item != null)
                {
                    foreach (var config in item)
                    {
                        var check = await GetAccessToken2AuthCode(config);
                        if (check.Item1)
                        {
                            config.Refresh_Token = check.Item2.Refresh_Token;
                            config.Access_Token = check.Item2.Access_Token;
                            config.Expires_In = check.Item2.Expires_In;
                            config.ExpiredDate = check.Item2.Expires_In.HasValue ? DateTime.Now.AddMilliseconds(check.Item2.Expires_In.Value) : null;
                        }
                    }
                    await _ZaloContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }

        }



        async Task<(bool, TokenResponseModel?)> GetAccessToken2AuthCode(Z_Config config)
        {
            try
            {
                //curl \
                //-X POST \
                //-H 'Content-Type: application/x-www-form-urlencoded' \
                //-H 'secret_key: <your_secret_key>' \
                //--data - urlencode 'code=<your_oauth_code>' \
                //--data - urlencode 'app_id=<your_app_id>' \
                //--data - urlencode 'grant_type=authorization_code' \
                //--data - urlencode 'code_verifier=your_code_verifier' \
                //'https://oauth.zaloapp.com/v4/oa/access_token'

                var client = new RestClient();
                var request = new RestRequest("https://oauth.zaloapp.com/v4/oa/access_token", Method.Post);
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddHeader("secret_key", $"{config.Secret_Key}");
                request.AddParameter("refresh_token", $"{config.Refresh_Token}");
                request.AddParameter("app_id", $"{config.App_Id}");
                request.AddParameter("grant_type", "refresh_token");
                RestResponse response = await client.ExecuteAsync(request);
                TokenResponseModel objContent = JsonConvert.DeserializeObject<TokenResponseModel>(response.Content);
                return (true, objContent);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return (false, null);
            }
        }

    }

}
