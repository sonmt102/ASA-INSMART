﻿using CTS.Model.Zalo.SDK;
using ASA.ZaloData.Infra;
using ZaloDotNetSDK;

namespace ASA.ZaloData.Services
{
    public interface IOAServices
    {
        /// <summary>
        /// Lấy profile của follower theo user id
        /// </summary>
        /// <param name="user_id"></param>
        /// <returns></returns>
        ProfileOfFollowerModel GetProfileOfFollower(string user_id);
    }

    public class OAServices : IOAServices
    {
        private ZaloClient _ZaloClient;
        private readonly ILogger<OAServices> _logger;
        private readonly ZaloContext _ZaloContext;

        public OAServices(ILogger<OAServices> logger, ZaloContext ZaloContext)
        {
            _ZaloContext = ZaloContext;
            _logger = logger;
            if (_ZaloClient == null) ConnectZalo();

        }

        void ConnectZalo()
        {
            var item = _ZaloContext.Z_Configs.FirstOrDefault();
            if (item != null)
            {
                _ZaloClient ??= new ZaloClient(item.Access_Token);
            }
        }

        /// <summary>
        /// Lấy profile của follower theo user id
        /// </summary>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public ProfileOfFollowerModel GetProfileOfFollower(string user_id)
        {
            try
            {
                var result = _ZaloClient.getProfileOfFollower(user_id);
                return result?.ToObject<ProfileOfFollowerModel>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }
    }
}
