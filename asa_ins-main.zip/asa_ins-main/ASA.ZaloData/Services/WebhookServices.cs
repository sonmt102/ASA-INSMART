﻿using ASA.ZaloData.Domain;
using ASA.ZaloData.Domain.Data;
using ASA.ZaloData.Domain.ZNS;
using ASA.ZaloData.Infra;
using AutoMapper;
using CTS.Common;
using CTS.Common.Zalo;
using CTS.Model.General;
using CTS.Model.Zalo.Webhook;
using CTS.Model.Zalo.Webhook.ZNS;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;

namespace ASA.ZaloData.Services
{
    public interface IWebhookServices
    {
        #region - OA
        Task OA_send_consent(OA_send_consentModel model);
        Task User_reply_consent(User_reply_consentModel model);
        Task Change_oa_daily_quota(Change_oa_daily_quotaModel model);
        Task Follow_Unfollow(Follow_UnfollowModel model);
        Task User_send_text(User_send_textModel model);
        Task User_click_chatnow(User_click_chatnowModel model);
        void User_seen_message(User_seen_messageModel model);

        #endregion


        #region - ZNS

        Task ZNS_User_feedback(ZNS_User_feedbackModel model);

        #endregion
    }
    public class WebhookServices : IWebhookServices
    {
        private readonly ILogger<WebhookServices> _logger;
        private readonly ZaloContext _ZaloContext;
        private readonly IMapper _Mapper;
        private readonly IOAServices _OAServices;
        private readonly IRabbitServices _RabbitServices;
        private readonly RabbitQueueSettingModel _QueueSettings;


        public WebhookServices(ILogger<WebhookServices> logger, ZaloContext context, IMapper mapper, IOAServices OAServices,
            IRabbitServices RabbitServices, IOptions<RabbitQueueSettingModel> QueueSettings)
        {
            _QueueSettings = QueueSettings.Value;
            _logger = logger;
            _ZaloContext = context;
            _Mapper = mapper;
            _OAServices = OAServices;
            _RabbitServices = RabbitServices;
        }


        #region - OA

        public async Task OA_send_consent(OA_send_consentModel model)
        {
            try
            {
                var item = _Mapper.Map<ZW_OA_send_consent>(model);
                item.Id = Guid.NewGuid();

                await _ZaloContext.OA_send_consent.AddAsync(item);
                await _ZaloContext.SaveChangesAsync();

                //Lưu vào đối soát
                var ctrl = await _ZaloContext.Ctrl_Consent.Where(x => x.Phonenumber == item.Phone).FirstOrDefaultAsync();
                if (ctrl != null)
                {
                    ctrl.UpdatedDate = DateTime.Now;
                    ctrl.Status = item.Request_type;
                    ctrl.Result = item.Request_type;
                    await _ZaloContext.SaveChangesAsync();
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }

        }

        public async Task User_reply_consent(User_reply_consentModel model)
        {
            try
            {
                var item = _Mapper.Map<ZW_User_reply_consent>(model);
                item.Id = Guid.NewGuid();

                await _ZaloContext.User_reply_consent.AddAsync(item);
                await _ZaloContext.SaveChangesAsync();

                //Lưu vào đối soát
                var ctrl = await _ZaloContext.Ctrl_Consent.Where(x => x.Phonenumber == item.Phone).FirstOrDefaultAsync();
                if (ctrl != null)
                {
                    ctrl.UpdatedDate = DateTime.Now;
                    ctrl.Status = item.User_consent;
                    ctrl.Result = item.User_consent;


                    var data = await _ZaloContext.Z_ContactConsentData.Where(x => x.Phonenumber == item.Phone).FirstOrDefaultAsync();
                    if (data != null)
                    {
                        data.Result = item.User_consent;


                        // Thời gian tối đa mà OA có quyền thực hiện cuộc gọi đến user, tính bằng milisecond. Ví dụ:
                        // 1646923352005(expired_time) – 1646750552005(confirmed_time) = 172800000(48h)
                        // Trường hợp expired_time = 0 thì OA có quyền gọi đến người dùng không giới hạn thời gian
                        data.Confirmed_time = item.Confirmed_time;
                        data.Expired_time = item.Expired_time;

                        if (item.User_consent == "ALLOW")
                        {

                            if (data.Expired_time == "0")
                            {
                                data.ExpiredDateTime = DateTime.MaxValue;
                            }
                            else
                            {
                                var check1 = long.TryParse(data.Expired_time, out long _Expired_time);
                                var check2 = long.TryParse(data.Confirmed_time, out long _Confirmed_time);
                                if (!check1 || !check2)
                                {
                                    data.Result = $"{data.Result} - fail convert datetime";
                                    data.ExpiredDateTime = DateTime.MinValue;
                                }
                                else
                                {
                                    data.ExpiredDateTime = DateTime.Now.AddMilliseconds(_Expired_time - _Confirmed_time);
                                }
                            }

                        }
                        else
                        {
                            data.ExpiredDateTime = DateTime.MinValue;
                        }
                    }
                    else
                    {
                        var ob = new Z_ContactConsentData
                        {
                            Id = Guid.NewGuid(),
                            Confirmed_time = item.Confirmed_time,
                            Expired_time = item.Expired_time,
                            Result = item.User_consent,
                            Phonenumber = item.Phone,
                        };
                        if (item.User_consent == "ALLOW")
                        {

                            if (ob.Expired_time == "0")
                            {
                                ob.ExpiredDateTime = DateTime.MaxValue;
                            }
                            else
                            {
                                var check1 = long.TryParse(ob.Expired_time, out long _Expired_time);
                                var check2 = long.TryParse(ob.Confirmed_time, out long _Confirmed_time);
                                if (!check1 || !check2)
                                {
                                    ob.Result = $"{ob.Result} - fail convert datetime";
                                    ob.ExpiredDateTime = DateTime.MinValue;
                                }
                                else
                                {
                                    ob.ExpiredDateTime = DateTime.Now.AddMilliseconds(_Expired_time - _Confirmed_time);
                                }
                            }

                        }
                        else
                        {
                            ob.ExpiredDateTime = DateTime.MinValue;
                        }
                    }


                    await _ZaloContext.SaveChangesAsync();



                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        public async Task Change_oa_daily_quota(Change_oa_daily_quotaModel model)
        {
            try
            {
                var item = new ZW_Change_oa_daily_quota
                {
                    Id = Guid.NewGuid(),
                    Event_name = model.Event_name,
                    OaId = model.OaId,
                    Quota = $"Prev:{model.Quota.Prev_value}|New:{model.Quota.New_value}",
                    Timestamp = model.Timestamp
                };
                await _ZaloContext.Change_oa_daily_quota.AddAsync(item);
                await _ZaloContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        public async Task Follow_Unfollow(Follow_UnfollowModel model)
        {
            try
            {
                var item = new ZW_Follow_Unfollow
                {
                    Id = Guid.NewGuid(),
                    Event_name = model.Event_name,
                    Timestamp = model.Timestamp,
                    App_id = model.App_id,
                    FollowerId = model.Follower.Id,
                    OA_id = model.OA_id,
                    User_id_by_app = model.User_id_by_app,
                    Source = model.Source
                };
                await _ZaloContext.Follow_Unfollow.AddAsync(item);
                await _ZaloContext.SaveChangesAsync();
                //Nếu follow thì sẽ lấy thông tin cho vào contact
                //if (item.Event_name == "follow")
                //{
                //    var profile = _OAServices.GetProfileOfFollower(item.FollowerId);
                //    if (profile != null)
                //    {
                //        var contact = await _TicketContext.T_Contacts.Where(x => x.Zalo == item.FollowerId).FirstOrDefaultAsync();
                //        if (contact != null)
                //        {
                //            contact.CustomField40 = profile.Data.Avatar;
                //            contact.FullName = profile.Data.Display_name;
                //            await _TicketContext.SaveChangesAsync();
                //        }
                //    }
                //}

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        public async Task User_send_text(User_send_textModel model)
        {
            try
            {
                var item = new ZW_User_send_text
                {
                    Id = Guid.NewGuid(),
                    Event_name = model.Event_name,
                    Timestamp = model.Timestamp,
                    App_id = model.App_id,
                    SenderId = model.Sender.Id,
                    RecipientId = model.Recipient.Id,
                    User_id_by_app = model.User_id_by_app,
                    CreatedDate = DateTime.Now
                };

                switch (model.Event_name)
                {
                    case ZaloWebhookEventConst.user_send_text:
                        item.ZW_User_send_text_details = new List<ZW_User_send_text_detail>()
                        {
                            new ZW_User_send_text_detail
                            {
                                Id =Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                                Type = "text"
                            }
                        };
                        break;
                    case ZaloWebhookEventConst.user_send_image:
                        {
                            item.ZW_User_send_text_details = model.Message.Attachments.Select(s => new ZW_User_send_text_detail
                            {
                                Id = Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Type = s.Type,
                                Thumbnail = s.Payload.Thumbnail,
                                Url = s.Payload.Url,
                                Description = s.Payload.Description,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                            }).ToList();
                        };
                        break;
                    case ZaloWebhookEventConst.user_send_link:
                        {
                            item.ZW_User_send_text_details = model.Message.Attachments.Select(s => new ZW_User_send_text_detail
                            {
                                Id = Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Type = s.Type,
                                Thumbnail = s.Payload.Thumbnail,
                                Url = s.Payload.Url,
                                Description = s.Payload.Description,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                            }).ToList();
                        };
                        break;
                    case ZaloWebhookEventConst.user_send_audio:
                        {
                            item.ZW_User_send_text_details = model.Message.Attachments.Select(s => new ZW_User_send_text_detail
                            {
                                Id = Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Type = s.Type,
                                Url = s.Payload.Url,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                            }).ToList();
                        };
                        break;
                    case ZaloWebhookEventConst.user_send_video:
                        {
                            item.ZW_User_send_text_details = model.Message.Attachments.Select(s => new ZW_User_send_text_detail
                            {
                                Id = Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Type = s.Type,
                                Thumbnail = s.Payload.Thumbnail,
                                Url = s.Payload.Url,
                                Description = s.Payload.Description,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                            }).ToList();
                        };
                        break;
                    case ZaloWebhookEventConst.user_send_sticker:
                        {
                            item.ZW_User_send_text_details = model.Message.Attachments.Select(s => new ZW_User_send_text_detail
                            {
                                Id = Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Type = s.Type,
                                Url = s.Payload.Url,
                                StickerId = s.Payload.Id,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                            }).ToList();
                        };
                        break;
                    case ZaloWebhookEventConst.user_send_location:
                        {
                            item.ZW_User_send_text_details = model.Message.Attachments.Select(s => new ZW_User_send_text_detail
                            {
                                Id = Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Type = s.Type,
                                Latitude = s.Payload.Coordinates.Latitude,
                                Longitude = s.Payload.Coordinates.Longitude,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                            }).ToList();
                        };
                        break;
                    case ZaloWebhookEventConst.user_send_business_card:
                        break;
                    case ZaloWebhookEventConst.user_send_file:
                        {
                            item.ZW_User_send_text_details = model.Message.Attachments.Select(s => new ZW_User_send_text_detail
                            {
                                Id = Guid.NewGuid(),
                                ZW_User_send_textId = item.Id,
                                Type = s.Type,
                                Size = s.Payload.Size,
                                Name = s.Payload.Name,
                                Url = s.Payload.Url,
                                FileExtension = s.Payload.Type,
                                Checksum = s.Payload.Checksum,
                                Text = model.Message.Text,
                                Msg_id = model.Message.Msg_id,
                            }).ToList();
                        };
                        break;
                    default:
                        break;
                }

                await _ZaloContext.User_send_text.AddAsync(item);
                await _ZaloContext.SaveChangesAsync();

                //bắn đi
                try
                {
                    _RabbitServices.Publish(new Rabbit_ZW_SendDataModel
                    {
                        Type = item.Event_name,
                        Data_ZW_User_send_text = _Mapper.Map<ZW_User_send_textModel>(item)
                    }, _QueueSettings.Exchange_Zalo_Chat, ExchangeType.Topic, _QueueSettings.RoutingKey_Zalo_Chat);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        public async Task User_click_chatnow(User_click_chatnowModel model)
        {
            try
            {

                var item = new ZW_User_click_chatnow
                {
                    Id = Guid.NewGuid(),
                    App_id = model.App_id,
                    Event_name = model.Event_name,
                    OA_id = model.OA_id,
                    Timestamp = model.Timestamp,
                    User_id = model.User_id,
                    User_id_by_app = model.User_id_by_app
                };
                await _ZaloContext.User_click_chatnow.AddAsync(item);
                await _ZaloContext.SaveChangesAsync();

                //bắn đi
                try
                {
                    _RabbitServices.Publish(new Rabbit_ZW_SendDataModel
                    {
                        Type = item.Event_name,
                        User_click_chatnowModel = model
                    }, _QueueSettings.Exchange_Zalo_Chat, ExchangeType.Topic, _QueueSettings.RoutingKey_Zalo_Chat);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }


        public void User_seen_message(User_seen_messageModel model)
        {
            //bắn đi
            try
            {
                _RabbitServices.Publish(new Rabbit_ZW_SendDataModel
                {
                    Type = model.Event_name,
                    Data_User_seen_message = model.Message.Msg_ids
                }, _QueueSettings.Exchange_Zalo_Chat, ExchangeType.Topic, _QueueSettings.RoutingKey_Zalo_Chat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        #endregion

        #region ZNS

        public async Task ZNS_User_feedback(ZNS_User_feedbackModel model)
        {
            try
            {
                DateTime? myTime = null;
                var checkTime = double.TryParse(model.Timestamp, out double result);
                if (checkTime) myTime = Helper.UnixTimeStampToDateTime(result);
                var item = new ZNSW_User_feedback
                {
                    Id = Guid.NewGuid(),
                    App_id = model.App_id,
                    Event_name = model.Event_name,
                    Timestamp = model.Timestamp,
                    Message_msg_id = model.Message.Msg_id,
                    Message_Note = model.Message.Note,
                    Message_Rate = model.Message.Rate,
                    Message_submit_time = model.Message.Submit_time,
                    Message_tracking_id = model.Message.Tracking_id,
                    Timestamp_Date = myTime
                };
                var details = model.Message.Feedbacks.Select(s => new ZNSW_User_feedbackDetail
                {
                    Id = Guid.NewGuid(),
                    Data = s,
                    ZNSW_User_feedbackId = item.Id
                }).ToList();

                await _ZaloContext.ZNSW_User_feedbacks.AddAsync(item);
                await _ZaloContext.ZNSW_User_feedbackDetails.AddRangeAsync(details);
                await _ZaloContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        #endregion
    }
}
