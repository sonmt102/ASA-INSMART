﻿using Microsoft.Extensions.ObjectPool;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using CTS.Model.General;
using System.Diagnostics;

namespace ASA.ZaloData.Services
{
    public static class RabbitZaloServices
    {
        public static IServiceCollection AddRabbitConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            var rabbitConfig = configuration.GetSection("RabbitMQ:QueueSettings");
            services.Configure<RabbitQueueSettingModel>(rabbitConfig);

            services.AddSingleton<ObjectPoolProvider, DefaultObjectPoolProvider>();
            services.AddSingleton<IPooledObjectPolicy<IModel>, RabbitModelPooledObjectPolicy>();

            services.AddSingleton<IRabbitServices, RabbitServices>();

            return services;
        }
    }


    public class RabbitModelPooledObjectPolicy : IPooledObjectPolicy<IModel>
    {
        private readonly RabbitQueueSettingModel _QueueSettings;

        private readonly IConnection _connection;

        public RabbitModelPooledObjectPolicy(IOptions<RabbitQueueSettingModel> QueueSettings)
        {
            _QueueSettings = QueueSettings.Value;
            _connection = GetConnection();
        }

        private IConnection GetConnection()
        {
            var factory = new ConnectionFactory()
            {
                ClientProvidedName = Debugger.IsAttached ? "INS-ZaloData-Publish-DEV" : "INS-ZaloData-Publish",
                HostName = _QueueSettings.HostName,
                UserName = _QueueSettings.UserName,
                Password = _QueueSettings.Password,
                Port = _QueueSettings.Port
            };

            return factory.CreateConnection();
        }

        public IModel Create()
        {
            return _connection.CreateModel();
        }

        public bool Return(IModel obj)
        {
            if (obj.IsOpen)
            {
                return true;
            }
            else
            {
                obj?.Dispose();
                return false;
            }
        }
    }
}
