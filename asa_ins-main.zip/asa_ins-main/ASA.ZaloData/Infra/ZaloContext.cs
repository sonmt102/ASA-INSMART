﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASA.ZaloData.Domain;
using ASA.ZaloData.Domain.Ctrl;
using ASA.ZaloData.Domain.Data;
using ASA.ZaloData.Domain.ZNS;

namespace ASA.ZaloData.Infra
{
    public partial class ZaloContext : DbContext
    {
        public ZaloContext(DbContextOptions<ZaloContext> options)
              : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Z_Config>(e =>
            {
                e.ToTable("Z_Config").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });



            modelBuilder.Entity<ZW_OA_send_consent>(e =>
            {
                e.ToTable("ZW_OA_send_consent").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZW_User_reply_consent>(e =>
            {
                e.ToTable("ZW_User_reply_consent").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZW_Change_oa_daily_quota>(e =>
            {
                e.ToTable("ZW_Change_oa_daily_quota").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZW_Follow_Unfollow>(e =>
            {
                e.ToTable("ZW_Follow_Unfollow").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZW_User_send_text>(e =>
            {
                e.ToTable("ZW_User_send_text").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZW_User_send_text_detail>(e =>
            {
                e.ToTable("ZW_User_send_text_detail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZW_User_click_chatnow>(e =>
            {
                e.ToTable("ZW_User_click_chatnow").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });



            modelBuilder.Entity<Z_Chat>(e =>
            {
                e.ToTable("Z_Chat").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_ChatDetail>(e =>
            {
                e.ToTable("Z_ChatDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<Z_Ctrl_Consent>(e =>
            {
                e.ToTable("Z_Ctrl_Consent").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<Z_ContactConsentData>(e =>
            {
                e.ToTable("Z_ContactConsentData").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_AccountClientToken>(e =>
            {
                e.ToTable("Z_AccountClientToken").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_AccountTakecareLog>(e =>
            {
                e.ToTable("Z_AccountTakecareLog").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            #region - ZNS

            modelBuilder.Entity<ZNSW_User_feedback>(e =>
            {
                e.ToTable("ZNSW_User_feedback").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZNSW_User_feedbackDetail>(e =>
            {
                e.ToTable("ZNSW_User_feedbackDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });


            #endregion


            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);



        public virtual DbSet<Z_AccountClientToken> Z_AccountClientTokens { get; set; }
        public virtual DbSet<Z_AccountTakecareLog> Z_AccountTakecareLogs { get; set; }
        public virtual DbSet<Z_Chat> Z_Chats { get; set; }
        public virtual DbSet<Z_ChatDetail> Z_ChatDetails { get; set; }
        public virtual DbSet<Z_Config> Z_Configs { get; set; }
        public virtual DbSet<ZW_OA_send_consent> OA_send_consent { get; set; }
        public virtual DbSet<ZW_User_reply_consent> User_reply_consent { get; set; }
        public virtual DbSet<ZW_Change_oa_daily_quota> Change_oa_daily_quota { get; set; }
        public virtual DbSet<ZW_Follow_Unfollow> Follow_Unfollow { get; set; }
        public virtual DbSet<ZW_User_send_text> User_send_text { get; set; }
        public virtual DbSet<ZW_User_send_text_detail> User_send_text_detail { get; set; }
        public virtual DbSet<ZW_User_click_chatnow> User_click_chatnow { get; set; }
        public virtual DbSet<Z_Ctrl_Consent> Ctrl_Consent { get; set; }
        public virtual DbSet<Z_ContactConsentData> Z_ContactConsentData { get; set; }


        #region - ZNS

        public virtual DbSet<ZNSW_User_feedback> ZNSW_User_feedbacks { get; set; }
        public virtual DbSet<ZNSW_User_feedbackDetail> ZNSW_User_feedbackDetails { get; set; }


        #endregion
    }
}
