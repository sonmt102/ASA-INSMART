﻿using ASA.ZaloData.Services;
using CTS.Common.Zalo;
using CTS.Model.General;
using CTS.Model.Zalo.Webhook;
using CTS.Model.Zalo.Webhook.ZNS;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Diagnostics;
using System.Text;

namespace ASA.ZaloData
{
    public class ConsumeRabbitMQServices : BackgroundService
    {
        #region PROPERTIES

        private readonly ILogger<ConsumeRabbitMQServices> _logger;
        private IConnection _connection;
        private IModel _channel;
        private readonly RabbitQueueSettingModel _RabbitSettings;
        private readonly IServiceProvider _ServiceProvider;


        public ConsumeRabbitMQServices(ILogger<ConsumeRabbitMQServices> logger, IOptions<RabbitQueueSettingModel> RabbitSettings,
            IServiceProvider ServiceProvider)
        {
            _ServiceProvider = ServiceProvider;
            _RabbitSettings = RabbitSettings.Value;
            _logger = logger;

            InitRabbitMQ();
        }

        #endregion

        private void InitRabbitMQ()
        {
            var factory = new ConnectionFactory
            {
                // create connection  
                ClientProvidedName = Debugger.IsAttached ? "INS-ZaloData-Consume-DEV" : "INS-ZaloData-Consume",
                HostName = _RabbitSettings.HostName,
                UserName = _RabbitSettings.UserName,
                Password = _RabbitSettings.Password,
                VirtualHost = "/",
                Port = _RabbitSettings.Port
            };
            _connection = factory.CreateConnection();

            // create channel  
            _channel = _connection.CreateModel();

            _channel.ExchangeDeclare(_RabbitSettings.Exchange, ExchangeType.Topic);
            _channel.QueueDeclare(_RabbitSettings.QueueName_ZaloData, true, false, false, null);
            _channel.QueueBind(_RabbitSettings.QueueName_ZaloData, _RabbitSettings.Exchange, _RabbitSettings.RoutingKey_ZaloData, null);
            _channel.BasicQos(0, 1, false);

            _connection.ConnectionShutdown += RabbitMQ_ConnectionShutdown;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            stoppingToken.ThrowIfCancellationRequested();

            var consumer = new EventingBasicConsumer(_channel);
            consumer.Received += async (ch, ea) =>
            {
                // received message  
                var content = Encoding.UTF8.GetString(ea.Body.ToArray());
                if (string.IsNullOrEmpty(content)) return;

                _logger.LogError(content);

                // handle the received message  
                await HandleMessageAsync(content);
                _channel.BasicAck(ea.DeliveryTag, false);
            };

            consumer.Shutdown += OnConsumerShutdown;
            consumer.Registered += OnConsumerRegistered;
            consumer.Unregistered += OnConsumerUnregistered;
            consumer.ConsumerCancelled += OnConsumerConsumerCancelled;

            _channel.BasicConsume(_RabbitSettings.QueueName_ZaloData, false, consumer);
            return Task.CompletedTask;


        }

        async Task HandleMessageAsync(string content)
        {
            try
            {
                _logger.LogError(content);
                var obj = JObject.Parse(content);
                JToken? token = obj["event_name"];
                if (token != null && !string.IsNullOrEmpty(token.ToString()))
                {


                    using (var scope = _ServiceProvider.CreateScope())
                    {
                        var _WebhookServices = scope.ServiceProvider.GetRequiredService<IWebhookServices>();
                        var _RabbitServices = scope.ServiceProvider.GetRequiredService<IRabbitServices>();
                        switch (token.ToString())
                        {
                            case ZaloWebhookEventConst.remove_tag:
                                {
                                    var data = JsonConvert.DeserializeObject<RemoveTagModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.remove_user_from_tag:
                                {
                                    var data = JsonConvert.DeserializeObject<Remove_user_from_tagModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.add_user_to_tag:
                                {
                                    var data = JsonConvert.DeserializeObject<Add_user_to_tagModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.user_seen_message:
                                {
                                    var data = JsonConvert.DeserializeObject<User_seen_messageModel>(content);
                                    _WebhookServices.User_seen_message(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_received_message:
                                {
                                    var data = JsonConvert.DeserializeObject<User_received_messageModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.user_authentication:
                                {
                                    var data = JsonConvert.DeserializeObject<User_authenticationModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.user_asking_product:
                                {
                                    var data = JsonConvert.DeserializeObject<User_asking_productModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.user_submit_info:
                                {
                                    var data = JsonConvert.DeserializeObject<User_submit_infoModel>(content);

                                }
                                break;
                            #region - Người dùng nhắn tin
                            case ZaloWebhookEventConst.user_send_text:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);

                                }
                                break;
                            case ZaloWebhookEventConst.user_send_image:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_send_link:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_send_audio:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_send_video:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_send_sticker:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_send_location:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_send_business_card:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_send_file:
                                {
                                    var data = JsonConvert.DeserializeObject<User_send_textModel>(content);
                                    await _WebhookServices.User_send_text(data);
                                }
                                break;
                            #endregion

                            case ZaloWebhookEventConst.follow:
                                {
                                    var data = JsonConvert.DeserializeObject<Follow_UnfollowModel>(content);
                                    await _WebhookServices.Follow_Unfollow(data);

                                }
                                break;
                            case ZaloWebhookEventConst.unfollow:
                                {
                                    var data = JsonConvert.DeserializeObject<Follow_UnfollowModel>(content);
                                    await _WebhookServices.Follow_Unfollow(data);

                                }
                                break;
                            case ZaloWebhookEventConst.oa_send_text:
                                {
                                    var data = JsonConvert.DeserializeObject<OA_send_textModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.user_click_chatnow:
                                {
                                    var data = JsonConvert.DeserializeObject<User_click_chatnowModel>(content);
                                    await _WebhookServices.User_click_chatnow(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_reacted_message:
                                {
                                    var data = JsonConvert.DeserializeObject<User_reacted_messageModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.oa_reacted_message:
                                {
                                    var data = JsonConvert.DeserializeObject<OA_reacted_messageModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.change_oa_template_tags:
                                {
                                    var data = JsonConvert.DeserializeObject<Change_oa_template_tagsModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.change_oa_daily_quota:
                                {
                                    var data = JsonConvert.DeserializeObject<Change_oa_daily_quotaModel>(content);
                                    await _WebhookServices.Change_oa_daily_quota(data);

                                }
                                break;
                            case ZaloWebhookEventConst.oa_send_consent:
                                {
                                    var data = JsonConvert.DeserializeObject<OA_send_consentModel>(content);
                                    await _WebhookServices.OA_send_consent(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_reply_consent:
                                {
                                    var data = JsonConvert.DeserializeObject<User_reply_consentModel>(content);
                                    await _WebhookServices.User_reply_consent(data);
                                }
                                break;
                            case ZaloWebhookEventConst.user_call_oa:
                                {
                                    var data = JsonConvert.DeserializeObject<User_call_oaModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.anonymous_send_text:
                                {
                                    var data = JsonConvert.DeserializeObject<Anonymous_send_textModel>(content);

                                }
                                break;
                            case ZaloWebhookEventConst.oa_send_anonymous_text:
                                {
                                    var data = JsonConvert.DeserializeObject<OA_send_anonymous_textModel>(content);

                                }
                                break;
                            #region ZNS
                            case ZaloWebhookEventConst.zns_user_feedback:
                                {
                                    var data = JsonConvert.DeserializeObject<ZNS_User_feedbackModel>(content);
                                    await _WebhookServices.ZNS_User_feedback(data);
                                }
                                break;

                            #endregion


                            default:
                                break;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }

        }


        private void OnConsumerConsumerCancelled(object sender, ConsumerEventArgs e)
        {
        }
        private void OnConsumerUnregistered(object sender, ConsumerEventArgs e)
        {
        }
        private void OnConsumerRegistered(object sender, ConsumerEventArgs e)
        {
        }
        private void OnConsumerShutdown(object sender, ShutdownEventArgs e)
        {
        }
        private void RabbitMQ_ConnectionShutdown(object sender, ShutdownEventArgs e)
        {
        }

        public override void Dispose()
        {
            _channel.Close();
            _connection.Close();
            base.Dispose();
        }
    }
}
