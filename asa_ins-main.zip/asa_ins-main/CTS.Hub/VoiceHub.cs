﻿using ASA.Static;
using CTS.Common;
using CTS.Infra;
using CTS.Model.Manager.Account;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Concurrent;

namespace CTS.Hub
{
    [Authorize]
    public class VoiceHub : Microsoft.AspNetCore.SignalR.Hub
    {
        private static readonly ConcurrentDictionary<string, User> Users = new(StringComparer.InvariantCultureIgnoreCase);

        private readonly MMContext _MContext;
        private readonly ILogger<VoiceHub> _logger;
        private readonly IStaticServices _StaticServices;

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="MMContext"></param>
        /// <param name="logger"></param>
        public VoiceHub(MMContext MMContext, ILogger<VoiceHub> logger, IStaticServices StaticServices)
        {
            _MContext = MMContext;
            _logger = logger;
            _StaticServices = StaticServices;
        }

        #region Methods
        /// <summary>
        /// Provides the handler for SignalR OnConnected event
        /// supports async threading
        /// </summary>
        /// <returns></returns>
        public override Task OnConnectedAsync()
        {
            try
            {
                var claimsIdentity = Context.User.Identity as System.Security.Claims.ClaimsIdentity;
                if (claimsIdentity != null)
                {
                    var itemAccount = claimsIdentity.FindFirst("UserData");
                    if (itemAccount != null)
                    {
                        var currentUser = JsonConvert.DeserializeObject<UserTokenModel>(itemAccount.Value);
                        string connectionId = Context.ConnectionId;
                        var user = Users.GetOrAdd(currentUser.UserName, _ => new User
                        {
                            ProfileId = currentUser.UserName,
                            ConnectionIds = new HashSet<string>(),
                            DateConnect = DateTime.Now,
                            Extension = currentUser.LoginExtension
                        });

                        lock (user.ConnectionIds)
                        {
                            user.ConnectionIds.Add(connectionId);

                            Groups.AddToGroupAsync(connectionId, currentUser.UserName);

                            #region + Gắn group Sup nếu là Supervisor
                            if (CheckingIsSupervisor(currentUser))
                            {
                                Groups.AddToGroupAsync(connectionId, PermissionConst.SUP_ALLOW);
                                _StaticServices.SupervisorLoginTimes += 1;
                            }
                            #endregion

                            #region + Gắn group nếu có đăng nhập extension để nhận thông tin trạng thái của softphone
                            //Do sử dụng event PeerStatus -> không có username trả về
                            if (!string.IsNullOrEmpty(currentUser.LoginExtension))
                                Groups.AddToGroupAsync(connectionId, currentUser.LoginExtension);

                            #endregion

                            UpdateOnlineAccount(currentUser.UserId, true);

                            return base.OnConnectedAsync();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
            return base.OnConnectedAsync();
        }

        /// <summary>
        /// Provides the handler for SignalR OnDisconnected event
        /// supports async threading
        /// </summary>
        /// <returns></returns>
        public override Task OnDisconnectedAsync(Exception exception)
        {
            var claimsIdentity = Context.User.Identity as System.Security.Claims.ClaimsIdentity;
            var myClaims = claimsIdentity.FindFirst("UserData");
            if (myClaims != null)
            {
                var currentUser = JsonConvert.DeserializeObject<UserTokenModel>(myClaims.Value);
                if (currentUser != null)
                {
                    DateTime DateCurrent = DateTime.Now;
                    Users.TryGetValue(currentUser.UserName, out User user);

                    if (user != null)
                    {
                        user.DateConnect = DateCurrent;
                        lock (user.ConnectionIds)
                        {
                            try
                            {
                                user.ConnectionIds.RemoveWhere(cid => cid.Equals(Context.ConnectionId));
                                Groups.RemoveFromGroupAsync(Context.ConnectionId, user.ProfileId);
                                if (CheckingIsSupervisor(currentUser))
                                {
                                    _StaticServices.SupervisorLoginTimes -= 1;
                                }

                                if (!string.IsNullOrEmpty(currentUser.LoginExtension))
                                    Groups.RemoveFromGroupAsync(Context.ConnectionId, currentUser.LoginExtension);
                                if (!user.ConnectionIds.Any())
                                {
                                    Users.TryRemove(currentUser.UserName, out User removedUser);
                                }

                                UpdateOnlineAccount(currentUser.UserId, false);
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex.Message, ex);
                            }
                        }
                    }
                }
            }

            return base.OnDisconnectedAsync(exception);
        }

        /// <summary>
        /// Provides the facility to send individual user notification message
        /// </summary>
        /// <param name="profileId">
        /// Set to the ProfileId of user who will receive the notification
        /// </param>
        /// <param name="message">
        /// set to the notification message
        /// </param>
        public void Send(string profileId, string message)
        {
            Clients.User(profileId).SendAsync("ReceiveMessage", message);
        }

        public int UpdateOnlineAccount(Guid accountId, bool isOnline)
        {
            try
            {
                var item = _MContext.Accounts.Where(x => x.Id == accountId).FirstOrDefault();
                if (item != null)
                {
                    if (isOnline) item.Online += 1;
                    else item.Online -= 1;
                    _MContext.SaveChanges();

                    return item.Online;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
            return 0;
        }

        /// <summary>
        /// Provides the facility to send group notification message
        /// set to the user groupd name who will receive the message
        /// </summary>
        /// <param name="groupName"></param>
        /// <param name="message"></param>
        public void SendUserMessage(String groupName, String message)
        {
            Clients.Group(groupName).SendAsync(message);
        }

        public void RecieveAgentInCall(String groupName, String message)
        {
            Clients.Group(groupName).SendAsync("ReceiveMessage", message);
        }

        /// <summary>
        /// Provides the ability to get User from the dictionary for passed in profileId
        /// </summary>
        /// <param name="profileId">
        /// set to the profileId of user that need to be fetched from the dictionary
        /// </param>
        /// <returns>
        /// return User object if found otherwise returns null
        /// </returns>
        public User GetUser(string profileId)
        {
            Users.TryGetValue(profileId, out User user);
            return user;
        }

        /// <summary>
        /// Provide theability to get currently connected user
        /// </summary>
        /// <returns>
        /// profileId of user based on current connectionId
        /// </returns>
        public IEnumerable<string> GetConnectedUser()
        {
            return Users.Where(x =>
            {
                lock (x.Value.ConnectionIds)
                {
                    return !x.Value.ConnectionIds.Contains(Context.ConnectionId, StringComparer.InvariantCultureIgnoreCase);
                }
            }).Select(x => x.Key);
        }
        public IEnumerable<string> GetAllConnectedUser()
        {
            return Users.Where(u => !string.IsNullOrEmpty(u.Key)).GroupBy(g => g.Key).Select(x => x.Key);
        }

        /// <summary>
        /// Kiểm tra quyền supervisor
        /// </summary>
        /// <returns></returns>
        public bool CheckingIsSupervisor(UserTokenModel user)
        {
            if (user.Permissions != null && user.Permissions.Count > 0 && user.Permissions.Contains(PermissionConst.SUP_ALLOW))
                return true;
            return false;

        }

        #endregion
    }
}
