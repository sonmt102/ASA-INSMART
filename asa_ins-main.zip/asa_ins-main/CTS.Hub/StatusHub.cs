﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Hub
{
    public class StatusHub : Microsoft.AspNetCore.SignalR.Hub
    {
    }
}
