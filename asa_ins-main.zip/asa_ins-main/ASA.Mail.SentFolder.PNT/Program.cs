using ASA.Mail.Models;
using ASA.Mail.SentFolder.PNT.Provider;
using ASA.SMTPAuth2;
using CTS.Model.General;
using Hangfire;
using Hangfire.MemoryStorage;
using HangfireBasicAuthenticationFilter;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

#region Configure Hangfire  
builder.Services.AddHangfire(c => c.UseMemoryStorage());
builder.Services.AddHangfireServer();
#endregion 

builder.Services.Configure<List<EmailConfigModel>>(builder.Configuration.GetSection("EmailConfigs"));
builder.Services.Configure<VoiceConfigModel>(builder.Configuration.GetSection("VoiceConfig"));
builder.Services.AddEFConfiguration(builder.Configuration);

#region Swagger
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Email Contact center",
        Version = "v1",
        Description = "A simple example ASP.NET Core Web API",
        TermsOfService = new Uri("https://example.com/terms"),
        Contact = new OpenApiContact
        {
            Name = "Shayne Boyer",
            Email = string.Empty,
            Url = new Uri("https://twitter.com/spboyer"),
        },
        License = new OpenApiLicense
        {
            Name = "Use under LICX",
            Url = new Uri("https://example.com/license"),
        }
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please insert JWT with Bearer into field",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
             new OpenApiSecurityScheme
             {
                 Reference = new OpenApiReference
                 {
                     Type = ReferenceType.SecurityScheme,
                     Id = "Bearer"
                 }
              },
              Array.Empty<string>()
        }
    });
    // Set the comments path for the Swagger JSON and UI.
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    c.IncludeXmlComments(xmlPath);
});
#endregion

#region Serilog
builder.Host.UseSerilog((ctx, lc) => lc
     .WriteTo.Console(restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Verbose)
     .WriteTo.File("Logs/mail-.txt", Serilog.Events.LogEventLevel.Error,
     "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} {CorrelationId} {Level:u3}] {Username} {Message:lj}{NewLine}{Exception}",
     encoding: System.Text.Encoding.UTF8, rollingInterval: RollingInterval.Day)
     .ReadFrom.Configuration(ctx.Configuration));
#endregion

builder.Services.AddMvc().AddRazorRuntimeCompilation();
builder.Services.AddControllers().AddNewtonsoftJson(options =>
{
    options.SerializerSettings.ContractResolver = new DefaultContractResolver();
    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
});

builder.Services.AddSingleton<CodeFlowHelper>();
builder.Services.AddSingleton(
    sp => new WellKnownConfigurationHandler(sp.GetService<IHttpClientFactory>()!, "default"));
builder.Services.AddHttpClient("default");

builder.Services.AddHostedService<StartUpListen>();


var app = builder.Build();
app.UseHttpsRedirection();
app.UseSwagger();
app.UseSwaggerUI();

#region Configure Hangfire  
//Basic Authentication added to access the Hangfire Dashboard  
app.UseHangfireDashboard("/hf", new DashboardOptions()
{
    AppPath = "/swagger",
    DashboardTitle = "ASA Schedule Interface",
    Authorization = new[]{
                new HangfireCustomBasicAuthenticationFilter{
                    User = builder.Configuration.GetSection("HangfireCredentials:UserName").Value,
                    Pass = builder.Configuration.GetSection("HangfireCredentials:Password").Value
                }
            },
});
#endregion

app.MapControllers();
app.UseStaticFiles();
app.UseRouting();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");
});
app.Run();