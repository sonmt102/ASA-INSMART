﻿using CTS.Model.General;
using Hangfire;
using Microsoft.Extensions.Options;
using Renci.SshNet;

namespace ASA.Mail.SentFolder.PNT.Services
{
    public interface IStartUpServices
    {
        /// <summary>
        /// Lịch chạy khởi động lại hệ thống
        /// </summary>
        void SetupScheduleRestartService();
        void RestartEmailServices();
    }

    public class StartUpServices : IStartUpServices
    {
        private readonly IRecurringJobManager _RecurringJobManager;
        private readonly ILogger<StartUpServices> _logger;
        private readonly VoiceConfigModel _VoiceConfig;

        public StartUpServices(IRecurringJobManager recurringJobManager, ILogger<StartUpServices> logger, IOptions<VoiceConfigModel> VoiceConfig)
        {
            _RecurringJobManager = recurringJobManager;
            _logger = logger;
            _VoiceConfig = VoiceConfig.Value;
        }


        /// <summary>
        /// Lịch chạy khởi động lại hệ thống
        /// </summary>
        public void SetupScheduleRestartService()
        {
            //Lịch restart service mail
            _RecurringJobManager.AddOrUpdate("Restart service mail SentFolder PNT every hour on 10 munites", () => RestartEmailServices(), "10 * * * *", TimeZoneInfo.Local);
        }




        public void RestartEmailServices()
        {
            try
            {
                _logger.LogError("!!!!!!!!!!!!!!!!!!!!Call restart servicessssssssss email");
                var sshclient = new SshClient(_VoiceConfig.SSH_CRM.IP, _VoiceConfig.SSH_CRM.Port, _VoiceConfig.SSH_CRM.UserName, _VoiceConfig.SSH_CRM.Password);
                sshclient.Connect();
                SshCommand sc = sshclient.CreateCommand("systemctl restart mail-sentfolder-pnt");
                sc.Execute();
                string answer = sc.Result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }
    }
}
