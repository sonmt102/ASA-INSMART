﻿using ASA.Mail.SentFolder.PNT.Services;
using ASA.Mail.Services;
using CTS.Infra;
using Microsoft.EntityFrameworkCore;

namespace ASA.Mail.SentFolder.PNT.Provider
{
    /// <summary>
    /// Khởi tạo
    /// </summary>
    public static class InstallerServices
    {
        /// <summary>
        /// Static
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static IServiceCollection AddEFConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("DBConnection");
            services.AddDbContext<CTSContext>(options =>
            {
                options.UseLazyLoadingProxies().UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
            });

            services.AddTransient<IIdleClientPhiNhanTho_SentServices, IdleClientPhiNhanTho_SentServices>();
            services.AddTransient<IInboxServices, InboxServices>();
            services.AddTransient<IStartUpServices, StartUpServices>();

            return services;
        }
    }
}
