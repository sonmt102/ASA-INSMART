﻿using CTS.Model.General;

namespace ASA.Static
{
    public interface IStaticServices
    {
        bool IsZaloSyncContact { get; set; }
        /// <summary>
        /// Id của lần khởi động
        /// Giành cho việc kickout những token cũ ra ngoài
        /// </summary>
        Guid? ServerId { get; set; }
        /// <summary>
        /// Đường dẫn POPUP khi có cuộc gọi trả lời từ ngoài vào
        /// </summary>
        string? POPUPUri { get; set; }
        /// <summary>
        /// Nhóm gọi ra mặc định
        /// </summary>
        Guid? DefaultOBQueue { get; set; }

        /// <summary>
        /// Lưu trữ số lượng SUP login vào hệ thống.
        /// Nếu = 0  thì những signal ko cần bắn đến SUP nữa
        /// </summary>
        int SupervisorLoginTimes { get; set; }

        #region Số lượng box IVR
        /// <summary>
        /// Số lượng Rớt trong hàng đợi
        /// </summary>
        int StopInACD { get; set; }
        /// <summary>
        /// Nhỡ ở Agent
        /// </summary>
        int MissCall { get; set; }

        #endregion


        /// <summary>
        /// Khởi tạo server id
        /// </summary>
        void InitServerId();

        /// <summary>
        /// Lưu trữ Matching Id của tài khoản đăng nhập. Khi đăng nhập sẽ khởi tạo
        /// </summary>
        List<ActiveLogMatchingModel> ActiveLogMatchings { get; set; }
        /// <summary>
        /// Lưu trữ thông tin lần đăng nhập của Agent
        /// </summary>
        Dictionary<string, Guid> AgentLoginSessions { get; set; }

        /// <summary>
        /// Lấy MatchingId
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        Guid? GetMatchingId(Guid accountId);
        /// <summary>
        /// Xóa matchingId
        /// </summary>
        /// <param name="accountId"></param>
        void RemoveMatchingId(Guid accountId);
        /// <summary>
        /// Kiểm tra tồn tại bản ghi pause
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        bool CheckExistPauseRecord(Guid accountId);
        /// <summary>
        /// Kiểm tra tồn tại bản ghi unpause
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        bool CheckExistUnPauseRecord(Guid accountId);
        /// <summary>
        /// Set Pause record
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="pauseRecord"></param>
        void SetPauseRecord(Guid accountId, bool pauseRecord);
        /// <summary>
        /// Set UnPause record
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="unPauseRecord"></param>
        void SetUnPauseRecord(Guid accountId, bool unPauseRecord);
        /// <summary>
        /// Lấy thông tin Matching
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        ActiveLogMatchingModel? GetMatching(Guid accountId);
        /// <summary>
        /// Lấy thời gian login
        /// </summary>
        /// <param name="accountId"></param>
        DateTime GetLoginDate(Guid accountId);
        /// <summary>
        /// Lấy thời gian UnPause trước đó
        /// </summary>
        /// <param name="accountId"></param>
        DateTime GetUnPauseDate(Guid accountId);
    }

    public class StaticServices : IStaticServices
    {
        public StaticServices()
        {
        }

        public bool IsZaloSyncContact { get; set; }

        #region Số lượng box IVR

        /// <summary>
        /// Số lượng Rớt trong hàng đợi
        /// </summary>
        public int StopInACD { get; set; }
        /// <summary>
        /// Nhỡ ở Agent
        /// </summary>
        public int MissCall { get; set; }

        #endregion


        /// <summary>
        /// Id của lần khởi động
        /// Giành cho việc kickout những token cũ ra ngoài
        /// </summary>
        public Guid? ServerId { get; set; }
        /// <summary>
        /// Đường dẫn POPUP khi có cuộc gọi trả lời từ ngoài vào
        /// </summary>
        public string? POPUPUri { get; set; }
        /// <summary>
        /// Nhóm gọi ra mặc định
        /// </summary>
        public Guid? DefaultOBQueue { get; set; }
        public int SupervisorLoginTimes { get; set; }
        /// <summary>
        /// Khởi tạo server id
        /// </summary>
        public void InitServerId()
        {
            ServerId = Guid.NewGuid();
        }

        /// <summary>
        /// Lưu trữ Matching Id của tài khoản đăng nhập
        /// </summary>
        public List<ActiveLogMatchingModel> ActiveLogMatchings { get; set; } = new();
        /// <summary>
        /// Lưu trữ thông tin lần đăng nhập của Agent
        /// </summary>
        public Dictionary<string, Guid> AgentLoginSessions { get; set; } = new Dictionary<string, Guid>();

        /// <summary>
        /// Lấy MatchingId
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public Guid? GetMatchingId(Guid accountId)
        {
            return ActiveLogMatchings.Where(x => x.AccountId == accountId).Select(s => s.MatchingId).FirstOrDefault();
        }

        /// <summary>
        /// Xóa matchingId
        /// </summary>
        /// <param name="accountId"></param>
        public void RemoveMatchingId(Guid accountId)
        {
            var item = ActiveLogMatchings.Where(x => x.AccountId == accountId).FirstOrDefault();
            if (item != null) ActiveLogMatchings.Remove(item);
        }

        /// <summary>
        /// Kiểm tra tồn tại bản ghi pause
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public bool CheckExistPauseRecord(Guid accountId)
        {
            return ActiveLogMatchings.Where(x => x.AccountId == accountId).Select(s => s.HadPauseRecord).FirstOrDefault();
        }

        /// <summary>
        /// Kiểm tra tồn tại bản ghi unpause
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public bool CheckExistUnPauseRecord(Guid accountId)
        {
            return ActiveLogMatchings.Where(x => x.AccountId == accountId).Select(s => s.HadUnPauseRecord).FirstOrDefault();
        }

        /// <summary>
        /// Set Pause record
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="pauseRecord"></param>
        public void SetPauseRecord(Guid accountId, bool pauseRecord)
        {
            var item = ActiveLogMatchings.Where(x => x.AccountId == accountId).FirstOrDefault();
            if (item != null)
            {
                item.HadPauseRecord = pauseRecord;
                if (pauseRecord)
                {
                    item.HadUnPauseRecord = false;
                    item.PauseDate = DateTime.Now;
                }
            }
        }

        /// <summary>
        /// Set UnPause record
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="unPauseRecord"></param>
        public void SetUnPauseRecord(Guid accountId, bool unPauseRecord)
        {
            var item = ActiveLogMatchings.Where(x => x.AccountId == accountId).FirstOrDefault();
            if (item != null)
            {
                item.HadUnPauseRecord = unPauseRecord;
                if (unPauseRecord)
                {
                    item.HadPauseRecord = false;
                    item.UnPauseDate = DateTime.Now;
                }
            }
        }

        /// <summary>
        /// Lấy thông tin Matching
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public ActiveLogMatchingModel? GetMatching(Guid accountId)
        {
            return ActiveLogMatchings.Where(x => x.AccountId == accountId).FirstOrDefault();
        }

        /// <summary>
        /// Lấy thời gian login
        /// </summary>
        /// <param name="accountId"></param>
        public DateTime GetLoginDate(Guid accountId)
        {
            var item = ActiveLogMatchings.Where(x => x.AccountId == accountId).FirstOrDefault();
            if (item != null)
            {
                return item.LoginDate;
            }
            return DateTime.Now;
        }

        /// <summary>
        /// Lấy thời gian UnPause trước đó
        /// </summary>
        /// <param name="accountId"></param>
        public DateTime GetUnPauseDate(Guid accountId)
        {
            var item = ActiveLogMatchings.Where(x => x.AccountId == accountId).FirstOrDefault();
            if (item != null)
            {
                return item.UnPauseDate;
            }
            return DateTime.Now;
        }
    }
}
