﻿using CTS.Domain.Asterisk;
using Microsoft.EntityFrameworkCore;

namespace CTS.Infra
{
    public partial class AsteriskContext : DbContext
    {
        public AsteriskContext(DbContextOptions<AsteriskContext> options)
              : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            #region VOICE

            modelBuilder.Entity<CallDetail>(e =>
            {
                e.ToTable("call_log").HasKey(k => k.CallId);
                e.HasMany(x => x.CallLogDetails).WithOne(x => x.CallDetail).HasForeignKey(x => x.CallId);
                e.Property(p => p.CallId).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<CallLogDetail>(e =>
            {
                e.ToTable("call_log_detail").HasKey(k => k.Id);
                e.HasOne(x => x.CallDetail).WithMany(x => x.CallLogDetails).HasForeignKey(x => x.CallId);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Ps_Aors>(e =>
            {
                e.ToTable("ps_aors").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Ps_Auths>(e =>
            {
                e.ToTable("ps_auths").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Ps_Endpoints>(e =>
            {
                e.ToTable("ps_endpoints").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Queues>(e =>
            {
                e.ToTable("queues").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QueueMembers>(e =>
            {
                e.ToTable("queue_members").HasKey(k => k.Uniqueid);
                e.Property(p => p.Uniqueid).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Supervisor>(e =>
            {
                e.ToTable("supervisor").HasKey(k => new { k.CallId, k.MICLINKEDID, k.MICUNIQUEID, k.Linkedid, k.Uniqueid, k.Channel });
                e.Property(p => p.CallId).ValueGeneratedOnAdd();
            });
            #endregion

            #region QA
            modelBuilder.Entity<QA_Marked>(e =>
            {
                e.ToTable("QA_Marked").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsMarked);
                e.HasOne(x => x.CallDetail).WithOne(x => x.QA_Marked).HasForeignKey<QA_Marked>(x => x.Call_LogId);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            #endregion

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);


        #region VOICE

        public virtual DbSet<CallDetail> CallDetails { get; set; }
        public virtual DbSet<CallLogDetail> CallLogDetails { get; set; }
        public virtual DbSet<Ps_Aors> Aors { get; set; }
        public virtual DbSet<Ps_Auths> Auths { get; set; }
        public virtual DbSet<Ps_Endpoints> Endpoints { get; set; }
        public virtual DbSet<Queues> Queues { get; set; }
        public virtual DbSet<QueueMembers> QueueMembers { get; set; }
        public virtual DbSet<Supervisor> Supervisors { get; set; }
        #endregion

        #region QA

        public virtual DbSet<QA_Marked> QA_Markeds { get; set; }

        #endregion
    }
}
