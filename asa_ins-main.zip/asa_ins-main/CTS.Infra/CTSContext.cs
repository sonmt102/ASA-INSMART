﻿using CTS.Domain.CIMS;
using CTS.Domain.KMS;
using CTS.Domain.Mail;
using CTS.Domain.Manager;
using CTS.Domain.QA;
using CTS.Domain.VOC;
using CTS.Domain.VOC.Export;
using CTS.Domain.Voice;
using CTS.Domain.Zalo;
using CTS.Domain.Zalo.ForControl;
using CTS.Domain.Zalo.Webhook;
using CTS.Domain.Zalo.ZNS;
using Microsoft.EntityFrameworkCore;

namespace CTS.Infra
{
    public partial class CTSContext : DbContext
    {
        public CTSContext(DbContextOptions<CTSContext> options)
              : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region MANAGE

            modelBuilder.Entity<CRM_Role>(e =>
            {
                e.ToTable("CRM_Role").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<CRM_LogAccess>(e =>
            {
                e.ToTable("CRM_LogAccess").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<CRM_Account>(e =>
            {
                e.ToTable("CRM_Account").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<CRM_AccountDepartment>(e =>
            {
                e.ToTable("CRM_AccountDepartment").HasKey(x => new { x.CRM_DepartmentId, x.CRM_AccountId });
            });

            modelBuilder.Entity<CRM_Department>(e =>
            {
                e.ToTable("CRM_Department").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<CRM_Category>(e =>
            {
                e.ToTable("CRM_Category").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<CRM_Permission>(e =>
            {
                e.ToTable("CRM_Permission").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<CRM_RolePermission>(e =>
            {
                e.ToTable("CRM_RolePermission").HasKey(sc => new { sc.CRM_RoleId, sc.CRM_PermissionId });
            });

            modelBuilder.Entity<CRM_GroupPermission>(e =>
            {
                e.ToTable("CRM_GroupPermission").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
            });

            modelBuilder.Entity<CRM_AccountRole>(e =>
            {
                e.ToTable("CRM_AccountRole").HasKey(sc => new { sc.CRM_AccountId, sc.CRM_RoleId });
            });

            modelBuilder.Entity<CRM_RecoverPassword>(e =>
            {
                e.ToTable("CRM_RecoverPassword").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<CRM_EmailConfig>(e =>
            {
                e.ToTable("CRM_EmailConfig").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<CRM_DM_TinhThanhPho>(e =>
            {
                e.ToTable("CRM_DM_TinhThanhPho").HasKey(k => k.MA_TINH);
                e.Property(p => p.MA_TINH).ValueGeneratedOnAdd();
                e.HasMany(x => x.DM_QuanHuyens).WithOne(x => x.DM_TinhThanhPho).HasForeignKey(x => x.MA_TINH);
            });
            modelBuilder.Entity<CRM_DM_QuanHuyen>(e =>
            {
                e.ToTable("CRM_DM_QuanHuyen").HasKey(k => k.MA_HUYEN);
                e.Property(p => p.MA_HUYEN).ValueGeneratedOnAdd();
                e.HasOne(x => x.DM_TinhThanhPho).WithMany(x => x.DM_QuanHuyens).HasForeignKey(x => x.MA_TINH);

                e.HasMany(x => x.DM_XaPhuongs).WithOne(x => x.DM_QuanHuyen).HasForeignKey(x => x.MA_HUYEN);
            });
            modelBuilder.Entity<CRM_DM_XaPhuong>(e =>
            {
                e.ToTable("CRM_DM_XaPhuong").HasKey(k => k.MA_XA);
                e.Property(p => p.MA_XA).ValueGeneratedOnAdd();
                e.HasOne(x => x.DM_QuanHuyen).WithMany(x => x.DM_XaPhuongs).HasForeignKey(x => x.MA_HUYEN);
            });

            #endregion

            #region VOC

            modelBuilder.Entity<VOC_Ticket>(e =>
            {
                e.ToTable("VOC_Ticket").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_Ticket_Reply>(e =>
            {
                e.ToTable("VOC_Ticket_Reply").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_Ticket_Reply_Attach>(e =>
            {
                e.ToTable("VOC_Ticket_Reply_Attach").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TicketContent>(e =>
            {
                e.ToTable("VOC_TicketContent").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_Ticket_CSHandlerContent>(e =>
            {
                e.ToTable("VOC_Ticket_CSHandlerContent").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TransferOP>(e =>
            {
                e.ToTable("VOC_TransferOP").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TransferOP_Reply>(e =>
            {
                e.ToTable("VOC_TransferOP_Reply").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TransferOP_Reply_Attach>(e =>
            {
                e.ToTable("VOC_TransferOP_Reply_Attach").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TransferOP_Content>(e =>
            {
                e.ToTable("VOC_TransferOP_Content").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_OPHandler_CTBHContent>(e =>
            {
                e.ToTable("VOC_OPHandler_CTBHContent").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_OPHandler_OPContent>(e =>
            {
                e.ToTable("VOC_OPHandler_OPContent").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_OPHandler_Attach>(e =>
            {
                e.ToTable("VOC_OPHandler_Attach").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_OPChangeOP>(e =>
            {
                e.ToTable("VOC_OPChangeOP").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_CSAttach>(e =>
            {
                e.ToTable("VOC_CSAttach").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TransferOP_Content>(e =>
            {
                e.ToTable("VOC_TransferOP_Content").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_CallData>(e =>
            {
                e.ToTable("VOC_CallData").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TicketHistory>(e =>
            {
                e.ToTable("VOC_TicketHistory").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TicketLogStatus>(e =>
            {
                e.ToTable("VOC_TicketLogStatus").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_RequestType>(e =>
            {
                e.ToTable("VOC_RequestType").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_Action>(e =>
            {
                e.ToTable("VOC_Action").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_AssignAccount>(e =>
            {
                e.ToTable("VOC_AssignAccount").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_Notify>(e =>
            {
                e.ToTable("VOC_Notify").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_TicketMailConfig>(e =>
            {
                e.ToTable("VOC_TicketMailConfig").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<EXPORT_TicketDetail>(e =>
            {
                e.ToTable("EXPORT_TicketDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<EXPORT_TicketDetail_Transfer>(e =>
            {
                e.ToTable("EXPORT_TicketDetail_Transfer").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_OP_ExportByDay>(e =>
            {
                e.ToTable("VOC_OP_ExportByDay").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_Export_Check>(e =>
            {
                e.ToTable("VOC_Export_Check").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOC_Export_TicketDetail>(e =>
            {
                e.ToTable("VOC_Export_TicketDetail").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
            });
            modelBuilder.Entity<VOC_Export_TicketDetail_Transfer>(e =>
            {
                e.ToTable("VOC_Export_TicketDetail_Transfer").HasKey(k => k.Id);
            });
            modelBuilder.Entity<VOC_Export_TicketDetail_Transfer_Handler>(e =>
            {
                e.ToTable("VOC_Export_TicketDetail_Transfer_Handler").HasKey(k => k.Id);
            });
            #endregion

            #region CIMS
            modelBuilder.Entity<CIMS_Customer>(e =>
            {
                e.ToTable("CIMS_Customer").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<CIMS_DanhMucTinh>(e =>
            {
                e.ToTable("CIMS_DanhMucTinh").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            #endregion

            #region VOICE
            modelBuilder.Entity<VOI_Extension>(e =>
            {
                e.ToTable("VOI_Extension").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_Queue>(e =>
            {
                e.ToTable("VOI_Queue").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_InternalNumber>(e =>
            {
                e.ToTable("VOI_InternalNumber").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_VIPBlackList>(e =>
            {
                e.ToTable("VOI_VIPBlackList").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_ActiveLogDetail>(e =>
            {
                e.ToTable("VOI_ActiveLogDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_ActiveLog>(e =>
            {
                e.ToTable("VOI_ActiveLog").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_AgentStatusCategory>(e =>
            {
                e.ToTable("VOI_AgentStatusCategory").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_AgentNotifyMissCall>(e =>
            {
                e.ToTable("VOI_AgentNotifyMissCall").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_VoiceSetting>(e =>
            {
                e.ToTable("VOI_VoiceSetting").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<AgentCallCalendar>(e =>
            {
                e.ToTable("AgentCallCalendar").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_QueueAccount>(e =>
            {
                e.ToTable("VOI_QueueAccount").HasKey(k => new { k.VOI_QueueId, k.CRM_AccountId });
            });
            modelBuilder.Entity<VOI_QueueExtension>(e =>
            {
                e.ToTable("VOI_QueueExtension").HasKey(x => new { x.VOI_QueueId, x.VOI_ExtensionId });
            });
            modelBuilder.Entity<VOI_Pusher>(e =>
            {
                e.ToTable("VOI_Pusher").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<VOI_Hotline>(e =>
            {
                e.ToTable("VOI_Hotline").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<AgentActivityLog>(e =>
            {
                e.ToTable("VOI_AgentActivityLog").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            #endregion

            #region MAIL
            modelBuilder.Entity<MAIL_INBOX>(e =>
            {
                e.ToTable("MAIL_INBOX").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_INBOX_Attach>(e =>
            {
                e.ToTable("MAIL_INBOX_Attach").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_INBOX_To>(e =>
            {
                e.ToTable("MAIL_INBOX_To").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_INBOX_CC>(e =>
            {
                e.ToTable("MAIL_INBOX_CC").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_INBOX_BCC>(e =>
            {
                e.ToTable("MAIL_INBOX_BCC").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_INBOX_Tag>(e =>
            {
                e.ToTable("MAIL_INBOX_Tag").HasKey(k => new { k.MAIL_INBOXId, k.MAIL_TagListId });
            });
            modelBuilder.Entity<MAIL_Queue>(e =>
            {
                e.ToTable("MAIL_Queue").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_AccountQueue>(e =>
            {
                e.ToTable("MAIL_AccountQueue").HasKey(k => new { k.CRM_AccountId, k.MAIL_QueueId });
            });
            modelBuilder.Entity<MAIL_TagList>(e =>
            {
                e.ToTable("MAIL_TagList").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_Sign>(e =>
            {
                e.ToTable("MAIL_Sign").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_Answer>(e =>
            {
                e.ToTable("MAIL_Answer").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_Answer_Attach>(e =>
            {
                e.ToTable("MAIL_Answer_Attach").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_Group>(e =>
            {
                e.ToTable("MAIL_Group").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_GroupAccount>(e =>
            {
                e.ToTable("MAIL_GroupAccount").HasKey(k => new { k.MAIL_GroupId, k.CRM_AccountId });
            });
            modelBuilder.Entity<MAIL_AssignAccount>(e =>
            {
                e.ToTable("MAIL_AssignAccount").HasKey(k => k.UserName);
            });
            modelBuilder.Entity<MAIL_Group>(e =>
            {
                e.ToTable("MAIL_Group").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<MAIL_AssignLog>(e =>
            {
                e.ToTable("MAIL_AssignLog").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            #endregion

            #region QA
            modelBuilder.Entity<QA_GroupCriteria>(e =>
            {
                e.ToTable("QA_GroupCriteria").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QA_Criterial>(e =>
            {
                e.ToTable("QA_Criterial").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QA_CriterialDetail>(e =>
            {
                e.ToTable("QA_CriterialDetail").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<QA_Mark>(e =>
            {
                e.ToTable("QA_Mark").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QA_MarkDetail>(e =>
            {
                e.ToTable("QA_MarkDetail").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<QA_RankConfig>(e =>
            {
                e.ToTable("QA_RankConfig").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QA_AgentError>(e =>
            {
                e.ToTable("QA_AgentError").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QA_MarkAgentError>(e =>
            {
                e.ToTable("QA_MarkAgentError").HasKey(x => new { x.QA_AgentErrorId, x.QA_MarkId });
            });
            modelBuilder.Entity<QA_Assign>(e =>
            {
                e.ToTable("QA_Assign").HasKey(x => x.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QA_AssignAccount>(e =>
            {
                e.ToTable("QA_AssignAccount").HasKey(x => new { x.CRM_AccountId, x.QA_AssignId });
            });
            modelBuilder.Entity<QA_MarkFeedback>(e =>
            {
                e.ToTable("QA_MarkFeedback").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            #endregion

            #region KMS

            modelBuilder.Entity<KMS_Category>(e =>
            {
                e.ToTable("KMS_Category").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<KMS_Posts>(e =>
            {
                e.ToTable("KMS_Posts").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<KMS_Posts_Comments>(e =>
            {
                e.ToTable("KMS_Posts_Comments").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<KMS_Posts_Modifier>(e =>
            {
                e.ToTable("KMS_Posts_Modifier").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<KMS_Posts_Views>(e =>
            {
                e.ToTable("KMS_Posts_Views").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<KMS_Files_Approved>(e =>
            {
                e.ToTable("KMS_Files_Approved").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<KMS_Posts_Category>(e =>
            {
                e.ToTable("KMS_Posts_Category").HasKey(sc => new { sc.KMS_PostsId, sc.KMS_CategoryId });
            });

            #endregion

            #region Zalo
            modelBuilder.Entity<Z_CustomerTag>(e =>
            {
                e.ToTable("Z_CustomerTag").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_AssignLog>(e =>
            {
                e.ToTable("Z_AssignLog").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Customer>(e =>
            {
                e.ToTable("Z_Customer").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Config>(e =>
            {
                e.ToTable("Z_Config").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_TagUser>(e =>
            {
                e.ToTable("Z_TagUser").HasKey(x => new { x.UserId, x.Tag });
            });
            modelBuilder.Entity<Z_Ctrl_Consent>(e =>
            {
                e.ToTable("Z_Ctrl_Consent").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Follower>(e =>
            {
                e.ToTable("Z_Follower").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_ContactConsentData>(e =>
            {
                e.ToTable("Z_ContactConsentData").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Queue>(e =>
            {
                e.ToTable("Z_Queue").HasKey(k => k.Id);
                e.HasQueryFilter(x => !x.IsDeleted);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_QueueAccount>(e =>
            {
                e.ToTable("Z_QueueAccount").HasKey(x => new { x.Z_QueueId, x.CRM_AccountId });
            });
            modelBuilder.Entity<Z_AccountClientToken>(e =>
            {
                e.ToTable("Z_AccountClientToken").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZW_User_send_text>(e =>
            {
                e.ToTable("ZW_User_send_text").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
                e.Ignore(x => x.DateStr);
            });
            modelBuilder.Entity<ZW_User_send_text_detail>(e =>
            {
                e.ToTable("ZW_User_send_text_detail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Chat>(e =>
            {
                e.ToTable("Z_Chat").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_ChatDetail>(e =>
            {
                e.ToTable("Z_ChatDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_AgentAnswer>(e =>
            {
                e.ToTable("Z_AgentAnswer").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_AgentAnswerDetail>(e =>
            {
                e.ToTable("Z_AgentAnswerDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_ChatSession>(e =>
            {
                e.ToTable("Z_ChatSession").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_ChatSessionDetail>(e =>
            {
                e.ToTable("Z_ChatSessionDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Chat_Question>(e =>
            {
                e.ToTable("Z_Chat_Question").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZNS_Booking_BA_Request>(e =>
            {
                e.ToTable("ZNS_BA_Request").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZNS_Vote_BA_Request>(e =>
            {
                e.ToTable("ZNS_Vote_BA_Request").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Ctrl_ZNS_Booking>(e =>
            {
                e.ToTable("Z_Ctrl_ZNS_Booking").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Ctrl_ZNS_Vote>(e =>
            {
                e.ToTable("Z_Ctrl_ZNS_Vote").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            #region - ZNS

            modelBuilder.Entity<ZNSW_User_feedback>(e =>
            {
                e.ToTable("ZNSW_User_feedback").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<ZNSW_User_feedbackDetail>(e =>
            {
                e.ToTable("ZNSW_User_feedbackDetail").HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });


            #endregion

            #endregion

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

        #region MANAGER

        public virtual DbSet<CRM_LogAccess> LogAccess { get; set; }
        public virtual DbSet<CRM_Account> Accounts { get; set; }
        public virtual DbSet<CRM_AccountDepartment> AccountDepartments { get; set; }
        public virtual DbSet<CRM_Department> Departments { get; set; }
        public virtual DbSet<CRM_Role> Roles { get; set; }
        public virtual DbSet<CRM_Permission> Permissions { get; set; }
        public virtual DbSet<CRM_GroupPermission> GroupPermissions { get; set; }
        public virtual DbSet<CRM_AccountRole> AccountRoles { get; set; }
        public virtual DbSet<CRM_RolePermission> RolePermissions { get; set; }
        public virtual DbSet<CRM_RecoverPassword> RecoverPasswords { get; set; }
        public virtual DbSet<CRM_Category> Categories { get; set; }
        public virtual DbSet<CRM_EmailConfig> EmailConfigs { get; set; }
        public virtual DbSet<CRM_DM_TinhThanhPho> DM_TinhThanhPhos { get; set; }
        public virtual DbSet<CRM_DM_QuanHuyen> DM_QuanHuyens { get; set; }
        public virtual DbSet<CRM_DM_XaPhuong> DM_XaPhuongs { get; set; }

        #endregion

        #region VOC

        public virtual DbSet<VOC_Ticket> VOC_Tickets { get; set; }
        public virtual DbSet<VOC_Ticket_Reply> VOC_Ticket_Replies { get; set; }
        public virtual DbSet<VOC_Ticket_Reply_Attach> VOC_Ticket_Reply_Attachs { get; set; }
        public virtual DbSet<VOC_TicketContent> VOC_TicketContents { get; set; }
        public virtual DbSet<VOC_Ticket_CSHandlerContent> VOC_Ticket_CSHandlerContents { get; set; }
        public virtual DbSet<VOC_TransferOP> VOC_TransferOP { get; set; }
        public virtual DbSet<VOC_TransferOP_Reply> VOC_TransferOP_Replys { get; set; }
        public virtual DbSet<VOC_TransferOP_Reply_Attach> VOC_TransferOP_Reply_Attachs { get; set; }
        public virtual DbSet<VOC_TransferOP_Content> VOC_TransferOP_Contents { get; set; }
        public virtual DbSet<VOC_OPHandler_CTBHContent> VOC_OPHandler_CTBHContents { get; set; }
        public virtual DbSet<VOC_OPHandler_OPContent> VOC_OPHandler_OPContents { get; set; }
        public virtual DbSet<VOC_OPHandler_Attach> VOC_OPHandler_Attachs { get; set; }
        public virtual DbSet<VOC_OPChangeOP> VOC_OPChangeOPs { get; set; }
        public virtual DbSet<VOC_CSAttach> VOC_CSAttachs { get; set; }
        public virtual DbSet<VOC_CallData> VOC_CallDatas { get; set; }
        public virtual DbSet<VOC_TicketHistory> VOC_TicketHistories { get; set; }
        public virtual DbSet<VOC_TicketLogStatus> VOC_TicketLogStatus { get; set; }
        public virtual DbSet<VOC_RequestType> VOC_RequestTypes { get; set; }
        public virtual DbSet<VOC_Action> VOC_Actions { get; set; }
        public virtual DbSet<VOC_AssignAccount> VOC_AssignAccounts { get; set; }
        public virtual DbSet<VOC_Notify> VOC_Notify { get; set; }
        public virtual DbSet<VOC_TicketMailConfig> VOC_TicketMailConfigs { get; set; }
        public virtual DbSet<EXPORT_TicketDetail> EXPORT_TicketDetails { get; set; }
        public virtual DbSet<EXPORT_TicketDetail_Transfer> EXPORT_TicketDetail_Transfers { get; set; }
        public virtual DbSet<VOC_OP_ExportByDay> VOC_OP_ExportByDay { get; set; }
        public virtual DbSet<VOC_Export_Check> VOC_Export_Checks { get; set; }
        public virtual DbSet<VOC_Export_TicketDetail> VOC_Export_TicketDetails { get; set; }
        public virtual DbSet<VOC_Export_TicketDetail_Transfer> VOC_Export_TicketDetail_Transfers { get; set; }
        public virtual DbSet<VOC_Export_TicketDetail_Transfer_Handler> VOC_Export_TicketDetail_Transfer_Handlers { get; set; }


        #endregion

        #region CIMS

        public virtual DbSet<CIMS_Customer> CIMS_Customers { get; set; }

        #endregion

        #region VOICE
        public virtual DbSet<VOI_Extension> VOI_Extensions { get; set; }
        public virtual DbSet<VOI_InternalNumber> VOI_InternalNumbers { get; set; }
        public virtual DbSet<VOI_VIPBlackList> VOI_VIPBlackLists { get; set; }
        public virtual DbSet<VOI_Queue> VOI_Queues { get; set; }
        public virtual DbSet<VOI_QueueAccount> VOI_QueueAccounts { get; set; }
        public virtual DbSet<VOI_QueueExtension> VOI_QueueExtensions { get; set; }
        public virtual DbSet<VOI_ActiveLogDetail> VOI_ActiveLogDetails { get; set; }
        public virtual DbSet<VOI_ActiveLog> VOI_ActiveLogs { get; set; }
        public virtual DbSet<VOI_AgentStatusCategory> VOI_AgentStatusCategories { get; set; }
        public virtual DbSet<VOI_AgentNotifyMissCall> VOI_AgentNotifyMissCalls { get; set; }
        public virtual DbSet<VOI_VoiceSetting> VOI_VoiceSettings { get; set; }
        /// <summary>
        /// Bảng lưu thông tin agent đặt lịch hẹn gọi lại cho cuộc gọi đã kết thúc trên màn hình agent
        /// </summary>
        public virtual DbSet<AgentCallCalendar> AgentCallCalendars { get; set; }
        public virtual DbSet<VOI_Pusher> VOI_Pusher { get; set; }
        public virtual DbSet<VOI_Hotline> VOI_Hotline { get; set; }
        public virtual DbSet<AgentActivityLog> AgentActivityLogs { get; set; }

        #endregion

        #region MAIL
        public virtual DbSet<MAIL_INBOX> MAIL_INBOXs { get; set; }
        public virtual DbSet<MAIL_INBOX_Attach> MAIL_INBOX_Attachs { get; set; }
        public virtual DbSet<MAIL_INBOX_To> MAIL_INBOX_Tos { get; set; }
        public virtual DbSet<MAIL_INBOX_CC> MAIL_INBOX_CCs { get; set; }
        public virtual DbSet<MAIL_INBOX_BCC> MAIL_INBOX_BCCs { get; set; }
        public virtual DbSet<MAIL_INBOX_Tag> MAIL_INBOX_Tags { get; set; }
        public virtual DbSet<MAIL_Queue> MAIL_Queues { get; set; }
        public virtual DbSet<MAIL_AccountQueue> MAIL_AccountQueues { get; set; }
        public virtual DbSet<MAIL_TagList> MAIL_TagLists { get; set; }
        public virtual DbSet<MAIL_Sign> MAIL_Signs { get; set; }
        public virtual DbSet<MAIL_Answer> MAIL_Answers { get; set; }
        public virtual DbSet<MAIL_Answer_Attach> MAIL_Answer_Attachs { get; set; }
        public virtual DbSet<MAIL_Group> MAIL_Groups { get; set; }
        public virtual DbSet<MAIL_GroupAccount> MAIL_GroupAccounts { get; set; }
        public virtual DbSet<MAIL_AssignAccount> MAIL_AssignAccounts { get; set; }
        public virtual DbSet<MAIL_AssignLog> MAIL_AssignLogs { get; set; }
        #endregion

        #region QA

        public virtual DbSet<QA_GroupCriteria> QA_GroupCriteria { get; set; }
        public virtual DbSet<QA_Criterial> QA_Criterial { get; set; }
        public virtual DbSet<QA_CriterialDetail> QA_CriterialDetail { get; set; }
        public virtual DbSet<QA_Mark> QA_Marks { get; set; }
        public virtual DbSet<QA_MarkDetail> QA_MarkDetails { get; set; }
        public virtual DbSet<QA_RankConfig> QA_RankConfigs { get; set; }
        public virtual DbSet<QA_AgentError> QA_AgentError { get; set; }
        public virtual DbSet<QA_MarkAgentError> QA_MarkAgentError { get; set; }
        public virtual DbSet<QA_Assign> QA_Assign { get; set; }
        public virtual DbSet<QA_AssignAccount> QA_AssignAccounts { get; set; }
        public virtual DbSet<QA_MarkFeedback> QA_MarkFeedback { get; set; }

        #endregion

        #region KMS

        public virtual DbSet<KMS_Category> KMS_Categories { get; set; }
        public virtual DbSet<KMS_Posts> KMS_Posts { get; set; }
        public virtual DbSet<KMS_Posts_Category> KMS_Posts_Category { get; set; }
        public virtual DbSet<KMS_Posts_Modifier> KMS_Posts_Modifier { get; set; }
        public virtual DbSet<KMS_Posts_Views> KMS_Posts_Views { get; set; }
        public virtual DbSet<KMS_Posts_Comments> KMS_Posts_Comments { get; set; }
        public virtual DbSet<KMS_Files_Approved> KMS_Files_Approved { get; set; }

        #endregion

        #region ZALO
        public virtual DbSet<ZW_User_send_text> User_send_text { get; set; }
        public virtual DbSet<ZW_User_send_text_detail> User_send_text_detail { get; set; }
        public virtual DbSet<Z_CustomerTag> Z_CustomerTags { get; set; }
        public virtual DbSet<Z_Customer> Z_Customers { get; set; }
        public virtual DbSet<Z_AssignLog> Z_AssignLogs { get; set; }
        public virtual DbSet<Z_Config> Z_Configs { get; set; }
        public virtual DbSet<Z_TagUser> Z_TagUsers { get; set; }
        public virtual DbSet<Z_Ctrl_Consent> Z_Ctrl_Consents { get; set; }
        public virtual DbSet<Z_Follower> Z_Followers { get; set; }
        public virtual DbSet<Z_ContactConsentData> Z_ContactConsentDatas { get; set; }
        public virtual DbSet<Z_Queue> Z_Queues { get; set; }
        public virtual DbSet<Z_QueueAccount> Z_QueueAccounts { get; set; }
        public virtual DbSet<Z_AccountClientToken> Z_AccountClientTokens { get; set; }
        public virtual DbSet<Z_AgentAnswer> Z_AgentAnswer { get; set; }
        public virtual DbSet<Z_AgentAnswerDetail> Z_AgentAnswerDetail { get; set; }

        public virtual DbSet<Z_Chat> Z_Chats { get; set; }
        public virtual DbSet<Z_ChatDetail> Z_ChatDetails { get; set; }
        public virtual DbSet<Z_Chat_Question> Z_Chat_Question { get; set; }
        public virtual DbSet<Z_ChatSession> Z_ChatSessions { get; set; }
        public virtual DbSet<Z_ChatSessionDetail> Z_ChatSessionDetails { get; set; }
        public virtual DbSet<ZNS_Booking_BA_Request> ZNS_Booking_BA_Requests { get; set; }
        public virtual DbSet<ZNS_Vote_BA_Request> ZNS_Vote_BA_Requests { get; set; }
        public virtual DbSet<Z_Ctrl_ZNS_Booking> Z_Ctrl_ZNS_Bookings { get; set; }
        public virtual DbSet<Z_Ctrl_ZNS_Vote> Z_Ctrl_ZNS_Votes { get; set; }

        #region - ZNS

        public virtual DbSet<ZNSW_User_feedback> ZNSW_User_feedbacks { get; set; }
        public virtual DbSet<ZNSW_User_feedbackDetail> ZNSW_User_feedbackDetails { get; set; }


        #endregion

        #endregion

    }
}