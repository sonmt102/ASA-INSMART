﻿using CTS.Domain.Memory;
using CTS.Domain.Zalo.Memory;
using Microsoft.EntityFrameworkCore;

namespace CTS.Infra
{
    public partial class MMContext : DbContext
    {
        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<MailQueueAccount> MailQueueAccounts { get; set; }
        public virtual DbSet<MailGroupAccount> MailGroupAccounts { get; set; }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<AccountInTicket> AccountInTickets { get; set; }

        public virtual DbSet<Queue> Queues { get; set; }
        public virtual DbSet<QueueWaiting> QueueWaitings { get; set; }
        public virtual DbSet<QueueAccount> QueueAccounts { get; set; }
        public virtual DbSet<AgentStatusCategory> AgentStatusCategories { get; set; }
        public virtual DbSet<CallData> CallDatas { get; set; }

        public virtual DbSet<VOCAssignAccount> VOCAssignAccounts { get; set; }
        public virtual DbSet<ExportExcelLog> ExportExcelLogs { get; set; }


        #region ZALO
        public DbSet<Z_Queue> Z_Queues { get; set; }
        public DbSet<Z_QueueAccount> Z_QueueAccounts { get; set; }
        public DbSet<Z_ChatSession> Z_ChatSessions { get; set; }
        public DbSet<Z_ChatSessionOA> Z_ChatSessionOAs { get; set; }
        public DbSet<Z_ChatSessionSender> Z_ChatSessionSenders { get; set; }
        public DbSet<Z_Chat_Question> Z_Chat_Question { get; set; }

        #endregion


        #region CONTRUCTOR

        public MMContext(DbContextOptions<MMContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<AccountInTicket>(e =>
            {
                e.HasKey(x => new { x.AccountId, x.TicketId });
            });

            modelBuilder.Entity<VOCAssignAccount>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<ExportExcelLog>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });

            #region VOICE

            modelBuilder.Entity<Queue>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QueueWaiting>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<QueueAccount>(e =>
            {
                e.HasKey(x => new { x.QueueId, x.AccountId });
            });
            modelBuilder.Entity<AgentStatusCategory>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<CallData>(e =>
            {
                e.HasKey(k => k.UniqueId);
                e.Property(p => p.UniqueId).ValueGeneratedOnAdd();
            });

            #endregion

            #region MAIL

            modelBuilder.Entity<MailQueueAccount>(e =>
            {
                e.HasKey(x => x.Id);
            });
            modelBuilder.Entity<MailGroupAccount>(e =>
            {
                e.HasKey(x => new { x.AccountId, x.GroupId });
            });
            #endregion

            #region ZALO

            modelBuilder.Entity<Z_Queue>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_QueueAccount>(e =>
            {
                e.HasKey(x => new { x.AccountId, x.Z_QueueId });
            });
            modelBuilder.Entity<Z_ChatSession>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_ChatSessionOA>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_ChatSessionSender>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            modelBuilder.Entity<Z_Chat_Question>(e =>
            {
                e.HasKey(k => k.Id);
                e.Property(p => p.Id).ValueGeneratedOnAdd();
            });
            #endregion



            base.OnModelCreating(modelBuilder);
        }

        #endregion
    }
}
