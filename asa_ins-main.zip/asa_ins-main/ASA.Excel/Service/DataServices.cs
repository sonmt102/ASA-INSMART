﻿using ASA.Excel.Models;
using ASA.Excel.Models.VOC;
using CTS.Common;
using CTS.Domain.VOC;
using CTS.Infra;
using Hangfire;
using Microsoft.EntityFrameworkCore;

namespace ASA.Excel.Service
{
    public interface IDataServices
    {
        Task Handler();
    }
    public class DataServices : IDataServices
    {
        private readonly ILogger<DataServices> _logger;
        private readonly CTSContext _Context;
        private readonly IBackgroundJobClient _BackgroundJobClient;

        public DataServices(ILogger<DataServices> logger, CTSContext context, IBackgroundJobClient backgroundJobClient)
        {
            _logger = logger;
            _Context = context;
            _BackgroundJobClient = backgroundJobClient;
        }

        #region - Ticket
        //Trong ticket khi cập nhật ticket thì xử lý cả xuất excel của cs và op

        /// <summary>
        /// Lấy ra những bản ghi update mà chưa xử lý
        /// </summary>
        /// <returns></returns>
        public async Task<List<VOC_Export_Check>> GetNotHandler()
        {
            //DateTime dt = new DateTime(2023, 10, 10);
            //var item = await _Context.VOC_Tickets.Where(x => x.KenhTiepNhan == "KTN010" && x.CreatedDate >= dt).Select(s => s.Id).ToListAsync();
            //return await _Context.VOC_Export_Checks.Where(x => item.Contains(x.Id)).ToListAsync();


            return await _Context.VOC_Export_Checks.Where(x => !x.IsHandler).ToListAsync();
        }

        public async Task Handler()
        {
            try
            {
                var data = await GetNotHandler();
                if (data == null || data.Count == 0)
                {
                    _BackgroundJobClient.Schedule(() => Handler(), TimeSpan.FromSeconds(10));
                    return;
                }

                //Xử lý paging
                var take = 20;
                var skip = 0;

                var total = data.Count;


                var cateBoPhanThuLy = await _Context.Categories.Where(x => x.Parent.Code == CategoryConst.VOC_BoPhanThuLy)
                  .Select(s => new CategoryModel
                  {
                      Name = s.Name,
                      Code = s.Code
                  }).ToListAsync();

                for (int i = 0; i < total; i++)
                {
                    var myIds = data.Skip(skip).Take(take).Select(s => s.Id).ToList();

                    //Xử lý excel CS
                    await Handler_CSExport(myIds, cateBoPhanThuLy);

                    //Cập nhật đã xử lý
                    await UpdateHandlerCheck(myIds);

                    _logger.LogInformation($"---------------------------skip: {skip}, take: {take}, records");

                    skip += myIds.Count;
                    if (skip >= total) break;

                }

                _BackgroundJobClient.Schedule(() => Handler(), TimeSpan.FromSeconds(10));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                _BackgroundJobClient.Schedule(() => Handler(), TimeSpan.FromSeconds(10));
            }


        }

        /// <summary>
        /// Xử lý excel CS
        /// </summary>
        /// <param name="ticketIds"></param>
        /// <param name="cateBoPhanThuLy"></param>
        /// <returns></returns>
        public async Task Handler_CSExport(List<Guid> ticketIds, List<CategoryModel> cateBoPhanThuLy)
        {
            var result = await _Context.VOC_Tickets.Where(x => ticketIds.Contains(x.Id))
                   .Select(s => new CSExportTicketModel
                   {
                       Id = s.Id,
                       CustomerName = s.CustomerName,
                       Phone = s.CustomerPhone,
                       CustomerEmail = s.Email,
                       ThoiGianTiepNhanEmail = s.TTHS_NgayGioTNEmail,
                       CreatedDate = s.CreatedDate,
                       Status = s.Status,
                       KenhTiepNhan = s.KenhTiepNhan,
                       NextReminderDate = s.NextReminderDate,
                       Code = s.MaSV,
                       LoaiKhieuNai = s.TTHS_LoaiKL,
                       CongTy = s.TTSV_CongTy,
                       LoaiSuVu = s.TTSV_LoaiSV,
                       LoaiYeuCau = s.TTSV_LoaiYeuCau,
                       YeuCau = s.TTSV_YeuCau,
                       SoHD = s.TTHS_SoHD,
                       SoHS = s.TTHS_SoHS,
                       Urgent = s.Urgent,
                       BenMuaBH = s.TTHS_BenMuaBH,
                       ClaimId = s.ClaimID,
                       CustomerType = s.DoiTuongGoiDen,
                       LoaiHoSo = s.TTHS_LoaiHS,
                       MoiGioi = s.CongTyMoiGioi,
                       NguoiDuocBH = s.TTHS_NguoiDuocBH,
                       NguoiXuLy = s.CRM_Account.UserName,
                       NguoiXuLyId = s.CRM_AccountId ?? Guid.NewGuid(),
                       CreatedBy = s.CreatedBy,
                       UpdatedBys = s.VOC_TicketHistories.Select(h => h.CreatedBy).ToList(),
                       SoLanChuyenOP = s.VOC_TransferOPs.Count,
                       TongThoiGianCSPhanHoiKH = s.CSTATTotal,
                       CompleteDate = s.CompleteDate,
                       IsComplete = s.CompleteDate.HasValue,
                       NguyenNhanDTKN = s.QTXL_NguyenNhanDTKN,
                       ChiTietNguyenNhanKN = s.ChiTietNguyenNhanKN,
                       IsFollow = s.IsFollow,
                       CSPhanHoiKH = s.CSPhanHoiKH
                   }).ToListAsync();

            if (result != null && result.Count > 0)
            {
                var myids = result.Select(s => s.Id).ToList();

                #region - Xử lý transfer
                var myTransOPs = await _Context.VOC_TransferOP.Where(x => myids.Contains(x.VOC_TicketId))
                    .Select(t => new CSExportTicketTransOPModel
                    {
                        TransferOPId = t.Id,
                        VOC_TicketId = t.VOC_TicketId,
                        TransDate = t.TransDate,
                        BoPhanThuLy = t.CTSV_BoPhanTL,
                        BoPhanThuLyCode = t.CTSV_BoPhanTL,
                        CSPhanHoiKH = t.CSPhanHoiKH,
                        Status = t.Status,
                        OrderStatus = t.OrderStatus,
                        Urgent = t.Urgent,
                        CheckCSYT = t.CheckCSYT,
                        CheckCTBH = t.CheckCTBH,
                        CheckBank = t.CheckBank,
                        CheckHDCM = t.CheckHDCM,
                        NguoiXuLy = t.NguoiXuLy,
                        OPHandlerDate = t.OPHandlerDate,
                        TongThoiGianOPPhanHoi = t.OPTATTotal,
                        TongThoiGianCSPhanHoi = t.CSTATTotal,
                        OPContents = t.VOC_OPHandler_OPContents.Select(c => new CSExportTicketContentModel
                        {
                            Content = c.Content.Substring(0, 5000),
                            CreatedDate = c.Date,
                            CreatedBy = c.CreatedBy,
                        }).ToList()
                    }).ToListAsync();
                if (myTransOPs != null && myTransOPs.Count > 0)
                {
                    myTransOPs.ForEach(t =>
                    {
                        t.BoPhanThuLy = cateBoPhanThuLy.Where(c => c.Code == t.BoPhanThuLyCode).Select(s => s.Name).FirstOrDefault();
                    });
                }

                result.ForEach(x =>
                {
                    x.TransferOPs = myTransOPs.Where(t => t.VOC_TicketId == x.Id).OrderBy(s => s.TransDate).ToList();
                });
                #endregion

                #region - Xử lý Ticket contents

                var myContents = await _Context.VOC_TicketContents.Where(x => myids.Contains(x.VOC_TicketId))
                    .Select(c => new CSExportTicketContentModel
                    {
                        VOC_TicketId = c.VOC_TicketId,
                        Content = c.Content.Substring(0, 5000),
                        CreatedDate = c.CreatedDate,
                        CreatedBy = c.CreatedBy
                    }).ToListAsync();

                result.ForEach(x =>
                {
                    x.NoiDungSVs = myContents.Where(t => t.VOC_TicketId == x.Id).OrderBy(x => x.CreatedDate).Take(2).ToList();
                });

                #endregion

                #region - Xử lý CS handler content

                var myCSHandlerContents = await _Context.VOC_Ticket_CSHandlerContents.Where(x => myids.Contains(x.VOC_TicketId))
                    .Select(c => new CSExportTicketContentModel
                    {
                        VOC_TicketId = c.VOC_TicketId,
                        Content = c.Content.Substring(0, 5000),
                        CreatedDate = c.CreatedDate,
                        CreatedBy = c.CreatedBy
                    }).ToListAsync();

                result.ForEach(x =>
                {
                    x.CSContents = myCSHandlerContents.Where(t => t.VOC_TicketId == x.Id).OrderBy(x => x.CreatedDate).Take(2).ToList();
                });

                #endregion

            }

            if (result != null && result.Count > 0)
            {
                for (int i = 0; i < result.Count; i++)
                {
                    var item = await _Context.VOC_Export_TicketDetails
                        .Include(x => x.VOC_Export_TicketDetail_Transfers)
                        .ThenInclude(x => x.VOC_Export_TicketDetail_Transfer_Handlers)
                        .Where(x => x.Id == result[i].Id).FirstOrDefaultAsync();
                    if (item != null)
                    {
                        item.NextReminderDate = result[i].NextReminderDate;
                        item.ThoiGianTiepNhanEmail = result[i].ThoiGianTiepNhanEmail;
                        item.LoaiKhieuNai = result[i].LoaiKhieuNai;
                        item.LoaiSuVu = result[i].LoaiSuVu;
                        item.NguoiXuLy = result[i].NguoiXuLy;
                        item.YeuCau = result[i].YeuCau;
                        item.NguoiDuocBH = result[i].NguoiDuocBH;
                        item.NguoiXuLyId = result[i].NguoiXuLyId;
                        item.BenMuaBH = result[i].BenMuaBH;
                        item.ClaimId = result[i].ClaimId;
                        item.Code = result[i].Code;
                        item.CompleteDate = result[i].CompleteDate;
                        item.CongTy = result[i].CongTy;
                        item.CreatedBy = result[i].CreatedBy;
                        item.CreatedDate = result[i].CreatedDate;
                        item.CSContent = result[i].CSContent;
                        item.CustomerEmail = result[i].CustomerEmail;
                        item.CustomerName = result[i].CustomerName;
                        item.CustomerType = result[i].CustomerType;
                        item.IsComplete = result[i].IsComplete;
                        item.KenhTiepNhan = result[i].KenhTiepNhan;
                        item.LoaiHoSo = result[i].LoaiHoSo;
                        item.LoaiYeuCau = result[i].LoaiYeuCau;
                        item.MoiGioi = result[i].MoiGioi;
                        item.NguyenNhanDTKN = result[i].NguyenNhanDTKN;
                        item.ChiTietNguyenNhanKN = result[i].ChiTietNguyenNhanKN;
                        item.NoiDungSV = result[i].NoiDungSV;
                        item.Phone = result[i].Phone;
                        item.SoHD = result[i].SoHD;
                        item.SoHS = result[i].SoHS;
                        item.SoLanChuyenOP = result[i].SoLanChuyenOP;
                        item.Status = result[i].Status;
                        item.TongThoiGianCSPhanHoiKH = result[i].TongThoiGianCSPhanHoiKH;
                        item.Urgent = result[i].Urgent;
                        item.UpdatedByStr = result[i].UpdatedByStr;
                        item.IsFollow = result[i].IsFollow;
                        item.CSPhanHoiKH = result[i].CSPhanHoiKH;

                        if (item.VOC_Export_TicketDetail_Transfers != null && item.VOC_Export_TicketDetail_Transfers.Count > 0)
                        {
                            _Context.VOC_Export_TicketDetail_Transfers.RemoveRange(item.VOC_Export_TicketDetail_Transfers);
                            foreach (var tran in item.VOC_Export_TicketDetail_Transfers)
                            {
                                if (tran.VOC_Export_TicketDetail_Transfer_Handlers != null && tran.VOC_Export_TicketDetail_Transfer_Handlers.Count > 0)
                                {
                                    _Context.VOC_Export_TicketDetail_Transfer_Handlers.RemoveRange(tran.VOC_Export_TicketDetail_Transfer_Handlers);
                                }
                            }

                        }
                        if (result[i].TransferOPs != null && result[i].TransferOPs.Count > 0)
                        {
                            var data = result[i].TransferOPs.Select(s => new VOC_Export_TicketDetail_Transfer
                            {
                                Id = Guid.NewGuid(),
                                TransferOPId = s.TransferOPId,
                                BoPhanTL = s.BoPhanThuLyCode,
                                CheckBank = s.CheckBank,
                                CheckCSYT = s.CheckCSYT,
                                CheckCTBH = s.CheckCTBH,
                                CheckHDCM = s.CheckHDCM,
                                CSPhanHoiKH = s.CSPhanHoiKH,
                                OrderStatus = s.OrderStatus,
                                Urgent = s.Urgent,
                                OPHandlerDate = s.OPHandlerDate,
                                Status = s.Status,
                                TransDate = s.TransDate,
                                VOC_Export_TicketDetailId = item.Id,
                                OPContent = s.OPContent,
                                NguoiXuLy = s.NguoiXuLy,
                                VOC_Export_TicketDetail_Transfer_Handlers = s.CreatedBys.Select(c => new VOC_Export_TicketDetail_Transfer_Handler
                                {
                                    Id = Guid.NewGuid(),
                                    Handler = c
                                }).ToList()
                            }).OrderBy(x => x.TransDate).ToList();
                            await _Context.VOC_Export_TicketDetail_Transfers.AddRangeAsync(data);

                            for (int j = 0; j < result[i].TransferOPs.Count; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        item.LanChuyen1 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 1:
                                        item.LanChuyen2 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 2:
                                        item.LanChuyen3 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 3:
                                        item.LanChuyen4 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 4:
                                        item.LanChuyen5 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 5:
                                        item.LanChuyen6 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 6:
                                        item.LanChuyen7 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 7:
                                        item.LanChuyen8 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 8:
                                        item.LanChuyen9 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 9:
                                        item.LanChuyen10 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 10:
                                        item.LanChuyen11 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 11:
                                        item.LanChuyen12 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 12:
                                        item.LanChuyen13 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 13:
                                        item.LanChuyen14 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 14:
                                        item.LanChuyen15 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 15:
                                        item.LanChuyen16 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 16:
                                        item.LanChuyen17 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 17:
                                        item.LanChuyen18 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 18:
                                        item.LanChuyen19 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    case 19:
                                        item.LanChuyen20 = result[i].TransferOPs[j].OPContent;
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                    else
                    {
                        var itemAdd = new VOC_Export_TicketDetail
                        {
                            Id = result[i].Id,
                            LoaiSuVu = result[i].LoaiSuVu,
                            NguoiXuLy = result[i].NguoiXuLy,
                            YeuCau = result[i].YeuCau,
                            NguoiDuocBH = result[i].NguoiDuocBH,
                            NguoiXuLyId = result[i].NguoiXuLyId,
                            BenMuaBH = result[i].BenMuaBH,
                            NextReminderDate = result[i].NextReminderDate,
                            ThoiGianTiepNhanEmail = result[i].ThoiGianTiepNhanEmail,
                            ClaimId = result[i].ClaimId,
                            Code = result[i].Code,
                            CompleteDate = result[i].CompleteDate,
                            CongTy = result[i].CongTy,
                            CreatedBy = result[i].CreatedBy,
                            CreatedDate = result[i].CreatedDate,
                            CSContent = result[i].CSContent,
                            CustomerEmail = result[i].CustomerEmail,
                            CustomerName = result[i].CustomerName,
                            CustomerType = result[i].CustomerType,
                            IsComplete = result[i].IsComplete,
                            LoaiKhieuNai = result[i].LoaiKhieuNai,
                            KenhTiepNhan = result[i].KenhTiepNhan,
                            LoaiHoSo = result[i].LoaiHoSo,
                            LoaiYeuCau = result[i].LoaiYeuCau,
                            MoiGioi = result[i].MoiGioi,
                            NguyenNhanDTKN = result[i].NguyenNhanDTKN,
                            ChiTietNguyenNhanKN = result[i].ChiTietNguyenNhanKN,
                            NoiDungSV = result[i].NoiDungSV,
                            Phone = result[i].Phone,
                            SoHD = result[i].SoHD,
                            SoHS = result[i].SoHS,
                            SoLanChuyenOP = result[i].SoLanChuyenOP,
                            Status = result[i].Status,
                            TongThoiGianCSPhanHoiKH = result[i].TongThoiGianCSPhanHoiKH,
                            Urgent = result[i].Urgent,
                            UpdatedByStr = result[i].UpdatedByStr,
                            IsFollow = result[i].IsFollow,
                            CSPhanHoiKH = result[i].CSPhanHoiKH,
                            VOC_Export_TicketDetail_Transfers = result[i].TransferOPs.Select(s => new VOC_Export_TicketDetail_Transfer
                            {
                                Id = Guid.NewGuid(),
                                TransferOPId = s.TransferOPId,
                                BoPhanTL = s.BoPhanThuLyCode,
                                CheckBank = s.CheckBank,
                                CheckCSYT = s.CheckCSYT,
                                CheckCTBH = s.CheckCTBH,
                                CheckHDCM = s.CheckHDCM,
                                CSPhanHoiKH = s.CSPhanHoiKH,
                                OPHandlerDate = s.OPHandlerDate,
                                NguoiXuLy = s.NguoiXuLy,
                                Status = s.Status,
                                TransDate = s.TransDate,
                                VOC_Export_TicketDetailId = result[i].Id,
                                OrderStatus = s.OrderStatus,
                                Urgent = s.Urgent,
                                OPContent = s.OPContent,
                                VOC_Export_TicketDetail_Transfer_Handlers = s.CreatedBys.Select(c => new VOC_Export_TicketDetail_Transfer_Handler
                                {
                                    Id = Guid.NewGuid(),
                                    Handler = c
                                }).ToList()
                            }).ToList()
                        };

                        for (int j = 0; j < result[i].TransferOPs.Count; j++)
                        {
                            switch (j)
                            {
                                case 0:
                                    itemAdd.LanChuyen1 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 1:
                                    itemAdd.LanChuyen2 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 2:
                                    itemAdd.LanChuyen3 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 3:
                                    itemAdd.LanChuyen4 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 4:
                                    itemAdd.LanChuyen5 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 5:
                                    itemAdd.LanChuyen6 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 6:
                                    itemAdd.LanChuyen7 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 7:
                                    itemAdd.LanChuyen8 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 8:
                                    itemAdd.LanChuyen9 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 9:
                                    itemAdd.LanChuyen10 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 10:
                                    itemAdd.LanChuyen11 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 11:
                                    itemAdd.LanChuyen12 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 12:
                                    itemAdd.LanChuyen13 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 13:
                                    itemAdd.LanChuyen14 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 14:
                                    itemAdd.LanChuyen15 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 15:
                                    itemAdd.LanChuyen16 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 16:
                                    itemAdd.LanChuyen17 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 17:
                                    itemAdd.LanChuyen18 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 18:
                                    itemAdd.LanChuyen19 = result[i].TransferOPs[j].OPContent;
                                    break;
                                case 19:
                                    itemAdd.LanChuyen20 = result[i].TransferOPs[j].OPContent;
                                    break;
                                default:
                                    break;
                            }
                        }

                        await _Context.VOC_Export_TicketDetails.AddAsync(itemAdd);

                    }
                }
                await _Context.SaveChangesAsync();
            }
        }

        /// <summary>
        /// Cập nhật Id đã xử lý
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task UpdateHandlerCheck(List<Guid> ids)
        {
            var item = await _Context.VOC_Export_Checks.Where(x => ids.Contains(x.Id)).ToListAsync();
            if (item != null && item.Count > 0)
            {
                item.ForEach(x => x.IsHandler = true);
                await _Context.SaveChangesAsync();
            }
        }


        #endregion




    }
}
