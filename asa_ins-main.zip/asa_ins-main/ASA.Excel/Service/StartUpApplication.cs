﻿namespace ASA.Excel.Service
{
    public class StartUpApplication : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpApplication> _logger;

        public StartUpApplication(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpApplication> logger)
        {
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }


        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _DataServices = scope.ServiceProvider.GetRequiredService<IDataServices>();


                {
                    await _DataServices.Handler();
                    _logger.LogInformation($"SETUP RUN EXCEL SERVICES SUCCESS!!!!!");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }
    }
}
