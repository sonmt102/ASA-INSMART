﻿using ASA.Excel.Service;
using CTS.Infra;
using Microsoft.EntityFrameworkCore;
using System.Net;

namespace ASA.Excel.Installer
{
    public static class EFInstaller
    {
        public static IServiceCollection AddEFConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            var connectionString = configuration.GetConnectionString("DBConnection");
            services.AddDbContext<CTSContext>(options =>
            {
                options.UseLazyLoadingProxies().UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
            });


            services.AddTransient<IDataServices, DataServices>();

            return services;
        }
    }
}
