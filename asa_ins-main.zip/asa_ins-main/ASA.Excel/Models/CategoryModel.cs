﻿namespace ASA.Excel.Models
{
    public class CategoryModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
