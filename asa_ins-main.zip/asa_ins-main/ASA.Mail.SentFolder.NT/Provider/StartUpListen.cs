﻿using ASA.Mail.Models;
using ASA.Mail.SentFolder.NT.Services;
using ASA.Mail.Services;
using CTS.Common;
using Microsoft.Extensions.Options;
using System.Diagnostics;

namespace ASA.Mail.SentFolder.NT.Provider
{
    /// <summary>
    /// MBAL
    /// </summary>
    public class StartUpListen : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpListen> _logger;
        private readonly List<EmailConfigModel> _EmailConfigs;

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="IServiceScopeFactory"></param>
        /// <param name="logger"></param>
        /// <param name="options"></param>
        public StartUpListen(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpListen> logger,
            IOptions<List<EmailConfigModel>> options)
        {
            _EmailConfigs = options.Value;
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }

        /// <summary>
        /// Run
        /// </summary>
        /// <param name="stoppingToken"></param>
        /// <returns></returns>
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _nt = scope.ServiceProvider.GetRequiredService<IIdleClientNhanTho_SentServices>();
                var _StartUpServices = scope.ServiceProvider.GetRequiredService<IStartUpServices>();

                var configHD = _EmailConfigs.Where(x => x.Type == MailType.NhanTho).FirstOrDefault();
                if (configHD != null)
                {
                    var check = await _nt.RunAsync(configHD);
                    if (!check.Item1)
                    {
                        Console.WriteLine($"FAIL CONNECT EMAIL NT");
                        Console.WriteLine($"Error: {check.Item2}");
                    }
                }


                //Khởi tạo lịch kiểm chạy lại hệ thống mỗi giờ
                {
                    if (!Debugger.IsAttached)
                    {
                        _StartUpServices.SetupScheduleRestartService();
                        _logger.LogInformation("SETUP RESTART SERVICE MAIL NT SENT FOLDER SUCCESS!!!!!");
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

    }
}
