﻿namespace CTS.Common
{
    public static class VoiceSettingConst
    {
        /// <summary>
        /// POPUP
        /// </summary>
        public const string Code1 = "code-1";
        /// <summary>
        /// Xóa cảnh báo cuộc gọi nhỡ đến Agent
        /// </summary>
        public const string Code2 = "code-2";
        /// <summary>
        /// Thời gian xóa cuộc gọi rớt trên màn hình Supervisor
        /// </summary>
        public const string Code3 = "code-3";
        /// <summary>
        /// Nhóm gọi ra mặc định
        /// </summary>
        public const string Code4 = "code-4";
    }
    public static class ContactRedisHashKey
    {
        public const string Key = "MICContact";
    }


    public static class UserEventStatusConst
    {
        /// <summary>
        /// Vào IVR
        /// </summary>
        public const string IVR = "IVR";
        /// <summary>
        /// Gọi ra
        /// </summary>
        public const string CALLOUTBOUND = "CALLOUTBOUND";
        /// <summary>
        /// Gọi nội bộ
        /// </summary>
        public const string INTERCOM = "INTERCOM";
        /// <summary>
        /// Vào queue
        /// </summary>
        public const string ENTERQUEUE = "ENTERQUEUE";
        /// <summary>
        /// Nghe máy
        /// </summary>
        public const string ANSWER = "ANSWER";
        /// <summary>
        /// Nghe máy trường hợp gọi ra 
        /// </summary>
        public const string ANSWER_OUTBOUND = "ANSWER_OUTBOUND";
        /// <summary>
        /// Chuyển cuộc gọi
        /// </summary>
        public const string TRANSFER = "TRANSFER";
        /// <summary>
        /// Ngắt máy
        /// </summary>
        public const string HANGUP = "HANGUP";
        /// <summary>
        /// Ngắt máy
        /// </summary>
        public const string HANGUPVOIPCC = "HANGUPVOIPCC";
        /// <summary>
        /// Giữ máy
        /// </summary>
        public const string HOLD = "HOLD";
        /// <summary>
        /// Bỏ giữ máy
        /// </summary>
        public const string UNHOLD = "UNHOLD";
        /// <summary>
        /// Đổ chuông
        /// </summary>
        public const string RINGING = "RINGING";
        /// <summary>
        /// Divert
        /// </summary>
        public const string DIVERT = "INS_DIVERT";
        public const string NONE_DIVERT = "DIVERT";
    }
    public static class AgentStatusConst
    {
        /// <summary>
        /// Sẵn sàng blue-1
        /// </summary>
        public const string SanSang = "blue-1";
        /// <summary>
        /// Nghỉ trưa pause-1
        /// </summary>
        public const string NghiTrua = "pause-1";
        /// <summary>
        /// Email pause-2
        /// </summary>
        public const string Email = "pause-2";
        /// <summary>
        /// Đi họp pause-3
        /// </summary>
        public const string Hop = "pause-3";
        /// <summary>
        /// Ra ngoài pause-4
        /// </summary>
        public const string RaNgoai = "pause-4";
        /// <summary>
        /// Việc riêng pause-5
        /// </summary>
        public const string ViecRieng = "pause-5";
        /// <summary>
        /// Ăn tối pause-6
        /// </summary>
        public const string AnToi = "pause-6";
        /// <summary>
        /// Nhập liệu pause-7
        /// </summary>
        public const string NhapLieu = "pause-7";
        /// <summary>
        /// Đăng nhập hệ thống gre-1
        /// </summary>
        public const string DangNhap = "gre-1";
        /// <summary>
        /// Supervisor loại khỏi nhóm war-1
        /// </summary>
        public const string SUP_Logout = "war-1";
        /// <summary>
        /// Rời nhóm war-3
        /// </summary>
        public const string RoiNhom = "war-3";
        /// <summary>
        /// Vào nhóm war-4
        /// </summary>
        public const string VaoNhom = "war-4";
        /// <summary>
        /// Người dùng yêu cầu logout war-5
        /// </summary>
        public const string RequestLogout = "war-5";
        /// <summary>
        /// Đăng xuất hệ thống red-1
        /// </summary>
        public const string DangXuat = "red-1";
        /// <summary>
        /// Supervisor đặt trạng thái tạm dừng war-2
        /// </summary>
        public const string SUP_Pause = "war-2";
        /// <summary>
        /// Supervisor đặt trạng thái sẵn sàng war-6
        /// </summary>
        public const string SUP_UnPause = "war-6";
        /// <summary>
        /// Chưa sẵn sàng gre-2
        /// </summary>
        public const string ChuaSanSang = "gre-2";
        /// <summary>
        /// Xử lý backend backend-1
        /// </summary>
        public const string BackEnd1 = "backend-1";
    }

    public static class AgentAccountExtension2Const
    {
        public const string Code = "_secondary";
    }


    public static class VOCRequestTypeCode
    {
        /// <summary>
        /// Thông báo tổn thất
        /// </summary>
        public const string TBTT = "TBTT";
        /// <summary>
        /// Khiếu nại
        /// </summary>
        public const string KN = "KN";
        /// <summary>
        /// Sản phẩm
        /// </summary>
        public const string SP = "SP";
        /// <summary>
        /// Thông tin khác
        /// </summary>
        public const string KHAC = "KHAC";
    }

    #region TICKET

    public static class ContactFieldConst
    {
        /// <summary>
        /// Trường nhập chữ(Textbox)
        /// </summary>
        public const string Textbox = "textbox";
        /// <summary>
        /// Trường danh sách lựa chọn(Combobox)
        /// </summary>
        public const string Combobox = "combobox";
        /// <summary>
        /// Trường nhập ngày(Date)
        /// </summary>
        public const string Date = "date";
        /// <summary>
        /// Trường nhập giờ(Time)
        /// </summary>
        public const string Time = "time";
        /// <summary>
        /// Trường ngày giờ(DateTime)
        /// </summary>
        public const string Datetime = "datetime";
        /// <summary>
        /// Trường nhập chữ nhiều dòng(Textarea)
        /// </summary>
        public const string Textarea = "textarea";
    }

    public static class TicketSignalEventConst
    {
        public const string TICKET_OutOfDate = "TICKET_OutOfDate";
    }

    #endregion
}
