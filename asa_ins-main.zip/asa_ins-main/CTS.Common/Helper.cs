﻿using Microsoft.AspNetCore.StaticFiles;
using Microsoft.AspNetCore.WebUtilities;
using System.ComponentModel;
using System.Data;
using System.Dynamic;
using System.Globalization;
using System.Linq.Expressions;
using System.Net;
using System.Net.Mail;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace CTS.Common
{
    public static class Helper
    {

        public static async Task<string> DumpTokenRequest(HttpRequestMessage request)
        {
            var content = await request.Content.ReadAsStringAsync();
            var sb = new StringBuilder();
            sb.AppendLine($"Request to:\n {request.RequestUri}");
            var queryStringParsed = QueryHelpers.ParseQuery(content);
            foreach (var element in queryStringParsed)
            {
                var value = element.Value;
                if (element.Key.Contains("secret"))
                {
                    value = new String('*', element.Value.Single().Length);
                }
                sb.AppendLine($"{element.Key} = {value}");
            }
            return sb.ToString();
        }

        public static string UrlFriendly(string url)
        {
            return Regex.Replace(url, @"[^A-Za-z0-9_\.~]+", "-");
        }

        public static int GetOrder_OPStatus(OPHandler_Status status)
        {
            return status switch
            {
                OPHandler_Status.ChuaXuLy => 0,
                OPHandler_Status.DangXuLy => 1,
                OPHandler_Status.DaXuLy => 2,
                OPHandler_Status.PhuongAnChuaDayDu => 1,
                OPHandler_Status.KhongPhanHoi => 1,
                _ => 0,
            };
        }

        public static DateTime? StringUnixTimeStampMilisecondToDateTime(string unixTimeStamp)
        {
            if (long.TryParse(unixTimeStamp, out long myValue))
            {
                // Unix timestamp is seconds past epoch
                var dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                dtDateTime = dtDateTime.AddMilliseconds(myValue).ToLocalTime();
                return dtDateTime;
            }
            return null;

        }
        public static DateTime LongMilisecondsTimeStampToDateTime(long unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            var dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddMilliseconds(unixTimeStamp).ToLocalTime();
            return dtDateTime;
        }

        /// <summary>
        /// Định dạng sđt cho zalo
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public static string FormatZaloPhone(this string phone)
        {
            if (string.IsNullOrEmpty(phone) || phone.Length < 2 || phone[..2] == "84") return phone;
            return $"84{phone[1..]}";
        }
        public static string ZaloBase64UrlEncode(byte[] arg)
        {
            string s = Convert.ToBase64String(arg); // Regular base64 encoder
            s = s.Split('=')[0]; // Remove any trailing '='s
            s = s.Replace('+', '-'); // 62nd char of encoding
            s = s.Replace('/', '_'); // 63rd char of encoding
            return s;
        }
        public static string ReplaceInvalidChars(string filename)
        {
            return string.Join("_", filename.Split(Path.GetInvalidFileNameChars()));
        }

        public static string RemoveSpecialCharacters(this string str)
        {
            var sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '.' || c == '_')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        public static string FormatSize(Int64 bytes)
        {
            string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };
            int counter = 0;
            decimal number = (decimal)bytes;
            while (Math.Round(number / 1024) >= 1)
            {
                number = number / 1024;
                counter++;
            }
            return string.Format("{0:n1}{1}", number, suffixes[counter]);
        }

        public static string ConvertSecondsToDate(this int? seconds)
        {
            var data = seconds ?? 0;
            TimeSpan t = TimeSpan.FromSeconds(data);

            if (t.Days > 0)
                return t.ToString(@"d\d\,\ hh\:mm\:ss");
            return t.ToString(@"hh\:mm\:ss");
        }

        public static string ConvertMinutesToDate(this int minutes)
        {
            TimeSpan t = TimeSpan.FromMinutes(minutes);

            if (t.Days > 0)
                return t.ToString(@"d\d\,\ hh\:mm\:ss");
            return t.ToString(@"hh\:mm\:ss");
        }

        public static DateTime GetVOCDeadline(this DateTime myTime, int time, VOCDeadlineTimeType type)
        {
            return type switch
            {
                VOCDeadlineTimeType.Phut => myTime.AddMinutes(time),
                VOCDeadlineTimeType.Gio => myTime.AddHours(time),
                VOCDeadlineTimeType.Ngay => myTime.AddDays(time),
                _ => myTime,
            };
        }
        public static string MIC_GetHashedMessage(string _secret, string message)
        {
            var encoding = new UTF8Encoding();
            var keyBytes = encoding.GetBytes(_secret);
            var messageBytes = encoding.GetBytes(message);

            using var hmacsha1 = new HMACSHA1(keyBytes);
            var hashMessage = hmacsha1.ComputeHash(messageBytes);
            return Convert.ToBase64String(hashMessage);
        }

        public static string MIC_ByteToString(byte[] buff)
        {
            string sbinary = "";

            for (int i = 0; i < buff.Length; i++)
            {
                sbinary += buff[i].ToString("X2"); // hex format
            }
            return (sbinary);
        }
        public static DateTime StartOfWeek(this DateTime dt, DayOfWeek startOfWeek)
        {
            int diff = (7 + (dt.DayOfWeek - startOfWeek)) % 7;
            return dt.AddDays(-1 * diff).Date;
        }

        public static dynamic[] ToPivotArray<T, TColumn, TRow, TData>(
                this IEnumerable<T> source,
                Func<T, TColumn> columnSelector,
                Expression<Func<T, TRow>> rowSelector,
                Func<IEnumerable<T>, TData> dataSelector)
        {

            var arr = new List<object>();
            var cols = new List<string>();
            String rowName = ((MemberExpression)rowSelector.Body).Member.Name;
            var columns = source.Select(columnSelector).Distinct();

            cols = (new[] { rowName }).Concat(columns.Select(x => x.ToString())).ToList();


            var rows = source.GroupBy(rowSelector.Compile())
                             .Select(rowGroup => new
                             {
                                 rowGroup.Key,
                                 Values = columns.GroupJoin(
                                     rowGroup,
                                     c => c,
                                     r => columnSelector(r),
                                     (c, columnGroup) => dataSelector(columnGroup))
                             }).ToArray();


            foreach (var row in rows)
            {
                var items = row.Values.Cast<object>().ToList();
                items.Insert(0, row.Key);
                var obj = GetAnonymousObject(cols, items);
                arr.Add(obj);
            }
            return arr.ToArray();
        }
        private static dynamic GetAnonymousObject(IEnumerable<string> columns, IEnumerable<object> values)
        {
            IDictionary<string, object> eo = new ExpandoObject() as IDictionary<string, object>;
            int i;
            for (i = 0; i < columns.Count(); i++)
            {
                eo.Add(columns.ElementAt<string>(i), values.ElementAt<object>(i));
            }
            return eo;
        }

        public static DataTable ToPivotTable<T, TColumn, TRow, TData>(
            this IEnumerable<T> source,
            Func<T, TColumn> columnSelector,
            Expression<Func<T, TRow>> rowSelector,
            Func<IEnumerable<T>, TData> dataSelector)
        {
            var table = new DataTable();
            var rowName = ((MemberExpression)rowSelector.Body).Member.Name;
            table.Columns.Add(new DataColumn(rowName));
            var columns = source.Select(columnSelector).Distinct();

            foreach (var column in columns)
                table.Columns.Add(new DataColumn(column.ToString()));

            var rows = source.GroupBy(rowSelector.Compile())
                             .Select(rowGroup => new
                             {
                                 rowGroup.Key,
                                 Values = columns.GroupJoin(
                                     rowGroup,
                                     c => c,
                                     r => columnSelector(r),
                                     (c, columnGroup) => dataSelector(columnGroup))
                             });

            foreach (var row in rows)
            {
                var dataRow = table.NewRow();
                var items = row.Values.Cast<object>().ToList();
                items.Insert(0, row.Key);
                dataRow.ItemArray = items.ToArray();
                table.Rows.Add(dataRow);
            }

            return table;
        }

        public static DateTime StartOfDay(this DateTime theDate)
        {
            return theDate.Date;
        }
        public static DateTime EndOfDay(this DateTime theDate)
        {
            return theDate.Date.AddDays(1).AddTicks(-1);
        }

        /// <summary>
        /// Bỏ những ký tự không phải là chữ
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static string RemoveSpecialCharacter(this string? s)
        {

            s = new string(s.Where(c => char.IsLetterOrDigit(c)).ToArray());

            //if (string.IsNullOrEmpty(s)) return string.Empty;
            //var rgx = new Regex("[^a-zA-Z0-9]");
            //s = rgx.Replace(s, "");
            return s;
        }

        public static string TryGetMineTypeFromFile(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(fileName, out string contentType))
            {
                contentType = "image/jpeg";
            }
            return contentType;
        }

        public static string TryGetMineTypeFromFileEmail(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(fileName, out string contentType))
            {
                contentType = "message/rfc822";
            }
            return contentType;
        }

        private static readonly string[] VietnameseSigns = new string[]
       {
            "aAeEoOuUiIdDyY",

            "áàạảãâấầậẩẫăắằặẳẵ",

            "ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",

            "éèẹẻẽêếềệểễ",

            "ÉÈẸẺẼÊẾỀỆỂỄ",

            "óòọỏõôốồộổỗơớờợởỡ",

            "ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",

            "úùụủũưứừựửữ",

            "ÚÙỤỦŨƯỨỪỰỬỮ",

            "íìịỉĩ",

            "ÍÌỊỈĨ",

            "đ",

            "Đ",

            "ýỳỵỷỹ",

            "ÝỲỴỶỸ"
       };

        public static string RandomPassword(int length)
        {
            var chars = "abcdefghijklmnopqrstuvwxyz!@#$%^&*ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            var stringChars = new char[length];
            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }
            string finalString = new(stringChars);

            return $"{finalString}{DateTime.Now:yyyy}";
        }

        public static string RandomTicketPreCode(int length)
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            var stringChars = new char[length];
            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }
            return new(stringChars);
        }

        public static string RemoveSign4VietnameseString(this string str)
        {
            for (int i = 1; i < VietnameseSigns.Length; i++)
            {
                for (int j = 0; j < VietnameseSigns[i].Length; j++)
                    str = str.Replace(VietnameseSigns[i][j], VietnameseSigns[0][i - 1]);
            }
            return str;
        }

        public static string RandomColor()
        {
            List<string> colors = new()
            {
                "bg-brown-400",
                "bg-dark-alpha",
                "bg-grey-300",
                "bg-slate-600",
                "bg-indigo-400",
                "bg-purple",
                "bg-pink",
                "bg-success-700",
                "bg-orange",
                "bg-orange",
                "bg-green",
                "bg-teal",
                "bg-dark",
                "bg-blue",
                "bg-indigo",
                "bg-purple",
                "bg-pink",
                "bg-success-700"
            };

            Random r = new();
            int index = r.Next(colors.Count);
            return colors[index];
        }

        public static string RandomBorderColor()
        {
            List<string> colors = new()
            {
                "border-green",
                "border-teal",
                "border-pink",
                "border-blue",
                "border-indigo",
                "border-purple",
                "border-pink",
                "border-red",
                "border-orange",
                "border-yellow",
                "border-green",
                "border-teal",
                "border-cyan",
                "border-blue",
                "border-indigo",
                "border-purple",
                "border-pink",
                "border-red"
            };

            Random r = new();
            int index = r.Next(colors.Count);
            return colors[index];
        }

        public static IEnumerable<List<T>> SplitList<T>(List<T> locations, int nSize = 30)
        {
            for (int i = 0; i < locations.Count; i += nSize)
            {
                yield return locations.GetRange(i, Math.Min(nSize, locations.Count - i));
            }
        }

        /// <summary>
        /// Lấy extension file theo đường dẫn
        /// </summary>
        /// <param name="attachFileName"></param>
        /// <returns></returns>
        public static string GetExtenFileAttachByPath(string attachFileName)
        {
            FileInfo fi = new(attachFileName);
            return fi.Extension;
        }
        /// <summary>
        /// Kiểm tra định dạng email
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        public static string GetNameOfEmail(string email)
        {
            if (string.IsNullOrEmpty(email)) return "";
            string[] arrEmail = email.Split('@');
            if (arrEmail != null && arrEmail.Length > 1)
            {
                return arrEmail[0];
            }
            return email;
        }

        /// <summary>
        /// Gửi email
        /// </summary>
        /// <param name="SSL"></param>
        /// <param name="email"></param>
        /// <param name="emailPasss"></param>
        /// <param name="host"></param>
        /// <param name="port"></param>
        /// <param name="emailTo"></param>
        /// <param name="subject"></param>
        /// <param name="content"></param>
        /// <param name="sendMailMessage"></param>
        /// <param name="nameOfEmail"></param>
        /// <param name="nameOfToEmail"></param>
        /// <returns></returns>
        public static bool SendMail(bool SSL, string email, string emailPasss, string host, int port, string emailTo,
            string subject, string content, out string sendMailMessage,
            string nameOfEmail = "", string nameOfToEmail = "", string attachmentFilename = "")
        {
            sendMailMessage = string.Empty;
            try
            {

                var fromAddress = new MailAddress(email, nameOfEmail);
                var toAddress = new MailAddress(emailTo, nameOfToEmail);
                string fromPassword = emailPasss;


                //string userEmail = GetNameOfEmail(email);
                string userEmail = email;

                var smtp = new SmtpClient
                {
                    Host = host,
                    Port = port,
                    EnableSsl = SSL,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(userEmail, fromPassword)
                };

                var message = new MailMessage(fromAddress, toAddress)
                {
                    Subject = subject,
                    Body = content,
                    IsBodyHtml = true,
                };
                if (!string.IsNullOrEmpty(attachmentFilename))
                    message.Attachments.Add(new Attachment(attachmentFilename));

                {
                    //ServicePointManager.ServerCertificateValidationCallback =
                    //    delegate (object s, X509Certificate certificate, X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
                    //    {
                    //        return true;
                    //    };
                    smtp.Send(message);
                }
                return true;

            }
            catch (Exception ex)
            {
                sendMailMessage = ex.Message;
                return false;
            }
        }

        /// <summary>
        /// Lấy số tuần hiện tại trong năm
        /// </summary>
        /// <returns></returns>
        public static int GetIso8601WeekOfYear()
        {
            DateTime time = DateTime.Now;
            // Seriously cheat.  If its Monday, Tuesday or Wednesday, then it'll 
            // be the same week# as whatever Thursday, Friday or Saturday are,
            // and we always get those right
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(time);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                time = time.AddDays(3);
            }

            // Return the week of our adjusted day
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(time, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

        public static string Decrypt(string cipherString, string key = "v9group2022", bool useHashing = true)
        {
            if (string.IsNullOrEmpty(cipherString)) return string.Empty;
            byte[] keyArray;
            byte[] toEncryptArray = Convert.FromBase64String(cipherString);
            if (useHashing)
            {
                //if hashing was used get the hash code with regards to your key
                var hashmd5 = MD5.Create();
                keyArray = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(key));
                //release any resource held by the MD5CryptoServiceProvider
                hashmd5.Clear();
            }
            else
            {
                //if hashing was not implemented get the byte code of the key
                keyArray = Encoding.UTF8.GetBytes(key);
            }

            using var tdes = TripleDES.Create();
            //set the secret key for the tripleDES algorithm
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            //padding mode(if any extra byte added)
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(
                                 toEncryptArray, 0, toEncryptArray.Length);
            //Release resources held by TripleDes Encryptor                
            tdes.Clear();
            //return the Clear decrypted TEXT
            return Encoding.UTF8.GetString(resultArray);
        }
        public static string Encrypt(string toEncrypt, string key = "v9group2022", bool useHashing = true)
        {
            if (string.IsNullOrEmpty(toEncrypt)) toEncrypt = "";
            byte[] keyArray;
            byte[] toEncryptArray = Encoding.UTF8.GetBytes(toEncrypt);

            //If hashing use get hashcode regards to your key
            if (useHashing)
            {
                var hashmd5 = MD5.Create();
                keyArray = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = Encoding.UTF8.GetBytes(key);

            var tdes = TripleDES.Create();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray =
              cTransform.TransformFinalBlock(toEncryptArray, 0,
              toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        private static readonly IDictionary<Type, ICollection<PropertyInfo>> _Properties =
        new Dictionary<Type, ICollection<PropertyInfo>>();

        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T));
            var table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
            }
            return table;
        }

        /// <summary>
        /// Converts a DataTable to a list with generic objects
        /// </summary>
        /// <typeparam name="T">Generic object</typeparam>
        /// <param name="table">DataTable</param>
        /// <returns>List with generic objects</returns>
        public static IEnumerable<T> DataTableToList<T>(this DataTable table) where T : class, new()
        {
            try
            {
                var objType = typeof(T);
                ICollection<PropertyInfo> properties;

                lock (_Properties)
                {
                    if (!_Properties.TryGetValue(objType, out properties))
                    {
                        properties = objType.GetProperties().Where(property => property.CanWrite).ToList();
                        _Properties.Add(objType, properties);
                    }
                }

                var list = new List<T>(table.Rows.Count);

                //foreach (var row in table.AsEnumerable().Skip(1))
                foreach (var row in table.AsEnumerable())
                {
                    var obj = new T();

                    foreach (var prop in properties)
                    {
                        try
                        {
                            var propType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                            var safeValue = row[prop.Name] == null ? null : Convert.ChangeType(row[prop.Name], propType);

                            prop.SetValue(obj, safeValue, null);
                        }
                        catch
                        {
                            continue;
                        }
                    }

                    list.Add(obj);
                }

                return list;
            }
            catch
            {
                return Enumerable.Empty<T>();
            }
        }

        public static bool IsDateTime(string txtDate, out DateTime tempDate)
        {
            return DateTime.TryParseExact(txtDate, "dd-MM-yyyy HH:mm:ss", CultureInfo.CurrentCulture, DateTimeStyles.None, out tempDate);
        }


        /// <summary>
        /// Joins the passed in DataTables on the colToJoinOn.
        /// <para>Returns an appropriate DataTable with zero rows if the colToJoinOn does not exist in both tables.</para>
        /// </summary>
        /// <param name="dtblLeft"></param>
        /// <param name="dtblRight"></param>
        /// <param name="colToJoinOn"></param>
        /// <param name="joinType"></param>
        /// <returns></returns>
        /// <remarks>
        /// <para>http://stackoverflow.com/questions/2379747/create-combined-datatable-from-two-datatables-joined-with-linq-c-sharp?rq=1</para>
        /// <para>http://msdn.microsoft.com/en-us/library/vstudio/bb397895.aspx</para>
        /// <para>http://www.codinghorror.com/blog/2007/10/a-visual-explanation-of-sql-joins.html</para>
        /// <para>http://stackoverflow.com/questions/406294/left-join-and-left-outer-join-in-sql-server</para>
        /// </remarks>
        public static DataTable JoinTwoDataTablesOnOneColumn(DataTable dtblLeft, DataTable dtblRight, string colToJoinOn, JoinType joinType)
        {
            //Change column name to a temp name so the LINQ for getting row data will work properly.
            string strTempColName = colToJoinOn + "_2";
            if (dtblRight.Columns.Contains(colToJoinOn))
                dtblRight.Columns[colToJoinOn].ColumnName = strTempColName;

            //Get columns from dtblLeft
            DataTable dtblResult = dtblLeft.Clone();

            //Get columns from dtblRight
            var dt2Columns = dtblRight.Columns.OfType<DataColumn>().Select(dc => new DataColumn(dc.ColumnName, dc.DataType, dc.Expression, dc.ColumnMapping));

            //Get columns from dtblRight that are not in dtblLeft
            var dt2FinalColumns = from dc in dt2Columns.AsEnumerable()
                                  where !dtblResult.Columns.Contains(dc.ColumnName)
                                  select dc;

            //Add the rest of the columns to dtblResult
            dtblResult.Columns.AddRange(dt2FinalColumns.ToArray());

            //No reason to continue if the colToJoinOn does not exist in both DataTables.
            if (!dtblLeft.Columns.Contains(colToJoinOn) || (!dtblRight.Columns.Contains(colToJoinOn) && !dtblRight.Columns.Contains(strTempColName)))
            {
                if (!dtblResult.Columns.Contains(colToJoinOn))
                    dtblResult.Columns.Add(colToJoinOn);
                return dtblResult;
            }

            switch (joinType)
            {

                default:
                case JoinType.Inner:
                    #region Inner
                    //get row data
                    //To use the DataTable.AsEnumerable() extension method you need to add a reference to the System.Data.DataSetExtension assembly in your project. 
                    var rowDataLeftInner = from rowLeft in dtblLeft.AsEnumerable()
                                           join rowRight in dtblRight.AsEnumerable() on rowLeft[colToJoinOn] equals rowRight[strTempColName]
                                           select rowLeft.ItemArray.Concat(rowRight.ItemArray).ToArray();


                    //Add row data to dtblResult
                    foreach (object[] values in rowDataLeftInner)
                        dtblResult.Rows.Add(values);

                    #endregion
                    break;
                case JoinType.Left:
                    #region Left
                    var rowDataLeftOuter = from rowLeft in dtblLeft.AsEnumerable()
                                           join rowRight in dtblRight.AsEnumerable() on rowLeft[colToJoinOn] equals rowRight[strTempColName] into gj
                                           from subRight in gj.DefaultIfEmpty()
                                           select rowLeft.ItemArray.Concat((subRight == null) ? (dtblRight.NewRow().ItemArray) : subRight.ItemArray).ToArray();


                    //Add row data to dtblResult
                    foreach (object[] values in rowDataLeftOuter)
                        dtblResult.Rows.Add(values);

                    #endregion
                    break;
            }

            //Change column name back to original
            dtblRight.Columns[strTempColName].ColumnName = colToJoinOn;

            //Remove extra column from result
            dtblResult.Columns.Remove(strTempColName);

            return dtblResult;
        }


        public static string GetRamdomCode(int number)
        {
            var code = string.Empty;
            Random random = new();
            for (int i = 0; i < number; i++)
            {
                //code += Convert.ToString(random.Next(1, 20), "000000");
                code += random.Next(1, 99).ToString("00");
            }
            return code;
        }

        public static bool HasValue(this double value)
        {
            return !Double.IsNaN(value) && !Double.IsInfinity(value);
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            var dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToLocalTime();
            return dtDateTime;
        }

        public static DateTime? StringUnixTimeStampToDateTime(string unixTimeStamp)
        {
            if (double.TryParse(unixTimeStamp, out double myValue))
            {
                // Unix timestamp is seconds past epoch
                var dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                dtDateTime = dtDateTime.AddSeconds(myValue).ToLocalTime();
                return dtDateTime;
            }
            return null;

        }
    }



}
