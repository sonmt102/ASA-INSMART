﻿namespace CTS.Common
{
    public static class SignalEventConst
    {
        #region VOC
        /// <summary>
        /// Cảnh báo VOC mới tiếp nhận
        /// </summary>
        public const string VOC_MoiTiepNhan = "VOC_MoiTiepNhan";
        /// <summary>
        /// Cảnh báo VOC Sắp đến hạn
        /// </summary>
        public const string VOC_SapDenHan = "VOC_SapDenHan";
        /// <summary>
        /// Cảnh báo VOC Đã đến hạn
        /// </summary>
        public const string VOC_DaDenHan = "VOC_SapDenHan";
        /// <summary>
        /// Cảnh báo lịch hẹn VOC
        /// </summary>
        public const string VOC_LichHen = "VOC_LichHen";
        /// <summary>
        /// Load lại lưới ticket
        /// </summary>
        public const string VOC_ReloadListTicket = "VOC_ReloadListTicket";

        #endregion


        #region VOICE

        #region - AGENT
        /// <summary>
        /// Thông báo đến số nội bộ đang đổ chuông
        /// </summary>
        public const string Agent_Ringing = "Agent_Ringing";
        /// <summary>
        /// Thông báo đến số nội bộ đang có cuộc gọi
        /// </summary>
        public const string Agent_InCall = "Agent_InCall";
        /// <summary>
        /// Thông báo đến số nội bộ đang có cuộc gọi với TH sử dụng module ticket
        /// </summary>
        public const string Agent_InCall_Ticket = "Agent_InCall_Ticket";
        /// <summary>
        /// Thông báo đến số nội bộ kết thúc cuộc gọi
        /// </summary>
        public const string Agent_HangUp = "Agent_HangUp";
        /// <summary>
        /// Thông báo đến agent có cuộc gọi nhỡ
        /// </summary>
        public const string Agent_MissCall = "Agent_MissCall";
        /// <summary>
        /// Thông báo đến lịch hẹn cuộc gọi
        /// </summary>
        public const string Agent_CallCalendar = "Agent_CallCalendar";
        /// <summary>
        /// Thông báo đến agent, SUP rời nhóm của agent
        /// </summary>
        public const string Agent_SUPRemoveQueue = "Agent_SUPRemoveQueue";
        /// <summary>
        /// Thông báo đến agent, SUP thay đổi trạng thái trong queue của agent
        /// </summary>
        public const string Agent_SUPChangeStatusAgentInQueue = "Agent_SUPChangeStatusAgentInQueue";
        public const string HANGUP_CALL = "HANGUP_CALL";


        #endregion



        #region - SUPERVISOR
        /// <summary>
        /// Dữ liệu hiển thị trên box IVR màn hình SUP
        /// </summary>
        public const string CALL_REALTIME = "CALL_REALTIME";
        /// <summary>
        /// Dữ liệu hiển thị trên box IVR màn hình SUP
        /// </summary>
        public const string SUP_BOX_IVR = "SUP_BOX_IVR";
        /// <summary>
        /// Thông tin tất cả box màn hình SUP
        /// </summary>
        public const string SUP_BOX = "SUP_BOX";
        /// <summary>
        /// Thông tin 2 box gọi nhỡ, gọi rớt
        /// </summary>
        public const string SUP_BOX_MISSCALL = "SUP_BOX_MISSCALL";
        /// <summary>
        /// Thông tin dữ liệu cho realtime chart
        /// </summary>
        public const string SUP_REALTIME_CHART = "SUP_REALTIME_CHART";
        /// <summary>
        /// Thay đổi thông tin trên lưới nhóm cuộc gọi
        /// </summary>
        public const string SUP_QUEUE_ChangeData = "SUP_Queue_ChangeData";
        /// <summary>
        /// Thay đổi thông tin trên lưới khi agent có cuộc gọi trong queue
        /// </summary>
        public const string SUP_AGENT_CallInQueue = "SUP_AGENT_CallInQueue";
        /// <summary>
        /// Thay đổi thông tin trên lưới khi agent có cuộc gọi không trong queue
        /// </summary>
        public const string SUP_AGENT_Call = "SUP_AGENT_Call";
        /// <summary>
        /// Thay đổi thông tin trên lưới khi agent kết thúc cuộc gọi
        /// </summary>
        public const string SUP_AGENT_HangUp = "SUP_AGENT_HangUp";
        /// <summary>
        /// Thông báo đến màn hình agent của sup có agent offline
        /// </summary>
        public const string SUP_AGENT_AgentLogout = "SUP_AGENT_AgentLogout";
        /// <summary>
        /// Thông báo đến màn hình agent của sup có agent online
        /// </summary>
        public const string SUP_AGENT_AgentLogin = "SUP_AGENT_AgentLogin";
        /// <summary>
        /// Thông báo đến màn hình agent của sup có agent vào nhóm
        /// </summary>
        public const string SUP_AGENT_AgentJoinQueue = "SUP_AGENT_AgentJoinQueue";
        /// <summary>
        /// Thông báo đến màn hình agent của sup có agent rời nhóm
        /// </summary>
        public const string SUP_AGENT_AgentLeaveQueue = "SUP_AGENT_AgentLeaveQueue";
        /// <summary>
        /// Thông báo đến màn hình agent của SUP thông tin có agent thay đổi trạng thái
        /// Change 1 queue hay nhiều queue cũng chỉ bắn 1 lần
        /// </summary>
        public const string SUP_AGENT_AgentChangeStatus = "SUP_AGENT_AgentChangeStatus";
        /// <summary>
        /// Thông báo đến màn hình queue của sup có agent online và tham gia queue
        /// </summary>
        public const string SUP_QUEUE_AgentLogin = "SUP_QUEUE_AgentLogin";
        /// <summary>
        /// TH: tạo mới queue thì bắn cho màn hình queue của SUP
        /// </summary>
        public const string SUP_QUEUE_QueueAdd = "SUP_QUEUE_QueueAdd";
        /// <summary>
        /// TH: tạo mới queue thì bắn cho màn hình queue của SUP, select queue
        /// </summary>
        public const string SUP_QUEUE_QueueAdd_Select = "SUP_QUEUE_QueueAdd_Select";
        /// <summary>
        /// TH: sửa queue thì bắn cho màn hình queue của SUP, select queue
        /// </summary>
        public const string SUP_QUEUE_QueueUpdate_Select = "SUP_QUEUE_QueueUpdate_Select";
        /// <summary>
        /// TH: xóa queue thì bắn cho màn hình queue của SUP
        /// </summary>
        public const string SUP_QUEUE_QueueDelete = "SUP_QUEUE_QueueDelete";


        #endregion

        #endregion
    }
}
