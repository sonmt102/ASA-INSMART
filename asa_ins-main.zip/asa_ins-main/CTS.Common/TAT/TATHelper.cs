﻿namespace CTS.Common.TAT
{
    public static class TATHelper
    {
        public static List<DateOnly> GetExceptedDate()
        {
            return new List<DateOnly>()
            {
                new (2024, 1, 1),//Tết dương
                //Nghỉ tết âm 2024
                new (2024, 2, 8),
                new (2024, 2, 9),
                new (2024, 2, 10),
                new (2024, 2, 11),
                new (2024, 2, 12),
                new (2024, 2, 13),
                new (2024, 2, 14)
                //End: Nghỉ tết âm 2024
            };
        }


        public static bool GetTATMinute(DateTime from, DateTime toDate, int time)
        {
            var excepted = GetExceptedDate();
            var myResult = true;
            var h = (toDate - from).TotalMinutes;

            var myMinutes = 0;
            for (double i = 1; i <= h; i++)
            {
                //var myDate = new DateTime(from.Year, from.Month, from.Day, from.Hour, 0, 0).AddHours(i);
                var myDate = from.AddMinutes(i);
                if (!excepted.Contains(DateOnly.FromDateTime(myDate))
                    && myDate.DayOfWeek != DayOfWeek.Sunday && myDate.DayOfWeek != DayOfWeek.Saturday)
                {
                    if (myDate.Hour >= 8 && myDate.Hour <= 12)
                    {
                        switch (myDate.Hour)
                        {
                            case 8:
                                if (myDate.Minute >= 1) myMinutes += 1;
                                break;
                            case 12:
                                if (myDate.Minute == 0) myMinutes += 1;
                                break;
                            default:
                                myMinutes += 1;
                                break;
                        }
                    }
                    if (myDate.Hour >= 13 && myDate.Hour <= 17)
                    {
                        switch (myDate.Hour)
                        {
                            case 13:
                                if (myDate.Minute > 30) myMinutes += 1;
                                break;
                            case 17:
                                if (myDate.Minute <= 30) myMinutes += 1;
                                break;
                            default:
                                myMinutes += 1;
                                break;
                        }
                    }
                    if (myMinutes > time)
                    {
                        myResult = false;
                        break;
                    }
                }

            }
            return myResult;
        }

        public static bool GetTATMinute(DateTime from, DateTime toDate, int time, out int totalMinutes)
        {
            var excepted = GetExceptedDate();
            var myResult = true;
            var h = (toDate - from).TotalMinutes;

            totalMinutes = 0;
            for (double i = 1; i <= h; i++)
            {
                var myDate = from.AddMinutes(i);
                if (!excepted.Contains(DateOnly.FromDateTime(myDate))
                    && myDate.DayOfWeek != DayOfWeek.Sunday && myDate.DayOfWeek != DayOfWeek.Saturday)
                {
                    if (myDate.Hour >= 8 && myDate.Hour <= 12)
                    {
                        if (myDate.Hour != 12 && myDate.Minute != 0)
                            totalMinutes += 1;
                    }
                    if (myDate.Hour >= 13 && myDate.Hour <= 17)
                    {
                        switch (myDate.Hour)
                        {
                            case 13:
                                if (myDate.Minute > 30) totalMinutes += 1;
                                break;
                            case 17:
                                if (myDate.Minute <= 30) totalMinutes += 1;
                                break;
                            default:
                                totalMinutes += 1;
                                break;
                        }
                    }
                    if (totalMinutes > time)
                    {
                        myResult = false;
                    }
                }

            }
            return myResult;
        }

        public static DateTime GetInTimeTAT(DateTime from, int time)
        {
            var excepted = GetExceptedDate();
            var myResult = DateTime.Now;
            var myMinutes = 0;
            for (double i = 1; i <= 20000; i++)
            {
                //var myDate = new DateTime(from.Year, from.Month, from.Day, from.Hour, 0, 0).AddHours(i);
                var myDate = from.AddMinutes(i);
                if (!excepted.Contains(DateOnly.FromDateTime(myDate))
                    && myDate.DayOfWeek != DayOfWeek.Sunday && myDate.DayOfWeek != DayOfWeek.Saturday)
                {
                    if (myDate.Hour >= 8 && myDate.Hour <= 12)
                    {
                        switch (myDate.Hour)
                        {
                            case 8:
                                if (myDate.Minute >= 1) myMinutes += 1;
                                break;
                            case 12:
                                if (myDate.Minute == 0) myMinutes += 1;
                                break;
                            default:
                                myMinutes += 1;
                                break;
                        }
                        //if (myDate.Hour != 12 && myDate.Minute != 0)
                        //    myMinutes += 1;
                    }
                    if (myDate.Hour >= 13 && myDate.Hour <= 17)
                    {
                        switch (myDate.Hour)
                        {
                            case 13:
                                if (myDate.Minute > 30) myMinutes += 1;
                                break;
                            case 17:
                                if (myDate.Minute <= 30) myMinutes += 1;
                                break;
                            default:
                                myMinutes += 1;
                                break;
                        }
                    }
                    if (myMinutes == time)
                    {
                        myResult = myDate;
                        break;
                    }
                }

            }
            return myResult;
        }

        /// <summary>
        /// Tổng thời gian phản hồi
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public static int GetTATTotal(DateTime from, DateTime to)
        {
            var excepted = GetExceptedDate();
            var minutes = (to - from).TotalMinutes;
            var myMinutes = 0;
            for (double i = 1; i <= minutes; i++)
            {
                //var myDate = new DateTime(from.Year, from.Month, from.Day, from.Hour, 0, 0).AddHours(i);
                var myDate = from.AddMinutes(i);
                if (!excepted.Contains(DateOnly.FromDateTime(myDate))
                    && myDate.DayOfWeek != DayOfWeek.Sunday && myDate.DayOfWeek != DayOfWeek.Saturday)
                {
                    if (myDate.Hour >= 8 && myDate.Hour <= 12)
                    {
                        switch (myDate.Hour)
                        {
                            case 8:
                                if (myDate.Minute >= 1) myMinutes += 1;
                                break;
                            case 12:
                                if (myDate.Minute == 0) myMinutes += 1;
                                break;
                            default:
                                myMinutes += 1;
                                break;
                        }
                    }
                    if (myDate.Hour >= 13 && myDate.Hour <= 17)
                    {
                        switch (myDate.Hour)
                        {
                            case 13:
                                if (myDate.Minute > 30) myMinutes += 1;
                                break;
                            case 17:
                                if (myDate.Minute <= 30) myMinutes += 1;
                                break;
                            default:
                                myMinutes += 1;
                                break;
                        }
                    }
                }

            }
            return myMinutes;
        }

        public static TimeResultModel GetTATTimeToCounter(TATModel item)
        {
            switch (item.LoaiSuVu)
            {
                case TATLoaiSuVuConst.TuVan:
                    {
                        switch (item.LoaiYeuCau)
                        {
                            case TATLoaiYeuCauConst.DV_BaoLanhVienPhi:
                                {
                                    switch (item.YeuCau)
                                    {
                                        case TATYeuCauConst.YC_HoTroBLVPKhongThe:
                                            {
                                                if (item.IsCallOrEmail)
                                                {
                                                    var result = SwitchTime_YC_HoTroBLVPKhongThe(item.CongTy);
                                                    if (result != null) return result;
                                                }
                                            }
                                            break;
                                        case TATYeuCauConst.ThacMacKetQuaBLVP:
                                            {
                                                if (item.IsCall && item.CongTy == TATCompanyConst.Nhan_Manulife)
                                                    return new TimeResultModel(4 * 60, 2 * 60);
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                break;
                            case TATLoaiYeuCauConst.DV_GiaiQuyeHSBoiThuong:
                                {
                                    switch (item.YeuCau)
                                    {
                                        case TATYeuCauConst.ThacMacKQGiaiQuyetBoiThuong:
                                            {
                                                if (item.IsCall && item.CongTy == TATCompanyConst.Nhan_Manulife)
                                                    return new TimeResultModel(4 * 60, 2 * 60);
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    break;
                case TATLoaiSuVuConst.KhieuNai:
                    {
                        if (item.IsCallOrEmail)
                        {
                            switch (item.LoaiYeuCau)
                            {
                                case TATLoaiYeuCauConst.BaoLanhVienPhi:
                                    {
                                        switch (item.YeuCau)
                                        {
                                            case TATYeuCauConst.CSYT_KhongNhanTheBH:
                                                {
                                                    var result = SwitchTime_YC_HoTroBLVPKhongThe(item.CongTy);
                                                    if (result != null) return result;
                                                }
                                                break;
                                            default:
                                                break;
                                        }
                                    }
                                    break;
                                default:
                                    break;
                            }



                            //Kiểm tra loại khiếu nại
                            {
                                //Kiểm tra loại khiếu nại
                                var result = GetKN_ComplaintTATTimeResult(item.LoaiKhieuNai);
                                if (result != null) return result;
                                //Kiểm tra của phi
                                if (TATCompanyConst.PhiNhanThoGroup.Contains(item.CongTy))
                                    return new TimeResultModel(16 * 60, 8 * 60);
                            }


                        }
                    }
                    break;
                default:
                    break;
            }

            return new TimeResultModel(8 * 60, 4 * 60);
        }

        public static TimeResultModel? GetKN_ComplaintTATTimeResult(string complaint)
        {
            if (string.IsNullOrEmpty(complaint)) return null;
            return complaint switch
            {
                TATLoaiKhieuNaiConst.MinorComplaint => new TimeResultModel(16 * 60, 8 * 60),
                TATLoaiKhieuNaiConst.MajorComplaint => new TimeResultModel(24 * 60, 12 * 60),
                _ => null,
            };
        }

        public static TimeResultModel? SwitchTime_YC_HoTroBLVPKhongThe(string com)
        {
            return com switch
            {
                TATCompanyConst.Nhan_Manulife => new TimeResultModel(15, 7),

                TATCompanyConst.Nhan_PVA => new TimeResultModel(30, 15),
                TATCompanyConst.Nhan_AIA => new TimeResultModel(30, 15),
                TATCompanyConst.Nhan_Hanwalife => new TimeResultModel(30, 15),
                TATCompanyConst.Nhan_Sunlife => new TimeResultModel(30, 15),
                TATCompanyConst.Nhan_FWD => new TimeResultModel(30, 15),

                TATCompanyConst.Phi_ABIC => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_AXA => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_BaoLong => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_BaoMinh => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_Fubon => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_HangKhong => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_HDI => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_HoanMy => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_MarineBenefits => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_MIC => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_MSIG => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_PhuHung => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_PJICO => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_PTI => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_SaiGon_HaNoi => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_ToanCau => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_Tokio_Marine => new TimeResultModel(60, 30),
                TATCompanyConst.Phi_UIC => new TimeResultModel(60, 30),
                _ => null
            };
        }
    }

    public class TATModel
    {
        public string? KenhTiepNhan { get; set; }
        public string? CongTy { get; set; }
        public string? LoaiSuVu { get; set; }
        public string? LoaiYeuCau { get; set; }
        public string? YeuCau { get; set; }
        public string? LoaiKhieuNai { get; set; }

        protected List<string> Kenh_CallAndEmail
        {
            get => new()
            {
                TATKenhTiepNhanConst.GoiDen,
                TATKenhTiepNhanConst.GoiDi,
                TATKenhTiepNhanConst.MissCall,
                TATKenhTiepNhanConst.Email_NhanTho,
                TATKenhTiepNhanConst.Email_PhiNhanTho,
                TATKenhTiepNhanConst.Email_Helpdesk,
                TATKenhTiepNhanConst.Email_MBAL
            };
        }

        protected List<string> Kenh_Email
        {
            get => new()
            {
                TATKenhTiepNhanConst.Email_NhanTho,
                TATKenhTiepNhanConst.Email_PhiNhanTho,
                TATKenhTiepNhanConst.Email_Helpdesk,
                TATKenhTiepNhanConst.Email_MBAL
            };
        }

        public bool IsCallOrEmail
        {
            get => Kenh_CallAndEmail.Contains(KenhTiepNhan);
        }

        public bool IsCall
        {
            get => KenhTiepNhan == TATKenhTiepNhanConst.GoiDen || KenhTiepNhan == TATKenhTiepNhanConst.GoiDi
                || KenhTiepNhan == TATKenhTiepNhanConst.MissCall;
        }

    }

    public class TimeResultModel
    {
        public TimeResultModel(int cs, int op)
        {
            CS = cs;
            OP = op;
        }
        public int CS { get; set; }
        public int OP { get; set; }
    }
}
