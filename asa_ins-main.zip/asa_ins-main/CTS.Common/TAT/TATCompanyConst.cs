﻿namespace CTS.Common.TAT
{
    public static class TATCompanyConst
    {
        public const string Nhan_Manulife = "M";
        public const string Nhan_PVA = "P2";
        public const string Nhan_AIA = "A01";
        public const string Nhan_Hanwalife = "HL";
        public const string Nhan_Sunlife = "S01";
        public const string Nhan_FWD = "F";

        public static readonly List<string> SpecicalGroup1 = new() { Nhan_PVA, Nhan_AIA, Nhan_Hanwalife, Nhan_Sunlife, Nhan_FWD };


        public const string Phi_ABIC = "ef9971db-a0ae-4d66-a591-7a1e52f72eab";
        public const string Phi_AXA = "A03";
        public const string Phi_BaoLong = "BL";
        public const string Phi_BaoMinh = "BM";
        public const string Phi_Fubon = "F1";
        public const string Phi_HangKhong = "HK";
        public const string Phi_HDI = "H03";
        public const string Phi_HoanMy = "236573df-888f-40ad-a326-a42723993e51";
        public const string Phi_MarineBenefits = "MB";
        public const string Phi_MIC = "M2";
        public const string Phi_MSIG = "M3";
        public const string Phi_PhuHung = "PH";
        public const string Phi_PJICO = "P";
        public const string Phi_PTI = "P1";
        public const string Phi_SaiGon_HaNoi = "SG";
        public const string Phi_ToanCau = "TC";
        public const string Phi_Tokio_Marine = "B";
        public const string Phi_UIC = "U";

        public static readonly List<string> PhiNhanThoGroup = new() { Phi_ABIC, Phi_AXA, Phi_BaoLong, Phi_BaoMinh,
            Phi_Fubon, Phi_HangKhong, Phi_HDI, Phi_HoanMy, Phi_MarineBenefits, Phi_MIC, Phi_MSIG, Phi_PhuHung,
            Phi_PJICO, Phi_PTI, Phi_SaiGon_HaNoi, Phi_ToanCau, Phi_Tokio_Marine, Phi_UIC };
    }

    public static class TATKenhTiepNhanConst
    {
        public const string GoiDen = "KTN002";
        public const string GoiDi = "KTN003";
        public const string MissCall = "MIS";


        public const string Email_NhanTho = "KTN004";
        public const string Email_PhiNhanTho = "KTN007";
        public const string Email_Helpdesk = "KTN_Email_HD";
        public const string Email_MBAL = "Email_MBAL";

        public static readonly List<string> KenhEmails = new() { Email_NhanTho, Email_PhiNhanTho, Email_Helpdesk, Email_MBAL };
    }



    public static class TATLoaiSuVuConst
    {
        /// <summary>
        /// Tư vấn
        /// </summary>
        public const string TuVan = "Tv20";
        /// <summary>
        /// Khiếu nại
        /// </summary>
        public const string KhieuNai = "Kn23";
    }

    public static class TATLoaiYeuCauConst
    {
        /// <summary>
        /// Dịch vụ Bảo lãnh viện phí
        /// </summary>
        public const string DV_BaoLanhVienPhi = "Dvblv18";
        /// <summary>
        /// Bảo lãnh viện phí
        /// </summary>
        public const string BaoLanhVienPhi = "Dvblv19";
        /// <summary>
        /// Dịch vụ Giải quyết hồ sơ bồi thường
        /// </summary>
        public const string DV_GiaiQuyeHSBoiThuong = "Dvgqh07";
    }

    public static class TATYeuCauConst
    {
        /// <summary>
        /// Yêu cầu hỗ trợ BLVP không thẻ
        /// </summary>
        public const string YC_HoTroBLVPKhongThe = "tv-dvblvp-yckhongthe";
        /// <summary>
        /// Thắc mắc kết quả BLVP
        /// </summary>
        public const string ThacMacKetQuaBLVP = "Tmkqg04";
        /// <summary>
        /// CSYT không nhận diện thẻ BH
        /// </summary>
        public const string CSYT_KhongNhanTheBH = "KN_BLVP_KhongNhanDien";
        /// <summary>
        /// Thắc mắc kết quả giải quyết bồi thường
        /// </summary>
        public const string ThacMacKQGiaiQuyetBoiThuong = "Tmkqg05";
    }

    public static class TATLoaiKhieuNaiConst
    {
        public const string MinorComplaint = "NormalComplaint";
        public const string MajorComplaint = "HotComplaint";
    }
}
