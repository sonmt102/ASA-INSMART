﻿namespace CTS.Common
{
    public static class CategoryConst
    {
        /// <summary>
        /// Kênh tiếp nhận
        /// </summary>
        public const string VOC_KenhTiepNhan = "VOC-KenhTiepNhan";
        /// <summary>
        /// Đối tượng gọi đến
        /// </summary>
        public const string VOC_DoiTuongGoiDen = "VOC-DoiTuongGoiDen";

        #region TTSV
        public const string VOC_CongTy = "VOC-CongTy";
        public const string VOC_CongTyMoiGioi = "MoiGioi";
        public const string VOC_LoaiSuVu = "A01";
        public const string VOC_LoaiKhieuNai = "VOC-LoaiKhieuNai";
        public static List<string> VOC_LoaiYeuCau = new() { "Kn23", "Tv20", "ttchung" };
        public static List<string> VOC_YeuCau = new() { "Dvblv19", "Dvgqh08", "Spvdv17", "ttchung", "Dvblv18", "Dvctt05", "Dvgt22", "Dvgqh07", "Dvtvt05", "Mc09", "Spvdv15" };
        public const string VOC_LoaiHoSo = "VOC-LoaiHoSo";
        public const string VOC_BoPhanThuLy = "VOC-BoPhanThuLy";
        public const string VOC_DonViTiepNhan = "VOC-DonViTiepNhan";
        public const string VOC_NguyenNhan = "VOC_NguyenNhan";
        #endregion
        #region QTXL
        public const string VOC_PhuongAnGiaiQuyet = "VOC-PhuongAnGiaiQuyet";
        public const string VOC_PhoiHopGQKN = "VOC-PhoiHopGQKN";
        public const string VOC_OPPhanHoiPA = "VOC-OPPhanHoiPA";
        public const string VOC_CSPhanHoiTTKH = "VOC-CSPhanHoiTTKH";
        #endregion
        /// <summary>
        /// Phòng bảo lãnh viện phí
        /// </summary>
        public const string VOC_BoPhanThuLy_BLVP = "VBPTL-07";

        public const string EmailNhanTho = "chamsockhachhang";
        public const string EmailPhiNhanTho = "giaidapthacmachn";
        public const string EmailHelpdesk = "helpdesk";
        public const string EmailDVKH_MBAL = "dvkhmbal";

    }



}
