﻿namespace CTS.Common
{
    public static class Mail_Tag_Const
    {
        public const string Tag_Check = "check";
        public const string Tag_Important = "important";
        public const string Tag_Reply = "reply";
    }
}
