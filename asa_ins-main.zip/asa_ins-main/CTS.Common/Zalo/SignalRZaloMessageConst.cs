﻿namespace CTS.Common.Zalo
{
    public static class SignalRZaloMessageConst
    {
        /// <summary>
        /// Có tin nhắn mới
        /// </summary>
        public const string New_Message = "z_new_message";
        /// <summary>
        /// Người dùng click vào nut bắt đầu chat
        /// </summary>
        public const string New_Click_Chat = "z_new_click_chat";
        /// <summary>
        /// Sự kiện nhân viên chat gửi sang cho khách hàng
        /// </summary>
        public const string New_Message_Agent_Chat = "z_agent_chat";


        
    }
}
