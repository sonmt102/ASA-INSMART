﻿namespace CTS.Common.Zalo
{
    public static class ZaloWebhookEventConst
    {
        /// <summary>
        /// Sự kiện nhãn bị xóa
        /// Khi Official Account xóa nhãn qua Open API, hệ thống Zalo sẽ gửi một request HTTP đến Webbhook Url đã đăng ký trên ứng dụng.
        /// </summary>
        public const string remove_tag = "remove_tag";
        /// <summary>
        /// Sự kiện gỡ nhãn khỏi người dùng
        /// Khi Official Account gỡ nhãn khỏi người dùng qua Open API, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// </summary>
        public const string remove_user_from_tag = "remove_user_from_tag";
        /// <summary>
        /// Sự kiện nhãn được tạo và Sự kiện nhãn được gắn cho người dùng -> Giống event name, khác nhau phàn nội dung trả về
        /// Khi Official Account tạo mới một nhãn qua Open API, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng
        /// </summary>
        public const string add_user_to_tag = "add_user_to_tag";
        /// <summary>
        /// Sự kiện người dùng đã xem tin nhắn được gửi từ Official Account
        /// Khi tin nhắn gửi từ Official Account được người dùng xem, hệ thống Zalo sẽ gửi đến Webhook Url của Official Account một http post như sau
        /// </summary>
        public const string user_seen_message = "user_seen_message";
        /// <summary>
        /// Sự kiện người dùng nhận tin nhắn từ Official Account
        /// Khi Official Account gửi tin nhắn cho người dùng và tin nhắn đó đã được nhận, hệ thống Zalo sẽ gửi đến Webhook Url của Official Account một request http như sau
        ///Quyền cần có:
        ///Sự kiện tin nhắn đã được nhận
        ///Sự kiện này chỉ được gửi về khi user nhận tin nhắn trên Zalo Mobile
        /// </summary>
        public const string user_received_message = "user_received_message";
        /// <summary>
        /// Sự kiện user access wifi authenticate by zalo
        /// Khi người dùng sử dụng wifi có địa chỉ ip đã được đăng ký thông qua Open API và đăng nhập vào Zalo, hệ thống Zalo sẽ gửi đến Webhook Url của Official Account một request http như sau
        /// </summary>
        public const string user_authentication = "user_authentication";
        /// <summary>
        /// Sự kiện người dùng muốn biết thêm thông tin về sản phẩm
        /// Khi người dùng chọn vào mục muốn hỏi thêm thông tin của sản phẩm và gửi tin cho shop, hệ thống Zalo sẽ gửi đến Webhook Url của Ứng dụng một request http như sau
        ///Quyền cần có:
        ///Sự kiện người dùng muốn biết thêm thông tin về sản phẩm
        /// </summary>
        public const string user_asking_product = "user_asking_product";
        /// <summary>
        /// Sự kiện người dùng đồng ý chia sẻ thông tin
        /// Khi người dùng đồng ý lời mời cập nhật thông tin, nhập đầy đủ và submit thông tin, hệ thống Zalo sẽ gửi đến Webhook Url của Ứng dụng một request http như sau
        ///Quyền cần có:
        ///Sự kiện người dùng chia sẻ thông tin
        /// </summary>
        public const string user_submit_info = "user_submit_info";
        /// <summary>
        /// Sự kiện người dùng gửi tin nhắn
        /// Khi người dùng gửi tin nhắn đến Official Account, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng
        /// </summary>
        public const string user_send_text = "user_send_text";
        public const string user_send_image = "user_send_image";
        public const string user_send_link = "user_send_link";
        public const string user_send_audio = "user_send_audio";
        public const string user_send_video = "user_send_video";
        public const string user_send_sticker = "user_send_sticker";
        public const string user_send_location = "user_send_location";
        public const string user_send_business_card = "user_send_business_card";
        public const string user_send_file = "user_send_file";
        /// <summary>
        /// Sự kiện người dùng quan tâm/ bỏ quan tâm Official Account
        /// Khi người dùng quan tâm Official Account, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// </summary>
        public const string follow = "follow";
        /// <summary>
        /// Sự kiện người dùng quan tâm/ bỏ quan tâm Official Account
        /// Khi người dùng quan tâm Official Account, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// </summary>
        public const string unfollow = "unfollow";
        /// <summary>
        /// Sự kiện Official Account gửi tin nhắn cho người dùng
        /// Khi Official Account gửi tin nhắn đến người dùng thông qua Open API hay từ cửa sổ chat OA Admin, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// </summary>
        public const string oa_send_text = "oa_send_text";
        /// <summary>
        /// Sự kiện người dùng click nút “Nhắn tin” trên Official Account
        /// Khi người dùng click nút “Nhắn tin” trên Official Account, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng. 
        /// Sự kiện này chỉ gửi 1 lần / 1 user / 1 OA và user đó chưa từng có lịch sử chat với OA.
        /// Sau khi người dùng nhấn nút “Nhắn tin” thì OA có thể gửi tin nhắn chủ động đến người dùng đó.
        /// </summary>
        public const string user_click_chatnow = "user_click_chatnow";
        /// <summary>
        /// Sự kiện người dùng thả biểu tượng cảm xúc lên tin nhắn
        /// Khi người dùng thả biểu tượng cảm xúc vào tin nhắn trong cửa sổ chat với OA, hệ thống Zalo sẽ gửi đến Webhook Url của Official Account một request http như sau
        /// Quyền cần có:  Sự kiện người dùng thả biểu tượng cảm xúc
        /// Sự kiện này chỉ được gửi về khi user nhận tin nhắn trên Zalo Mobile
        /// </summary>
        public const string user_reacted_message = "user_reacted_message";
        /// <summary>
        /// Sự kiện OA thả biểu tượng cảm xúc lên tin nhắn
        /// Khi OA thả biểu tượng cảm xúc vào tin nhắn, hệ thống Zalo sẽ gửi đến Webhook Url của Official Account một request http như sau
        /// Quyền cần có: Sự kiện Official Account thả biểu tượng cảm xúc
        /// Sự kiện này chỉ được gửi về khi user nhận tin nhắn trên Zalo Mobile
        /// </summary>
        public const string oa_reacted_message = "oa_reacted_message";
        /// <summary>
        /// Thông báo thay đổi về loại nội dung OA có thể gửi
        /// Khi có sự kiện thay đổi về cấp độ nội dung OA có thể gửi được phát sinh theo hệ thống đánh giá hoặc theo đề xuất thay đổi từ khách hàng, hệ thống Zalo sẽ gửi đến Webhook Url của ứng dụng một HTTP request như sau.
        /// Quyền cần có:
        /// Sử dụng Zalo Notification Service
        /// </summary>
        public const string change_oa_template_tags = "change_oa_template_tags";
        /// <summary>
        /// Thông báo thay đổi về hạn mức gửi tin của OA
        /// Khi có sự kiện thay đổi về hạn mức gửi tin của OA được phát sinh theo hệ thống đánh giá hoặc theo đề xuất thay đổi từ khách hàng, hệ thống Zalo sẽ gửi đến Webhook Url của ứng dụng một HTTP request như sau
        /// Quyền cần có:
        /// Sử dụng Zalo Notification Service
        /// </summary>
        public const string change_oa_daily_quota = "change_oa_daily_quota";
        /// <summary>
        /// Sự kiện OA gửi yêu cầu thực hiện cuộc gọi đến người dùng / yêu cầu đã hết hạn
        /// Khi OA gửi yêu cầu thực hiện cuộc gọi đến người dùng hoặc khi yêu cầu đó đã hết hạn, 
        /// hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// Quyền cần có: OA gửi yêu cầu thực hiện cuộc gọi đến người dùng
        /// </summary>
        public const string oa_send_consent = "oa_send_consent";
        /// <summary>
        /// Sự kiện người dùng trả lời yêu cầu thực hiện cuộc gọi từ OA
        /// Khi người dùng nhấn cho phép hoặc từ chối yêu cầu thực hiện cuộc gọi, Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// Quyền cần có: Sự kiện người dùng trả lời yêu cầu thực hiện cuộc gọi từ OA
        /// </summary>
        public const string user_reply_consent = "user_reply_consent";
        /// <summary>
        /// Sự kiện kết thúc cuộc gọi
        /// Khi người dùng nhấn cho phép hoặc từ chối yêu cầu thực hiện cuộc gọi, Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// Quyền cần có: Sự kiện người dùng trả lời yêu cầu thực hiện cuộc gọi từ OA
        /// </summary>
        public const string user_call_oa = "user_call_oa";
        /// <summary>
        /// Sự kiện người dùng ẩn danh gửi tin nhắn
        /// Khi người dùng gửi tin nhắn đến Official Account, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// </summary>
        public const string anonymous_send_text = "anonymous_send_text";
        /// <summary>
        /// Sự kiện Official Account gửi tin nhắn cho người dùng ẩn danh
        /// Khi Official Account gửi tin nhắn đến người dùng ẩn danh, hệ thống Zalo sẽ gửi một request HTTP đến Webhook Url đã đăng ký của ứng dụng.
        /// </summary>
        public const string oa_send_anonymous_text = "oa_send_anonymous_text";


        #region ZNS
        public const string zns_user_feedback = "user_feedback";

        #endregion
    }
}
