﻿namespace CTS.Common
{

    public enum TransferOP_ReplyType : int
    {
        Email = 0,
        Call = 1
    }

    public enum UpdateTicketType : int
    {
        All = 0,
        Ticket = 1,
        TransferOP = 2
    }
    public enum ExportExcelLogType : int
    {
        VOC_CS_List = 0,
        VOC_CS_Detail = 1,
        VOC_CS_TAT = 2,
        VOC_OP_List = 3,
        VOC_OP_Detail = 5,
        VOC_OP_TAT = 4
    }

    public enum ExportExcelLogStatus : int
    {
        DangXuLy = 0,
        DaXong = 1,
        Loi = 2
    }

    public enum ServerMailType : int
    {
        Gmail = 0,
        Office365 = 1
    }

    public enum MailType : int
    {
        PhiNhanTho = 0,
        NhanTho = 1,
        Helpdesk = 2,
        DVKH_MBAL = 3
    }
    public enum VOC_TAT_Minute : int
    {
        Customer_TAT_NO_BLVP = 480,
        Customer_TAT_BLVP = 60,
        OP_TAT_NO_BLVP = 240,
        OP_TAT_BLVP = 30
    }

    public enum VOCHistoryType : int
    {
        Phone = 0,
        Contract = 1,
        Document = 2,
        Email = 3
    }
    public enum OPHandler_Status : int
    {
        ChuaXuLy = 0,
        DangXuLy = 1,
        DaXuLy = 2,
        PhuongAnChuaDayDu = 3,
        KhongPhanHoi = 4
    }

    public enum OPHandler_Detail_Status : int
    {
        ChuaXuLy = 0,
        CTBH = 1,
        CSYT = 2,
        Bank = 3,
        HDCM = 4,
        DaXuLy = 5,
        PhuongAnChuaDayDu = 6,
        KhongPhanHoi = 7,
        DangXuLy = 8
    }

    /// <summary>
    /// Trạng thái tìm kiếm màn hình agent
    /// </summary>
    public enum AgentStatusHistory : int
    {
        All = 0,
        Answer = 1,
        NoAnswer = 2,
        MissCall = 3,
        Inbound = 4,
        Outbound = 5
    }
    public enum FixChanSpyExen
    {
        NgheXen = 101,
        NhacNho = 102,
        HoiThoai = 103
    }
    public enum TicketFromModule : int
    {
        None = 0,
        Call = 1,
        Chat = 2,
        Zalo = 3,
        Facebook = 4
    }

    /// <summary>
    /// Hướng cuộc gọi trong phần core
    /// </summary>
    public enum CallCoreDirection : int
    {
        /// <summary>
        /// Gọi vào
        /// </summary>
        Intercom = 0,
        /// <summary>
        /// Gọi ra
        /// </summary>
        Inbound = 1,
        /// <summary>
        /// Cả gọi ra, gọi vào
        /// </summary>
        Outbound = 2,
    }

    public enum DateType : int
    {
        None = 0,
        Gio = 1,
        Ngay = 2,
        Thang = 3,
        Nam = 4
    }

    /// <summary>
    /// Loại action
    /// </summary>
    public enum ActionType : int
    {
        IVR = 1,
        ChuyenCuocGoiToiNhom = 2,
        ChuyenCuocGoiRaDiDong = 3,
        VoiceMail = 4,
        TraLoiTuDong = 5,
        KetThucCuocGoi = 6
    }

    /// <summary>
    /// Phân biệt action con là phím bấm hay không
    /// </summary>
    public enum ActionCode : int
    {
        PhimBam = 1,
        TrucThuoc = 2
    }

    public enum ActionCode2_ActionType
    {
        None = 0,
        /// <summary>
        /// Phát hết thông báo mà khách hàng không bấm phím
        /// Hành động con trong hành động IVR
        /// </summary>
        IVR_Type1 = 1,
        /// <summary>
        /// Nếu khách hàng bấm sai phím vượt tối đa
        /// Hành động con trong hành động IVR
        /// </summary>
        IVR_Type2 = 2,
        /// <summary>
        /// Nếu không gặp được điện thoại viên
        /// ành động con trong hành động: Chuyển cuộc gọi tới nhóm
        /// </summary>
        TG_Type = 3
    }

    /// <summary>
    /// Hướng cuộc gọi
    /// </summary>
    public enum CallDirection : int
    {
        /// <summary>
        /// Gọi vào
        /// </summary>
        Inbound = 0,
        /// <summary>
        /// Gọi ra
        /// </summary>
        Outbound = 1,
        /// <summary>
        /// Cả gọi ra, gọi vào
        /// </summary>
        Both = 2,
    }

    /// <summary>
    /// Loại lịch
    /// </summary>
    public enum V9_ScheduleActionType
    {
        /// <summary>
        /// Theo thứ
        /// </summary>
        DayOfWeek = 1,
        /// <summary>
        /// Theo ngày
        /// </summary>
        Date = 2
    }
    public enum AgentStatusCall : int
    {
        /// <summary>
        /// Không có cuộc gọi
        /// </summary>
        None = 0,
        /// <summary>
        /// Đang đổ chuông
        /// </summary>
        Ring = 1,
        /// <summary>
        /// Đang trong cuộc gọi
        /// </summary>
        InCall = 2
    }
    public enum LogAccess_DataType : int
    {
        TaiKhoan = 1,
        Quyen = 2
    }
    public enum LogAccess_Type : int
    {
        TruyCap = 1,
        TaoMoi = 2,
        ChinhSua = 3,
        Xoa = 4
    }
    public enum CallWarningType : int
    {
        None = 0,
        /// <summary>
        /// Tần số cao lên bất thường
        /// </summary>
        CaoBatThuong = 1,
        /// <summary>
        /// Có nhiều cặp tần số cao
        /// </summary>
        NhieuCap99 = 2,
        /// <summary>
        /// Có nhiều tần số cao liền nhau
        /// </summary>
        Nhieu99LienNhau = 3,
        /// <summary>
        /// Dính cả 3 TH
        /// </summary>
        All = 4
    }
    public enum JoinType
    {
        /// <summary>
        /// Same as regular join. Inner join produces only the set of records that match in both Table A and Table B.
        /// </summary>
        Inner = 0,
        /// <summary>
        /// Same as Left Outer join. Left outer join produces a complete set of records from Table A, with the matching records (where available) in Table B. If there is no match, the right side will contain null.
        /// </summary>
        Left = 1
    }

    public enum VOCDeadlineTimeType : int
    {
        Phut = 1,
        Gio = 2,
        Ngay = 3
    }

    public enum QALoaiTieuChi : int
    {
        ChuyenMon = 1,
        NghiepVu = 2
    }
    public enum VOCActionType : int
    {
        /// <summary>
        /// Thông báo lên phần mềm cho người phụ trách
        /// </summary>
        ThongBao = 1,
        /// <summary>
        /// Gửi email đến người phụ trách
        /// </summary>
        GuiEmail = 2,
        /// <summary>
        /// Phân công mặc định đến người phụ trách
        /// </summary>
        PhanCongPhuTrach = 3
    }

    public enum VOCTicketStatus : int
    {
        NEW = 1,
        TRANSFER_OP = 2,
        COMPLETE = 3,
        DangTheoDoi = 4,
        HANDLER = 5
    }

    public enum NotifyModule : int
    {
        VOC = 1,
    }


    public enum EMSMSCampaignType : int
    {
        GuiTheoLo = 0,
        ChucMungSinhNhat = 1
    }

    public enum EMSMSTemplateType : int
    {
        Email = 1,
        SMS = 2
    }
}
