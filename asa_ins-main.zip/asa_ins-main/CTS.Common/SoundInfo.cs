﻿//using NAudio.Wave;

namespace CTS.Common
{
    public static class SoundInfo
    {
        //public static double GetWavFileDuration(string fileName)
        //{
        //    WaveFileReader wf = new WaveFileReader(fileName);
        //    return wf.TotalTime.TotalSeconds;
        //}
    }
}
