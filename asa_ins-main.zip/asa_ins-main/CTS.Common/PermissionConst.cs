﻿namespace CTS.Common
{
    public static class PermissionConst
    {
        #region VOC
        /// <summary>
        /// Quyền truy cập dữ liệu yêu cầu
        /// </summary>
        public const string VIEW_TICKET = "VIEW_TICKET";
        /// <summary>
        /// Quyền truy xoá lần chuyển OP
        /// </summary>
        public const string DELETE_TRANSFER_OP = "DELETE_TRANSFER_OP";
        /// <summary>
        /// Quyền tạo mới yêu cầu
        /// </summary>
        public const string CREATE_TICKET = "CREATE_TICKET";
        /// <summary>
        /// Quyền cập nhật yêu cầu
        /// </summary>
        public const string UPDATE_TICKET = "UPDATE_TICKET";
        /// <summary>
        /// Quyền xóa bản ghi yêu cầu
        /// </summary>
        public const string DELETE_TICKET = "DELETE_TICKET";
        /// <summary>
        /// Quyền truy cập báo cáo yêu cầu
        /// </summary>
        public const string REPORT_TICKET = "REPORT_TICKET";

        /// <summary>
        /// Xem tất cả dữ liệu phòng ban
        /// </summary>
        public const string VIEW_ALL_TICKET_DEPARTMENT = "VIEW_ALL_TICKET_DEPARTMENT";
        /// <summary>
        /// Quyền bộ phận thụ lý
        /// </summary>
        public const string VIEW_OP = "VIEW_OP";

        #endregion

        #region QA
        /// <summary>
        /// Quyền chấm điểm
        /// </summary>
        public const string CREATE_QA = "CREATE_QA";
        /// <summary>
        /// Quyền phân công chấm điểm
        /// </summary>
        public const string ASSIGN_QA = "ASSIGN_QA";
        /// <summary>
        /// Quyền truy cập báo cáo
        /// </summary>
        public const string REPORT_QA = "REPORT_QA";
        /// <summary>
        /// Quản lý chấm điểm
        /// </summary>
        public const string MANAGER_QA = "MANAGER_QA";
        #endregion

        #region EMAIL/SMS

        public const string EMAIL_SMS = "EMAIL/SMS";
        #endregion

        #region CIMS
        /// <summary>
        /// Quyền truy cập dữ liệu chung
        /// </summary>
        public const string VIEW_CIMS = "VIEW_CIMS";
        /// <summary>
        /// Quyền truy cập dữ NEXT
        /// </summary>
        public const string VIEW_DATALAKE = "VIEW_DATALAKE";
        /// <summary>
        /// Quyền truy cập dữ liệu danh mục tỉnh
        /// </summary>
        public const string VIEW_CATEGORY = "VIEW_CATEGORY";

        #endregion

        #region KMS
        /// <summary>
        /// Quyền quản lý bài viết
        /// </summary>
        public const string KMS_MANAGER = "KMS_MANAGER";

        #endregion

        #region Quản trị

        /// <summary>
        /// Có quyền quản trị
        /// </summary>
        public const string MANAGER = "MANAGER";

        #endregion

        #region Chat

        /// <summary>
        /// Có quyền vào báo cáo chat
        /// </summary>
        public const string REPORT_CHAT = "REPORT_CHAT";
        /// <summary>
        /// Có quyền vào chat
        /// </summary>
        public const string CHAT = "CHAT";
        #endregion

        #region VOICE

        /// <summary>
        /// Có quyền agent và có đăng nhập số nội bộ
        /// </summary>
        public const string AGENT_ALLOW = "AGENT_ALLOW";
        /// <summary>
        /// Có quyền SUPERVISOR
        /// </summary>
        public const string SUP_ALLOW = "SUP_ALLOW";
        /// <summary>
        /// Có quyền xem báo cáo
        /// </summary>
        public const string REPORT_ALLOW = "REPORT_ALLOW";

        #endregion

        #region Zalo

        /// <summary>
        /// Quyền trực Zalo
        /// </summary>
        public const string AGENT_ZALO = "AGENT_ZALO";

        #endregion
    }
}
