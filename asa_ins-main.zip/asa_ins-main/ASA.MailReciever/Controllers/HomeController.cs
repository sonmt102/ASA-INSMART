﻿using ASA.Mail.Models;
using ASA.Mail.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace ASA.MailReciever.Controllers
{
    public class HomeController : Controller
    {
        private readonly IIdleClientNhanThoServices _IdleClientNhanThoServices;
        private readonly IIdleClientPhiNhanThoServices _IdleClientPhiNhanThoServices;
        private readonly IInboxServices _InboxServices;
        private readonly List<EmailConfigModel> _EmailConfigs;
        private readonly ITestServices _TestServices;
        private readonly ICompanyIdentityServices _CompanyIdentityServices;

        public HomeController(IIdleClientNhanThoServices IdleClientNhanThoServices, IIdleClientPhiNhanThoServices IdleClientPhiNhanThoServices,
            IInboxServices InboxServices, IOptions<List<EmailConfigModel>> options, ITestServices TestServices,
            ICompanyIdentityServices CompanyIdentityServices)
        {
            _CompanyIdentityServices = CompanyIdentityServices;
            _TestServices = TestServices;
            _EmailConfigs = options.Value;
            _InboxServices = InboxServices;
            _IdleClientNhanThoServices = IdleClientNhanThoServices;
            _IdleClientPhiNhanThoServices = IdleClientPhiNhanThoServices;
        }

        [HttpGet("Test/Mail")]
        public async Task<IActionResult> Mail(int uni)
        {
            try
            {
                var conf = _EmailConfigs.Where(x => x.Code == "giaidapthacmachn").FirstOrDefault();
                await _TestServices.SetFlag(conf, uni);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);

            }
        }

        [HttpGet("Test/GetFolder")]
        public async Task<IActionResult> GetFolder()
        {
            try
            {
                var conf = _EmailConfigs.Where(x => x.Code == "chamsockhachhang").FirstOrDefault();
                await _TestServices.GetFolderCS(conf);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);

            }
        }

        [HttpGet("Test/CheckSubFolders")]
        public async Task<IActionResult> CheckSubFolders()
        {
            try
            {
                var conf = _EmailConfigs.Where(x => x.Code == "chamsockhachhang").FirstOrDefault();
                await _TestServices.CheckSubFolder(conf);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);

            }
        }


        [HttpGet("Test/CheckFolderPhiNhanTho")]
        public async Task<IActionResult> CheckFolderPhiNhanTho()
        {
            try
            {
                var conf = _EmailConfigs.Where(x => x.Code == "giaidapthacmachn").FirstOrDefault();
                await _TestServices.CheckSubFolder(conf);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);

            }
        }

        [HttpGet("Test/CheckNhanDienCongTy/{mailId}")]
        public async Task<IActionResult> CheckNhanDienCongTy(Guid mailId)
        {
            try
            {
                var check = await _CompanyIdentityServices.RunAsync(mailId);
                return Ok(check);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);

            }
        }
    }
}
