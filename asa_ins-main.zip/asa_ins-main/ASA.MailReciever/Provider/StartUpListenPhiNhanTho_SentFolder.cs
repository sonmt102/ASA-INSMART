﻿using ASA.Mail.Models;
using ASA.Mail.Services;
using CTS.Common;
using Microsoft.Extensions.Options;

namespace ASA.MailReciever.Provider
{

    public class StartUpListenPhiNhanTho_SentFolder : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpListenPhiNhanTho_SentFolder> _logger;
        private readonly List<EmailConfigModel> _EmailConfigs;

        public StartUpListenPhiNhanTho_SentFolder(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpListenPhiNhanTho_SentFolder> logger,
            IOptions<List<EmailConfigModel>> options)
        {
            _EmailConfigs = options.Value;
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _PhiNhanTho_SentFolder = scope.ServiceProvider.GetRequiredService<IIdleClientPhiNhanTho_SentServices>();

                //Phi: giaidapthacmachn@insmart.com.vn

                var configPhi = _EmailConfigs.Where(x => x.Type == MailType.PhiNhanTho).FirstOrDefault();
                if (configPhi != null)
                {
                    var check = await _PhiNhanTho_SentFolder.RunAsync(configPhi);
                    if (!check.Item1)
                    {
                        Console.WriteLine($"FAIL CONNECT EMAIL PHI NHAN THO SENT FOLDER");
                        Console.WriteLine($"Error: {check.Item2}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

    }
}
