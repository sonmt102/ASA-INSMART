﻿using ASA.Mail.Models;
using ASA.Mail.Services;
using CTS.Common;
using Microsoft.Extensions.Options;

namespace ASA.MailReciever.Provider
{

    public class StartUpListenHelpdesk : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpListenHelpdesk> _logger;
        private readonly List<EmailConfigModel> _EmailConfigs;

        public StartUpListenHelpdesk(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpListenHelpdesk> logger,
            IOptions<List<EmailConfigModel>> options)
        {
            _EmailConfigs = options.Value;
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _hd = scope.ServiceProvider.GetRequiredService<IIdleClientHelpdeskServices>();

                //Phi: giaidapthacmachn@insmart.com.vn

                var configHD = _EmailConfigs.Where(x => x.Type == MailType.Helpdesk).FirstOrDefault();
                if (configHD != null)
                {
                    var check = await _hd.RunAsync(configHD);
                    if (!check.Item1)
                    {
                        Console.WriteLine($"FAIL CONNECT EMAIL HELP DESK");
                        Console.WriteLine($"Error: {check.Item2}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

    }
}
