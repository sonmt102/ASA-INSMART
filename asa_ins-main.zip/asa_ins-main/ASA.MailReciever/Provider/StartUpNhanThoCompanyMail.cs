﻿using ASA.Mail.Services;

namespace ASA.MailReciever.Provider
{

    public class StartUpNhanThoCompanyMail : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpNhanThoCompanyMail> _logger;

        public StartUpNhanThoCompanyMail(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpNhanThoCompanyMail> logger)
        {
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _companyServices = scope.ServiceProvider.GetRequiredService<ICompanyIdentityServices>();

                await _companyServices.RunAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

    }
}
