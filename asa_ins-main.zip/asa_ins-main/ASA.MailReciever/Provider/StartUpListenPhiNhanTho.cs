﻿using ASA.Mail.Models;
using ASA.Mail.Services;
using CTS.Common;
using Microsoft.Extensions.Options;

namespace ASA.MailReciever.Provider
{

    public class StartUpListenPhiNhanTho : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpListenPhiNhanTho> _logger;
        private readonly List<EmailConfigModel> _EmailConfigs;

        public StartUpListenPhiNhanTho(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpListenPhiNhanTho> logger,
            IOptions<List<EmailConfigModel>> options)
        {
            _EmailConfigs = options.Value;
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _PhiNhanTho = scope.ServiceProvider.GetRequiredService<IIdleClientPhiNhanThoServices>();

                //Phi: giaidapthacmachn@insmart.com.vn

                var configPhi = _EmailConfigs.Where(x => x.Type == MailType.PhiNhanTho).FirstOrDefault();
                if (configPhi != null)
                {
                    var check = await _PhiNhanTho.RunAsync(configPhi);
                    if (!check.Item1)
                    {
                        Console.WriteLine($"FAIL CONNECT EMAIL PHI NHAN THO");
                        Console.WriteLine($"Error: {check.Item2}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

    }
}
