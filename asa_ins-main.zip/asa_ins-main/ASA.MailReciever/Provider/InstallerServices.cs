﻿using ASA.Mail.Services;
using CTS.Infra;
using Microsoft.EntityFrameworkCore;

namespace ASA.MailReciever.Provider
{
    public static class InstallerServices
    {
        public static IServiceCollection AddEFConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("DBConnection");
            services.AddDbContext<CTSContext>(options =>
            {
                options.UseLazyLoadingProxies().UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
            });

            //var asteriskConnectionString = configuration.GetConnectionString("AsteriskConnection");
            //services.AddDbContext<AsteriskContext>(options =>
            //{
            //    options.UseLazyLoadingProxies().UseMySql(asteriskConnectionString, ServerVersion.AutoDetect(asteriskConnectionString));
            //});

            //services.AddDbContext<MMContext>(opt =>
            //{
            //    opt.ConfigureWarnings(builder =>
            //    {
            //        builder.Ignore(CoreEventId.PossibleIncorrectRequiredNavigationWithQueryFilterInteractionWarning);
            //    });
            //    opt.UseInMemoryDatabase(databaseName: "INSInMemoryDb");
            //}, ServiceLifetime.Scoped, ServiceLifetime.Scoped);

            services.AddTransient<IIdleClientNhanThoServices, IdleClientNhanThoServices>();
            services.AddTransient<IIdleClientPhiNhanThoServices, IdleClientPhiNhanThoServices>();
            services.AddTransient<IIdleClientPhiNhanTho_SentServices, IdleClientPhiNhanTho_SentServices>();
            services.AddTransient<IIdleClientHelpdeskServices, IdleClientHelpdeskServices>();
            services.AddTransient<IInboxServices, InboxServices>();
            services.AddTransient<ITestServices, TestServices>();
            services.AddTransient<ICompanyIdentityServices, CompanyIdentityServices>();

            return services;
        }
    }
}
