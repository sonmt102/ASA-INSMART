﻿using ASA.Mail.Models;
using ASA.Mail.Services;
using CTS.Common;
using Microsoft.Extensions.Options;

namespace ASA.MailReciever.Provider
{

    public class StartUpListenNhanTho : BackgroundService
    {
        private readonly IServiceScopeFactory _ServiceScopeFactory;
        private readonly ILogger<StartUpListenNhanTho> _logger;
        private readonly List<EmailConfigModel> _EmailConfigs;

        public StartUpListenNhanTho(IServiceScopeFactory IServiceScopeFactory, ILogger<StartUpListenNhanTho> logger,
            IOptions<List<EmailConfigModel>> options)
        {
            _EmailConfigs = options.Value;
            _logger = logger;
            _ServiceScopeFactory = IServiceScopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _ServiceScopeFactory.CreateScope();
                var _NhanTho = scope.ServiceProvider.GetRequiredService<IIdleClientNhanThoServices>();

                //Nhan: chamsockhachhang@insmart.com.vn
                var configNhan = _EmailConfigs.Where(x => x.Type == MailType.NhanTho).FirstOrDefault();
                if (configNhan != null)
                {
                    var check = await _NhanTho.RunAsync(configNhan);
                    if (!check.Item1)
                    {
                        Console.WriteLine($"FAIL CONNECT EMAIL NHAN THO");
                        Console.WriteLine($"Error: {check.Item2}");
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

    }
}
