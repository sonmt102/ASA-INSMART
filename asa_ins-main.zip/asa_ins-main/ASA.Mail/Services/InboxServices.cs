﻿using ASA.Mail.Common;
using ASA.Mail.Models;
using CTS.Domain.Mail;
using CTS.Infra;
using MailKit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ASA.Mail.Services
{
    public interface IInboxServices
    {
        Task<int> GetMaxIndexNhanThoInbox();
        Task<int> GetMaxIndexPhiNhanThoInbox();
        Task<List<string>> GetMessageIdBeforeAday(string queue);
        Task<List<string>> GetMessageIdBeforeAday_SentItem(string queue);
        Task<List<UniqueId>> GetUniqueBeforeAday(string queue);
        Task<List<UniqueId>> GetUniqueBeforeAday_SentItem(string queue);
        Task Create(List<MAIL_INBOXCreateModel> mes, string queue, bool isAssign = false);
        Task<string> ReGetMail(List<MAIL_INBOXCreateModel> mes);
    }
    public class InboxServices : IInboxServices
    {
        private readonly CTSContext _Context;
        private readonly ILogger<InboxServices> _logger;

        public InboxServices(CTSContext context, ILogger<InboxServices> logger)
        {
            _Context = context;
            _logger = logger;
        }

        public async Task Create(List<MAIL_INBOXCreateModel> mes, string queue, bool isAssign = false)
        {
            try
            {
                #region - Xử lý trùng UniqueId
                {
                    var uniqueIds = mes.Select(s => s.UniqueId).ToList();
                    var existUniqueId = await _Context.MAIL_INBOXs.Where(x =>
                        x.Date >= DateTime.Now.AddDays(-2) && uniqueIds.Contains(x.UniqueId)
                        && x.Queue == queue
                    ).Select(s => s.UniqueId).ToListAsync();
                    mes = mes.Where(x => !existUniqueId.Contains(x.UniqueId)).ToList();

                }
                #endregion

                #region - Xử lý trung MessageId

                {
                    var messageIds = mes.Where(x => !string.IsNullOrEmpty(x.MessageId)).Select(s => s.MessageId).ToList();
                    var existMessageId = await _Context.MAIL_INBOXs.Where(x => x.Queue == queue
                        && x.Date >= DateTime.Now.AddDays(-2) && messageIds.Contains(x.MessageId) && !string.IsNullOrEmpty(x.MessageId)
                    ).Select(s => s.MessageId).ToListAsync();
                    mes = mes.Where(x => !existMessageId.Contains(x.MessageId)).ToList();
                }

                #endregion

                #region - Lưu thông tin

                if (mes != null && mes.Any())
                {
                    var data = mes.Select(s => new MAIL_INBOX
                    {
                        Id = Guid.NewGuid(),
                        Index = s.Index,
                        Body = !string.IsNullOrEmpty(s.Body) ? s.Body.Trim() : null,
                        IsReply = s.IsReply,
                        Date = s.Date,
                        Flag = s.Flag,
                        CreatedDate = DateTime.Now,
                        Queue = s.Queue,
                        From = s.From,
                        Channel = s.Channel,
                        FromEmail = s.FromEmail,
                        InReplyTo = s.InReplyTo,
                        MessageId = s.MessageId,
                        UniqueId = s.UniqueId,
                        Subject = s.Subject,
                        FolderMail = s.FolderMail,
                        IsAssign = isAssign,
                        MAIL_INBOX_Tos = s.Tos.Select(s1 => new MAIL_INBOX_To
                        {
                            Id = Guid.NewGuid(),
                            Email = s1.Email,
                            Name = s1.Name
                        }).ToList(),
                        MAIL_INBOX_CCs = s.CCs.Select(s1 => new MAIL_INBOX_CC
                        {
                            Id = Guid.NewGuid(),
                            Email = s1.Email,
                            Name = s1.Name
                        }).ToList(),
                        MAIL_INBOX_BCCs = s.BCCs.Select(s1 => new MAIL_INBOX_BCC
                        {
                            Id = Guid.NewGuid(),
                            Email = s1.Email,
                            Name = s1.Name
                        }).ToList(),
                        MAIL_INBOX_Attachs = s.Attachs.Select(s1 => new MAIL_INBOX_Attach
                        {
                            Id = Guid.NewGuid(),
                            Queue = s.Queue,
                            UniqueId = s.UniqueId,
                            Name = s1
                        }).ToList(),
                        MAIL_INBOX_Tags = (!string.IsNullOrEmpty(s.FolderMail) && s.FolderMail != "Inbox") ? new List<MAIL_INBOX_Tag>()
                        {
                            new MAIL_INBOX_Tag
                            {
                                MAIL_TagListId = 2
                            }
                        } : null
                    });


                    var myQueue = await _Context.MAIL_Queues.Where(x => x.Code == queue).FirstOrDefaultAsync();
                    if (myQueue != null) myQueue.MailCounter = data.Max(x => x.UniqueId);

                    await _Context.MAIL_INBOXs.AddRangeAsync(data);
                    await _Context.SaveChangesAsync();
                }

                #endregion
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        public async Task<int> GetMaxIndexNhanThoInbox()
        {
            try
            {
                return await _Context.MAIL_Queues.IgnoreAutoIncludes()
                    .Where(x => x.MailType == CTS.Common.MailType.NhanTho).MaxAsync(x => x.MailCounter);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return 0;
            }

        }

        public async Task<int> GetMaxIndexPhiNhanThoInbox()
        {
            try
            {
                return await _Context.MAIL_Queues.IgnoreAutoIncludes()
                    .Where(x => x.MailType == CTS.Common.MailType.PhiNhanTho).MaxAsync(x => x.MailCounter);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return 0;
            }

        }

        public async Task<List<UniqueId>> GetUniqueBeforeAday(string queue)
        {
            try
            {
                var data = await _Context.MAIL_INBOXs.Where(x => x.Queue == queue && x.Date >= DateTime.Now.AddDays(-2))
                    .Select(s => s.UniqueId).ToListAsync();
                if (data != null && data.Count > 0) return data.Select(s => new UniqueId(14, Convert.ToUInt32(s))).ToList();
                else return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }

        public async Task<List<UniqueId>> GetUniqueBeforeAday_SentItem(string queue)
        {
            try
            {
                var data = await _Context.MAIL_INBOXs.Where(x => x.Queue == queue && x.Date >= DateTime.Now.AddDays(-2)
                    && x.FolderMail == MailConst.FolderSentItem)
                    .Select(s => s.UniqueId).ToListAsync();
                if (data != null && data.Count > 0) return data.Select(s => new UniqueId(14, Convert.ToUInt32(s))).ToList();
                else return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }




        public async Task<List<string>> GetMessageIdBeforeAday(string queue)
        {
            try
            {
                return await _Context.MAIL_INBOXs.Where(x => x.Queue == queue && x.Date >= DateTime.Now.AddDays(-2))
                    .Select(s => s.MessageId).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }

        public async Task<List<string>> GetMessageIdBeforeAday_SentItem(string queue)
        {
            try
            {
                return await _Context.MAIL_INBOXs.Where(x => x.Queue == queue && x.Date >= DateTime.Now.AddDays(-2)
                    && x.FolderMail == MailConst.FolderSentItem)
                    .Select(s => s.MessageId).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }

        public async Task<string> ReGetMail(List<MAIL_INBOXCreateModel> mes)
        {
            try
            {
                for (int i = 0; i < mes.Count; i++)
                {
                    var item = await _Context.MAIL_INBOXs.Include(x => x.MAIL_INBOX_Attachs).Where(x => x.UniqueId == mes[i].UniqueId).FirstOrDefaultAsync();
                    if (item != null)
                    {
                        item.Subject = mes[i].Subject;
                        item.Body = mes[i].Body;
                        if (item.MAIL_INBOX_Attachs.Any())
                        {
                            _Context.MAIL_INBOX_Attachs.RemoveRange(item.MAIL_INBOX_Attachs);
                            await _Context.SaveChangesAsync();
                        }
                        if (mes[i].Attachs != null && mes[i].Attachs.Count > 0)
                        {
                            item.MAIL_INBOX_Attachs = mes[i].Attachs.Select(s1 => new MAIL_INBOX_Attach
                            {
                                Id = Guid.NewGuid(),
                                Name = s1
                            }).ToList();
                        }
                        await _Context.SaveChangesAsync();
                    }
                    else
                    {
                        //await Create(mes);
                    }
                }

                return "OK";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return ex.Message;
            }

        }

    }
}
