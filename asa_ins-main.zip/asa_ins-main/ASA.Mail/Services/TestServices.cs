﻿//
// IdleClient.cs
//
// Author: Jeffrey Stedfast <jeff@xamarin.com>
//
// Copyright (c) 2014-2023 Jeffrey Stedfast
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

using ASA.Mail.Models;
using CTS.Common;
using ASA.SMTPAuth2;
using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using MailKit.Security;
using Microsoft.Extensions.Logging;
using MimeKit;
using Newtonsoft.Json;
using System.Text;
using System.Text.RegularExpressions;

namespace ASA.Mail.Services
{
    public interface ITestServices
    {
        Task<(bool, string)> RunAsync(EmailConfigModel config);
        Task<string> ReGetMail(EmailConfigModel config, string messId, string config_AttachSource, string config_Code, string config_Channel);
        Task SetFlag(EmailConfigModel config, int uni);
        Task GetFolderCS(EmailConfigModel config);
        Task GetCheckMail(EmailConfigModel config, int uni);
        Task CheckSubFolder(EmailConfigModel config);
    }

    public class TestServices : IDisposable, ITestServices
    {
        private readonly CancellationTokenSource cancel;
        CancellationTokenSource? done;
        private readonly FetchRequest request;
        private readonly ImapClient client;
        private bool messagesArrived;
        private readonly ILogger<TestServices> _logger;
        private readonly IInboxServices _InboxServices;
        private readonly CodeFlowHelper _codeFlowHelper;
        private readonly WellKnownConfigurationHandler _wellKnownConfigurationHandler;
        private readonly IHttpClientFactory _httpClientFactory;

        /// <summary>
        /// Contructor
        /// </summary>
        public TestServices(ILogger<TestServices> logger, IInboxServices InboxServices,
            CodeFlowHelper codeFlowHelper, WellKnownConfigurationHandler wellKnownConfigurationHandler,
             IHttpClientFactory httpClientFactory)
        {
            _InboxServices = InboxServices;
            _logger = logger;
            client = new ImapClient(new ProtocolLogger(Console.OpenStandardError()));
            request = new FetchRequest(MessageSummaryItems.Full | MessageSummaryItems.UniqueId);
            cancel = new CancellationTokenSource();
            _wellKnownConfigurationHandler = wellKnownConfigurationHandler;
            _codeFlowHelper = codeFlowHelper;
            _httpClientFactory = httpClientFactory;
        }

        async Task ReconnectAsync(EmailConfigModel config)
        {
            if (!client.IsConnected)
            {
                switch (config.ServerType)
                {
                    case ServerMailType.Gmail:
                        await client.ConnectAsync(config.Host, config.Port, SecureSocketOptions.Auto, cancel.Token);
                        break;
                    case ServerMailType.Office365:
                        await client.ConnectAsync(config.Host, config.Port, SecureSocketOptions.Auto, cancel.Token);
                        break;
                    default:
                        break;
                }

            }


            if (!client.IsAuthenticated)
            {
                switch (config.ServerType)
                {
                    case ServerMailType.Gmail:
                        await client.AuthenticateAsync(config.Username, config.Password, cancel.Token);

                        await client.Inbox.OpenAsync(FolderAccess.ReadWrite, cancel.Token);
                        break;
                    case ServerMailType.Office365:
                        {
                            OAuth2Client oAuth2Client = CreateOAuth2Client(config);
                            var request = await oAuth2Client.GenerateTokenRequestForClientFlowAsync(
                                $"https://login.microsoftonline.com/{config.TenantID}/v2.0",
                                "https://outlook.office365.com/.default",
                            config.ClientSecret);

                            var clientHttp = _httpClientFactory.CreateClient("default");
                            var response = await clientHttp.SendAsync(request);
                            if (!response.IsSuccessStatusCode)
                            {
                                string error = "";
                                if (response.Content != null)
                                {
                                    error = (await response.Content.ReadAsStringAsync()) ?? "";
                                }
                                _logger.LogError($"Internal error: {error}");
                                return;
                            }

                            var stringResponse = await response.Content.ReadAsStringAsync();
                            var obj = JsonConvert.DeserializeAnonymousType(stringResponse, new
                            {
                                access_token = ""
                            })!;

                            await client.AuthenticateAsync(new SaslMechanismOAuth2(config.Username, obj.access_token), cancel.Token);
                            await client.Inbox.OpenAsync(FolderAccess.ReadWrite, cancel.Token);
                        }
                        break;
                    default:
                        break;
                }

            }
        }

        private OAuth2Client CreateOAuth2Client(EmailConfigModel config)
        {
            var oAuth2Client = new OAuth2Client(
                _codeFlowHelper,
                _wellKnownConfigurationHandler,
                $"https://login.microsoftonline.com/{config.TenantID}/v2.0",
                config.ClientID);
            return oAuth2Client;
        }

        public async Task<string> ReGetMail(EmailConfigModel config, string messId, string config_AttachSource,
            string config_Code, string queue_channel)
        {
            try
            {

                {
                    await client.ConnectAsync(config.Host, config.Port, SecureSocketOptions.Auto, cancel.Token);

                    OAuth2Client oAuth2Client = CreateOAuth2Client(config);
                    var request = await oAuth2Client.GenerateTokenRequestForClientFlowAsync(
                        $"https://login.microsoftonline.com/{config.TenantID}/v2.0",
                        "https://outlook.office365.com/.default",
                    config.ClientSecret);

                    var clientHttp = _httpClientFactory.CreateClient("default");
                    var response = await clientHttp.SendAsync(request);
                    if (!response.IsSuccessStatusCode)
                    {
                        string error = "";
                        if (response.Content != null)
                        {
                            error = (await response.Content.ReadAsStringAsync()) ?? "";
                        }
                        _logger.LogError($"Internal error: {error}");
                        return "false";
                    }

                    var stringResponse = await response.Content.ReadAsStringAsync();
                    var obj = JsonConvert.DeserializeAnonymousType(stringResponse, new
                    {
                        access_token = ""
                    })!;

                    await client.AuthenticateAsync(new SaslMechanismOAuth2(config.Username, obj.access_token), cancel.Token);
                    await client.Inbox.OpenAsync(FolderAccess.ReadWrite, cancel.Token);
                }


                if (client.IsAuthenticated)
                {
                    var uids = await client.Inbox.SearchAsync(SearchQuery.HeaderContains("MessageId", messId));
                    if (uids != null)
                    {
                        var data = new List<MAIL_INBOXCreateModel>();
                        IList<IMessageSummary> fetched = await client.Inbox.FetchAsync(uids: new List<UniqueId>() { new UniqueId(398264) },
                            request, cancel.Token);
                        if (fetched != null && fetched.Count > 0)
                        {
                            foreach (var item in fetched)
                            {
                                try
                                {
                                    GetBodyMail(item, out string? htmlString);

                                    var mail_attachs = GetAttachsMail(item.UniqueId, config_AttachSource, config_Code);

                                    var mapMail = GetDataMail(item, htmlString, mail_attachs, config_Code, queue_channel);
                                    if (mapMail != null)
                                    {
                                        var keywords = new HashSet<string>() { "$MailLabel1" };
                                        client.Inbox.AddFlags(item.UniqueId, MessageFlags.Flagged, keywords, true, cancel.Token);
                                        data.Add(mapMail);
                                    }

                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError(ex, ex.Message);
                                }
                            }
                        }
                        if (data != null && data.Count > 0)
                        {
                            await _InboxServices.ReGetMail(data);
                        }
                    }
                    return "OK";
                }
                else
                {
                    return "Chưa kêt nối";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return ex.Message;
            }

        }

        /// <summary>
        /// Map data
        /// </summary>
        /// <param name="item"></param>
        /// <param name="htmlString"></param>
        /// <param name="mail_attachs"></param>
        /// <param name="queue_code"></param>
        /// <param name="queue_channel"></param>
        /// <returns></returns>
        MAIL_INBOXCreateModel? GetDataMail(IMessageSummary item, string? htmlString, List<string> mail_attachs,
            string queue_code, string queue_channel)
        {
            var fromName = item.Envelope.From.Mailboxes.Select(s => s.Name).FirstOrDefault();
            var fromEmail = item.Envelope.From.Mailboxes.Select(s => s.Address).FirstOrDefault();
            return new MAIL_INBOXCreateModel
            {
                Queue = queue_code,
                Index = item.Index,
                Body = htmlString,
                IsReply = item.IsReply,
                Flag = item.Flags.HasValue ? item.Flags.Value.ToString() : null,
                Date = item.Date.LocalDateTime,
                From = fromName,
                Channel = queue_channel,
                FromEmail = fromEmail,
                InReplyTo = item.Envelope.InReplyTo,
                MessageId = item.Envelope.MessageId,
                UniqueId = Convert.ToInt32(item.UniqueId.Id),
                Subject = item.Envelope.Subject,
                Tos = item.Envelope.To.Mailboxes.Select(s => new MAIL_INBOX_ToModel
                {
                    Email = s.Address,
                    Name = s.Name
                }).ToList(),
                CCs = item.Envelope.Cc.Mailboxes.Select(s => new MAIL_INBOX_ToModel
                {
                    Email = s.Address,
                    Name = s.Name
                }).ToList(),
                BCCs = item.Envelope.Bcc.Mailboxes.Select(s => new MAIL_INBOX_ToModel
                {
                    Email = s.Address,
                    Name = s.Name
                }).ToList(),
                Attachs = mail_attachs
            };
        }

        /// <summary>
        /// Lấy đính kèm
        /// </summary>
        /// <param name="uniqueId"></param>
        /// <param name="config_AttachSource"></param>
        /// <param name="config_Code"></param>
        /// <returns></returns>
        List<string> GetAttachsMail(UniqueId uniqueId, string config_AttachSource, string config_Code)
        {
            var mail_attachs = new List<string>();
            try
            {
                MimeMessage message = client.Inbox.GetMessage(uniqueId);
                if (message != null && message.Attachments != null)
                {
                    foreach (MimeEntity entity in message.Attachments)
                    {
                        // determine a directory to save stuff in
                        var directory = Path.Combine(config_AttachSource, config_Code, uniqueId.ToString());
                        // create the directory
                        if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);

                        var fileName = entity.ContentDisposition?.FileName ?? entity.ContentType.Name;
                        if (File.Exists(Path.Combine(directory, fileName)))
                        {
                            mail_attachs.Add(fileName);
                        }
                        else
                        {
                            using (var stream = File.Create(Path.Combine(directory, fileName)))
                            {
                                if (entity is MessagePart)
                                {
                                    var rfc822 = (MessagePart)entity;
                                    var path = Path.Combine(directory, fileName);
                                    rfc822.Message.WriteTo(path);

                                    mail_attachs.Add(fileName);
                                }
                                else
                                {
                                    var part = (MimePart)entity;
                                    // note: it's possible for this to be null, but most will specify a filename
                                    var path = Path.Combine(directory, fileName);
                                    // decode and save the content to a file
                                    part.Content.DecodeTo(stream);

                                    mail_attachs.Add(fileName);
                                }
                            }
                        }



                    }
                }
            }
            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, ex.Message);
            }

            return mail_attachs;
        }

        /// <summary>
        /// Lấy body
        /// </summary>
        /// <param name="item"></param>
        /// <param name="htmlString"></param>
        void GetBodyMail(IMessageSummary item, out string? htmlString)
        {
            if (item.HtmlBody != null)
            {
                var body = (TextPart)client.Inbox.GetBodyPart(item.UniqueId, item.HtmlBody);
                var regx = new Regex("<body.*?>(?<theBody>.*)</body>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                Match match = regx.Match(body.Text);
                if (match.Success)
                {
                    htmlString = match.Groups["theBody"].Value;
                }
                else if (!string.IsNullOrEmpty(body.Text))
                {
                    htmlString = body.Text;
                }
                else
                {
                    if (item.TextBody != null)
                    {
                        body = (TextPart)client.Inbox.GetBodyPart(item.UniqueId, item.TextBody);
                        htmlString = body.Text;
                    }
                    else
                    {
                        htmlString = body.Text;
                    }
                }
            }
            else
            {
                var body = (TextPart)client.Inbox.GetBodyPart(item.UniqueId, item.TextBody);
                htmlString = body.Text;
            }
        }

        protected string GetBodyV2(string? htmlString)
        {
            if (!string.IsNullOrEmpty(htmlString))
            {
                var regx = new Regex("<body.*?>(?<theBody>.*)</body>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                Match match = regx.Match(htmlString);
                if (match.Success)
                {
                    htmlString = match.Groups["theBody"].Value;
                }
            }

            return htmlString;
        }

        public async Task GetFolderCS(EmailConfigModel config)
        {
            await ReconnectAsync(config);


            if (config.Folders != null && config.Folders.Count > 0)
            {
                var spaces = client.GetFolder(client.PersonalNamespaces[0]);
                var dataFolder = spaces.GetSubfolders(false);

                foreach (var folder in dataFolder)
                {
                    await HandlerSubFolderMail(config, config.Folders, folder);

                    Console.WriteLine("[folder] {0}", folder.Name);
                }
            }
        }

        async Task HandlerSubFolderMail(EmailConfigModel config, List<EmailConfigFolder> myFolders, IMailFolder ibFolder)
        {
            var myFolder = myFolders.Where(x => x.FolderName == ibFolder.Name).FirstOrDefault();
            if (myFolder != null)
            {
                //TH: có folder cha
                if (myFolder.SubFolders != null && myFolder.SubFolders.Count > 0)
                {
                    var ibSubFolders = ibFolder.GetSubfolders(false);
                    if (ibSubFolders != null && ibSubFolders.Count > 0)
                    {
                        foreach (var ibSub in ibSubFolders)
                        {
                            await HandlerSubFolderMail(config, myFolder.SubFolders, ibSub);
                        }
                    }
                }
                else
                {
                    await FetchMessageSummariesWithFolderAsync(config, ibFolder);
                }
            }
        }

        public async Task SetFlag(EmailConfigModel config, int uni)
        {
            try
            {
                await ReconnectAsync(config);

                var myU = new UniqueId(Convert.ToUInt32(uni));

                var us = new List<UniqueId>() { myU };
                IList<IMessageSummary> fetched = await client.Inbox.FetchAsync(us, request);
                if (fetched != null && fetched.Count > 0)
                {
                    client.Inbox.Store(fetched[0].UniqueId, new StoreFlagsRequest(StoreAction.Add, MessageFlags.Flagged) { Silent = true });
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        public async Task CheckSubFolder(EmailConfigModel config)
        {
            await ReconnectAsync(config);

            var allFolders = new List<SubfolderModel>();

            Console.OutputEncoding = Encoding.UTF8;
            var spaces = client.GetFolder(client.PersonalNamespaces[0]);
            var dataFolder = spaces.GetSubfolders(false);
            var sentItems = spaces.GetSubfolderAsync("Hộp thư đi");
            foreach (var item in dataFolder)
            {
                Console.WriteLine($"Lv1 --{item.Name}");
                var folder1 = item.GetSubfolders(false);
                foreach (var item1 in folder1)
                {
                    Console.WriteLine($"Lv2 ---{item1.Name}");
                    var folder2 = item1.GetSubfolders(false);
                    foreach (var item2 in folder2)
                    {
                        Console.WriteLine($"Lv3 ----{item2.Name}");
                        var folder3 = item2.GetSubfolders(false);
                        foreach (var item3 in folder3)
                        {
                            Console.WriteLine($"Lv4 -----{item3.Name}");
                            var folder4 = item3.GetSubfolders(false);
                            foreach (var item4 in folder4)
                            {
                                Console.WriteLine($"Lv5 ------{item4.Name}");

                            }
                        }
                    }
                }
            }
        }

        public async Task GetCheckMail(EmailConfigModel config, int uni)
        {
            try
            {
                await ReconnectAsync(config);

                var myU = new UniqueId(Convert.ToUInt32(uni));
                //, new UniqueId(404706)35886

                var us = new List<UniqueId>() { myU };

                //IList<IMessageSummary> fetched = await client.Inbox.FetchAsync(uniqueIds, request, cancel.Token);
                //if (fetched != null && fetched.Count > 0)
                //{
                //    foreach (var item in fetched)
                //    {
                //        if (item.Envelope.Subject == "Hỏi về hồ sơ bồi thường")
                //        {

                //        }
                //    }
                //}
                if (client.Inbox.PermanentFlags.HasFlag(MessageFlags.UserDefined))
                {
                    // folder supports user-defined custom flags
                }

                IList<IMessageSummary> fetched = await client.Inbox.FetchAsync(us, request);
                if (fetched != null && fetched.Count > 0)
                {
                    foreach (var item in fetched)
                    {
                        MimeMessage message = client.Inbox.GetMessage(myU);
                        var hp = new HtmlPreviewVisitor(item.UniqueId, config.Code);
                        message.Accept(hp);

                        var data = hp.HtmlBody;

                        //var htmlString = string.Empty;
                        //if (item.HtmlBody != null)
                        //{
                        //    var body = (TextPart)client.Inbox.GetBodyPart(item.UniqueId, item.HtmlBody);
                        //    var regx = new Regex("<body.*?>(?<theBody>.*)</body>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                        //    Match match = regx.Match(body.Text);
                        //    if (match.Success)
                        //    {
                        //        htmlString = match.Groups["theBody"].Value;
                        //    }
                        //    else if (!string.IsNullOrEmpty(body.Text))
                        //    {
                        //        htmlString = body.Text;
                        //    }
                        //    else
                        //    {
                        //        if (item.TextBody != null)
                        //        {
                        //            body = (TextPart)client.Inbox.GetBodyPart(item.UniqueId, item.TextBody);
                        //            htmlString = body.Text;
                        //        }
                        //        else
                        //        {
                        //            htmlString = body.Text;
                        //        }
                        //    }
                        //}
                        //else
                        //{
                        //    var body = (TextPart)client.Inbox.GetBodyPart(item.UniqueId, item.TextBody);
                        //    htmlString = body.Text;
                        //}

                        //MimeMessage message = client.Inbox.GetMessage(myU);
                        //var aaa = PopulateInlineImages(message, htmlString);

                        //// Using HtmlAgilityPack
                        //var doc = new HtmlDocument();
                        //doc.LoadHtml(htmlString);  // Load your html text here

                        //// Loop over the img tags in html doc
                        //foreach (var node in doc.DocumentNode.SelectNodes("//img"))
                        //{
                        //    // File path to the image. We get the src attribute off the current node for the file name.
                        //    var file = Path.Combine("", node.GetAttributeValue("src", ""));
                        //    if (!File.Exists(file))
                        //    {
                        //        continue;
                        //    }

                        //    // Set content type to the current image's extension, such as "png" or "jpg"
                        //    var contentType = new ContentType("image", Path.GetExtension(file));
                        //    var contentId = MimeKit.Utils.MimeUtils.GenerateMessageId();
                        //    var image = (MimePart)bodyBuilder.LinkedResources.Add(file, contentType);
                        //    image.ContentTransferEncoding = ContentEncoding.Base64;
                        //    image.ContentId = contentId;

                        //    // Set the current image's src attriubte to "cid:<content-id>"
                        //    node.SetAttributeValue("src", $"cid:" + contentId);
                        //}

                        //bodyBuilder.HtmlBody = doc.DocumentNode.OuterHtml;


                        //var multipart = (Multipart)fetched[0].BodyParts;
                        //foreach (var child in multipart)
                        //{
                        //}
                        ////var myImage = fetched[0].BodyParts.OfType<MimePart>().FirstOrDefault(x => x.IsMimeType("image", "png"));
                        //var myImage = fetched[0].BodyParts.OfType<MimePart>().FirstOrDefault();




                    }





                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }

        async Task FetchMessageSummariesAsync(EmailConfigModel config)
        {
            do
            {
                var data = new List<MAIL_INBOXCreateModel>(); ;
                try
                {
                    // fetch summary information for messages that we don't already have
                    int startIndex = await _InboxServices.GetMaxIndexPhiNhanThoInbox();
                    var myU = new UniqueId(Convert.ToUInt32(startIndex));
                    IList<UniqueId> uniqueIds = await client.Inbox.SearchAsync(SearchQuery.DeliveredAfter(DateTime.Now.AddHours(-7)), cancel.Token);
                    uniqueIds = uniqueIds.Where(x => x > myU).ToList();
                    if (uniqueIds == null || uniqueIds.Count == 0) break;

                    IList<IMessageSummary> fetched = await client.Inbox.FetchAsync(uniqueIds, request, cancel.Token);
                    if (fetched != null && fetched.Count > 0)
                    {
                        foreach (var item in fetched)
                        {
                            try
                            {
                                MimeMessage message = client.Inbox.GetMessage(myU);
                                var hp = new HtmlPreviewVisitor(item.UniqueId, config.Code);
                                message.Accept(hp);

                                var htmlString = GetBodyV2(hp.HtmlBody);

                                //GetBodyMail(item, out string? htmlString);
                                var mail_attachs = GetAttachsMail(item.UniqueId, config.AttachSource, config.Code);

                                var mapMail = GetDataMail(item, htmlString, mail_attachs, config.Code, config.Channel);
                                if (mapMail != null)
                                {
                                    var keywords = new HashSet<string>() { "$MailLabel1" };
                                    client.Inbox.AddFlags(item.UniqueId, MessageFlags.Flagged, keywords, true, cancel.Token);
                                    data.Add(mapMail);
                                }
                            }
                            catch (ImapCommandException ex)
                            {
                                _logger.LogError(ex, ex.Message);
                            }
                            catch (MessageNotFoundException ex)
                            {
                                _logger.LogError(ex, ex.Message);
                            }
                        }
                    }
                }
                catch (ImapProtocolException ex)
                {
                    _logger.LogError(ex, ex.Message);
                    await ReconnectAsync(config);
                }
                catch (IOException ex)
                {
                    _logger.LogError(ex, ex.Message);
                    await ReconnectAsync(config);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                    Thread.Sleep(15000);
                    break;
                }

                try
                {
                    if (data != null && data.Count > 0)
                    {
                        await _InboxServices.Create(data, config.Code);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                }

                break;

            } while (true);



        }

        async Task FetchMessageSummariesWithFolderAsync(EmailConfigModel config, IMailFolder folder)
        {
            do
            {
                var data = new List<MAIL_INBOXCreateModel>(); ;
                try
                {
                    var dataUni = await _InboxServices.GetUniqueBeforeAday(config.Code);
                    IList<UniqueId> uniqueIds = await client.Inbox.SearchAsync(
                        SearchQuery.DeliveredAfter(DateTime.Now.AddHours(-8)), cancel.Token);
                    if (uniqueIds == null || uniqueIds.Count == 0) break;

                    uniqueIds = uniqueIds.Where(p => !dataUni.Any(p2 => p2.Id == p.Id)).ToList();

                    IList<IMessageSummary> fetched = await client.Inbox.FetchAsync(uniqueIds, request, cancel.Token);
                    if (fetched != null && fetched.Count > 0)
                    {
                        var fetchedMess = fetched.Select(s => s.Envelope.MessageId).ToList();
                        var exitMess = await _InboxServices.GetMessageIdBeforeAday(config.Code);
                        fetchedMess = fetchedMess.Where(x => exitMess.Contains(x)).ToList();

                        foreach (var item in fetched)
                        {
                            folder.Store(item.UniqueId, new StoreFlagsRequest(StoreAction.Add, MessageFlags.Flagged) { Silent = true });
                            try
                            {
                                MimeMessage message = folder.GetMessage(item.UniqueId);
                                var hp = new HtmlPreviewVisitor(item.UniqueId, config.Code);
                                message.Accept(hp);

                                var htmlString = GetBodyV2(hp.HtmlBody);

                                var mail_attachs = GetAttachsMail(item.UniqueId, config.AttachSource, config.Code);

                                var mapMail = GetDataMail(item, htmlString, mail_attachs, config.Code, config.Channel);
                                if (mapMail != null)
                                {
                                    folder.Store(item.UniqueId, new StoreFlagsRequest(StoreAction.Add, MessageFlags.Flagged) { Silent = true });
                                    data.Add(mapMail);
                                }
                            }
                            catch (ImapCommandException ex)
                            {
                                _logger.LogError(ex, ex.Message);
                            }
                            catch (MessageNotFoundException ex)
                            {
                                _logger.LogError(ex, ex.Message);
                            }
                        }
                    }
                }
                catch (ImapProtocolException ex)
                {
                    _logger.LogError(ex, ex.Message);
                    await ReconnectAsync(config);
                }
                catch (IOException ex)
                {
                    _logger.LogError(ex, ex.Message);
                    await ReconnectAsync(config);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                    Thread.Sleep(15000);
                    break;
                }

                try
                {
                    if (data != null && data.Count > 0)
                    {
                        await _InboxServices.Create(data, config.Code);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                }

                break;

            } while (true);



        }

        async Task WaitForNewMessagesAsync(EmailConfigModel config)
        {
            do
            {
                try
                {
                    if (client.Capabilities.HasFlag(ImapCapabilities.Idle))
                    {
                        // Note: IMAP servers are only supposed to drop the connection after 30 minutes, so normally
                        // we'd IDLE for a max of, say, ~29 minutes... but GMail seems to drop idle connections after
                        // about 10 minutes, so we'll only idle for 9 minutes.
                        done = new CancellationTokenSource(new TimeSpan(0, 9, 0));
                        try
                        {
                            await client.IdleAsync(done.Token, cancel.Token);
                        }
                        finally
                        {
                            done.Dispose();
                            done = null;
                        }
                    }
                    else
                    {
                        // Note: we don't want to spam the IMAP server with NOOP commands, so lets wait a minute
                        // between each NOOP command.
                        await Task.Delay(new TimeSpan(0, 1, 0), cancel.Token);
                        await client.NoOpAsync(cancel.Token);
                    }
                    break;
                }
                catch (ImapProtocolException)
                {
                    // protocol exceptions often result in the client getting disconnected
                    await ReconnectAsync(config);
                }
                catch (IOException)
                {
                    // I/O exceptions always result in the client getting disconnected
                    await ReconnectAsync(config);
                }
            } while (true);
        }

        async Task IdleAsync(EmailConfigModel config)
        {
            do
            {
                try
                {
                    await WaitForNewMessagesAsync(config);

                    if (messagesArrived)
                    {
                        await FetchMessageSummariesAsync(config);
                        messagesArrived = false;
                    }
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            } while (!cancel.IsCancellationRequested);
        }

        public async Task<(bool, string)> RunAsync(EmailConfigModel config)
        {
            // connect to the IMAP server and get our initial list of messages
            try
            {
                await ReconnectAsync(config);
                //await FetchSentMessageAsync();
                //await FetchMessageSummariesAsync(config);
            }
            catch (OperationCanceledException ex)
            {
                await client.DisconnectAsync(true);
                _logger.LogError(ex, ex.Message);

                return (false, ex.Message);
            }

            // Note: We capture client.Inbox here because cancelling IdleAsync() *may* require
            // disconnecting the IMAP client connection, and, if it does, the `client.Inbox`
            // property will no longer be accessible which means we won't be able to disconnect
            // our event handlers.
            var inbox = client.Inbox;

            // keep track of changes to the number of messages in the folder (this is how we'll tell if new messages have arrived).
            inbox.CountChanged += OnCountChanged;

            // keep track of messages being expunged so that when the CountChanged event fires, we can tell if it's
            // because new messages have arrived vs messages being removed (or some combination of the two).
            inbox.MessageExpunged += OnMessageExpunged;

            // keep track of flag changes
            inbox.MessageFlagsChanged += OnMessageFlagsChanged;

            await IdleAsync(config);

            inbox.MessageFlagsChanged -= OnMessageFlagsChanged;
            inbox.MessageExpunged -= OnMessageExpunged;
            inbox.CountChanged -= OnCountChanged;

            await client.DisconnectAsync(true);


            return (true, string.Empty);
        }

        // Note: the CountChanged event will fire when new messages arrive in the folder and/or when messages are expunged.
        async void OnCountChanged(object sender, EventArgs e)
        {
            var folder = (ImapFolder)sender;
            await Task.CompletedTask;
            // Note: because we are keeping track of the MessageExpunged event and updating our
            // 'messages' list, we know that if we get a CountChanged event and folder.Count is
            // larger than messages.Count, then it means that new messages have arrived.
            //var counter = await _InboxServices.GetMaxIndexPhiNhanThoInbox();
            //if (folder.Count > counter)
            //{
            //    int arrived = folder.Count - counter;

            //    if (arrived > 1)
            //        Console.WriteLine("\t{0} new messages have arrived.", arrived);
            //    else
            //        Console.WriteLine("\t1 new message has arrived.");

            //    // Note: your first instinct may be to fetch these new messages now, but you cannot do
            //    // that in this event handler (the ImapFolder is not re-entrant).
            //    //
            //    // Instead, cancel the `done` token and update our state so that we know new messages
            //    // have arrived. We'll fetch the summaries for these new messages later...
            //    messagesArrived = true;
            //    done?.Cancel();
            //}

            messagesArrived = true;
            done?.Cancel();
        }

        void OnMessageExpunged(object sender, MessageEventArgs e)
        {
            //var folder = (ImapFolder)sender;

            //if (e.Index < messages.Count)
            //{
            //    var message = messages[e.Index];

            //    Console.WriteLine("{0}: message #{1} has been expunged: {2}", folder, e.Index, message.Envelope.Subject);

            //    // Note: If you are keeping a local cache of message information
            //    // (e.g. MessageSummary data) for the folder, then you'll need
            //    // to remove the message at e.Index.
            //    messages.RemoveAt(e.Index);
            //}
            //else
            //{
            //    Console.WriteLine("{0}: message #{1} has been expunged.", folder, e.Index);
            //}
        }

        void OnMessageFlagsChanged(object sender, MessageFlagsChangedEventArgs e)
        {
            var folder = (ImapFolder)sender;

            Console.WriteLine("{0}: flags have changed for message #{1} ({2}).", folder, e.Index, e.Flags);
        }

        public void Exit()
        {
            cancel.Cancel();
        }

        public void Dispose()
        {
            client.Dispose();
            cancel.Dispose();

            GC.SuppressFinalize(this);
        }
    }
}
