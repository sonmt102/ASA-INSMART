﻿
using ASA.Mail.Models;
using CTS.Common;
using CTS.Infra;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text.RegularExpressions;

namespace ASA.Mail.Services
{
    public interface ICompanyIdentityServices
    {
        Task RunAsync();
        Task<string> RunAsync(Guid mailId);
    }

    public class CompanyIdentityServices : ICompanyIdentityServices
    {
        private readonly ILogger<CompanyIdentityServices> _logger;
        private readonly CTSContext _Context;
        private readonly IBackgroundJobClient _BackgroundJobClient;

        public CompanyIdentityServices(CTSContext Context, ILogger<CompanyIdentityServices> logger, IBackgroundJobClient BackgroundJobClient)
        {
            _BackgroundJobClient = BackgroundJobClient;
            _Context = Context;
            _logger = logger;
        }

        public async Task RunAsync()
        {
            try
            {
                var mails = await _Context.MAIL_INBOXs.Where(x => x.Queue == CategoryConst.EmailNhanTho && !x.IsAssign
                 && !x.IsCheckSubject && string.IsNullOrEmpty(x.CongTy))
                .Include(x => x.MAIL_INBOX_Tos).OrderBy(x => x.Date).ToListAsync();
                if (mails == null || mails.Count == 0)
                {
                    _BackgroundJobClient.Schedule(() => RunAsync(), TimeSpan.FromSeconds(10));
                    return;
                }

                var allNhanCompany = await _Context.MAIL_Groups.Where(x => x.InboxQueueCode == CategoryConst.EmailNhanTho)
                      .Select(s => new NhanThoGroupModel
                      {
                          Id = s.Id,
                          Name = s.Name,
                          Order = s.Order,
                          Regex = s.Regex
                      }).ToListAsync();
                if (allNhanCompany == null || allNhanCompany.Count == 0)
                {
                    _BackgroundJobClient.Schedule(() => RunAsync(), TimeSpan.FromSeconds(10));
                    return;
                }

                foreach (var mail in mails)
                {
                    //Xử lý công ty BH
                    NhanThoGroupModel? resultCompany = null;
                    //TH có sub thì check format hợp đồng
                    if (mail.FromEmail.Contains("prudential.com.vn")
                        || mail.MAIL_INBOX_Tos.Any(t => t.Email.Contains("prudential.com.vn"))
                        || mail.MAIL_INBOX_CCs.Any(t => t.Email.Contains("prudential.com.vn")))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "PVA").FirstOrDefault();
                    }
                    else if (mail.FromEmail.Contains("manulife.com.vn") || mail.FromEmail.Contains("manulife.com")
                        || mail.FromEmail.Contains("techcombank.com.vn"))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "Manulife").FirstOrDefault();
                    }
                    else if (mail.FromEmail.Contains("aia.com") || mail.FromEmail.Contains("aiav.com.vn")
                        || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("aia")))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "AIA").FirstOrDefault();
                    }
                    else if (mail.FromEmail.Contains("fwd.com") || mail.FromEmail.Contains("fwdlife.com.vn")
                        || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("fwd")))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "FWD").FirstOrDefault();
                    }
                    else if (mail.FromEmail.Contains("mbageas.life") || mail.FromEmail.Contains("mbal") ||
                        (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("mbageas"))
                         || mail.MAIL_INBOX_Tos.Any(t => t.Email.Contains("mbageas")))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "MBAL").FirstOrDefault();
                    }
                    else if (mail.FromEmail.Contains("hanwhalife.com.vn")
                       || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("hanwhalife")))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "HWL").FirstOrDefault();
                    }
                    else if (mail.FromEmail.Contains("sunlife.com")
                       || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("sunlife")))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "Sunlife").FirstOrDefault();
                    }
                    else if (mail.FromEmail.Contains("chubb.com")
                       || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("chubb")))
                    {
                        resultCompany = allNhanCompany.Where(x => x.Name == "ChubbLife").FirstOrDefault();
                    }
                    else if (!string.IsNullOrEmpty(mail.Subject))
                    {
                        foreach (var item in allNhanCompany)
                        {
                            if (!string.IsNullOrEmpty(item.Regex))
                            {
                                var regs = item.Regex.Split(';');
                                if (regs != null && regs.Length > 0)
                                {
                                    for (int i = 0; i < regs.Length; i++)
                                    {
                                        if (!string.IsNullOrEmpty(regs[i]) && new Regex(regs[i]).IsMatch(mail.Subject))
                                        {
                                            resultCompany = item;
                                            break;
                                        }
                                    }
                                    if (resultCompany != null) break;
                                }
                            }
                        }

                    }

                    //Note lại đã kiểm tra subject
                    mail.IsCheckSubject = true;

                    //Nếu tìm thấy công ty
                    if (resultCompany != null)//Nếu có company thì lấy agent online trong đó
                    {
                        mail.CongTy = resultCompany.Name;
                    }

                }
                await _Context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }

            _BackgroundJobClient.Schedule(() => RunAsync(), TimeSpan.FromSeconds(10));


        }

        public async Task<string> RunAsync(Guid mailId)
        {
            //var mail = await _Context.MAIL_INBOXs.Where(x => x.Queue == CategoryConst.EmailNhanTho && !x.IsAssign
            //     && !x.IsCheckSubject && string.IsNullOrEmpty(x.CongTy) && x.Id == mailId)
            //    .Include(x => x.MAIL_INBOX_Tos).OrderBy(x => x.Date).FirstOrDefaultAsync();

            var mail = await _Context.MAIL_INBOXs.Where(x => x.Id == mailId)
                .Include(x => x.MAIL_INBOX_Tos).OrderBy(x => x.Date).FirstOrDefaultAsync();

            if (mail == null)
            {
                return "Không có dữ liệu mail";
            }

            var allNhanCompany = await _Context.MAIL_Groups.Where(x => x.InboxQueueCode == CategoryConst.EmailNhanTho)
                  .Select(s => new NhanThoGroupModel
                  {
                      Id = s.Id,
                      Name = s.Name,
                      Order = s.Order,
                      Regex = s.Regex
                  }).ToListAsync();
            if (allNhanCompany == null || allNhanCompany.Count == 0)
            {
                return "Không có công ty";
            }

            //Xử lý công ty BH
            NhanThoGroupModel? resultCompany = null;
            //TH có sub thì check format hợp đồng
            if (mail.FromEmail.Contains("prudential.com.vn")
                || mail.MAIL_INBOX_Tos.Any(t => t.Email.Contains("prudential.com.vn"))
                || mail.MAIL_INBOX_CCs.Any(t => t.Email.Contains("prudential.com.vn")))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "PVA").FirstOrDefault();
            }
            else if (mail.FromEmail.Contains("manulife.com.vn") || mail.FromEmail.Contains("manulife.com"))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "Manulife").FirstOrDefault();
            }
            else if (mail.FromEmail.Contains("aia.com") || mail.FromEmail.Contains("aiav.com.vn")
                || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("aia")))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "AIA").FirstOrDefault();
            }
            else if (mail.FromEmail.Contains("fwd.com") || mail.FromEmail.Contains("fwdlife.com.vn")
                || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("fwd")))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "FWD").FirstOrDefault();
            }
            else if (mail.FromEmail.Contains("mbageas.life") ||
                (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("mbageas")))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "MBAL").FirstOrDefault();
            }
            else if (mail.FromEmail.Contains("hanwhalife.com.vn")
               || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("hanwhalife")))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "HWL").FirstOrDefault();
            }
            else if (mail.FromEmail.Contains("sunlife.com")
               || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("sunlife")))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "Sunlife").FirstOrDefault();
            }
            else if (mail.FromEmail.Contains("chubb.com")
               || (!string.IsNullOrEmpty(mail.Subject) && mail.Subject.ToLower().Contains("chubb")))
            {
                resultCompany = allNhanCompany.Where(x => x.Name == "ChubbLife").FirstOrDefault();
            }
            else if (!string.IsNullOrEmpty(mail.Subject))
            {
                foreach (var item in allNhanCompany)
                {
                    if (!string.IsNullOrEmpty(item.Regex))
                    {
                        var regs = item.Regex.Split(';');
                        if (regs != null && regs.Length > 0)
                        {
                            for (int i = 0; i < regs.Length; i++)
                            {
                                if (!string.IsNullOrEmpty(regs[i]) && new Regex(regs[i]).IsMatch(mail.Subject))
                                {
                                    resultCompany = item;
                                    break;
                                }
                            }
                            if (resultCompany != null) break;
                        }
                    }
                }

            }

            //Note lại đã kiểm tra subject
            mail.IsCheckSubject = true;

            //Nếu tìm thấy công ty
            if (resultCompany != null)//Nếu có company thì lấy agent online trong đó
            {
                mail.CongTy = resultCompany.Name;
            }

            await _Context.SaveChangesAsync();

            return "OK";
        }

    }
}
