﻿//
// IdleClient.cs
//
// Author: Jeffrey Stedfast <jeff@xamarin.com>
//
// Copyright (c) 2014-2023 Jeffrey Stedfast
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

using ASA.Mail.Models;
using CTS.Common;
using ASA.SMTPAuth2;
using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using MailKit.Security;
using Microsoft.Extensions.Logging;
using MimeKit;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace ASA.Mail.Services
{
    public interface IIdleClientHelpdeskServices
    {
        Task<(bool, string)> RunAsync(EmailConfigModel config);
    }

    public class IdleClientHelpdeskServices : IDisposable, IIdleClientHelpdeskServices
    {
        private readonly CancellationTokenSource cancel;
        CancellationTokenSource? done;
        private readonly FetchRequest request;
        private readonly ImapClient client;
        private bool messagesArrived;
        private readonly ILogger<IdleClientHelpdeskServices> _logger;
        private readonly IInboxServices _InboxServices;
        private readonly CodeFlowHelper _codeFlowHelper;
        private readonly WellKnownConfigurationHandler _wellKnownConfigurationHandler;
        private readonly IHttpClientFactory _httpClientFactory;

        /// <summary>
        /// Contructor
        /// </summary>
        public IdleClientHelpdeskServices(ILogger<IdleClientHelpdeskServices> logger, IInboxServices InboxServices,
            CodeFlowHelper codeFlowHelper, WellKnownConfigurationHandler wellKnownConfigurationHandler,
             IHttpClientFactory httpClientFactory)
        {
            _InboxServices = InboxServices;
            _logger = logger;
            client = new ImapClient(new ProtocolLogger(Console.OpenStandardError()));
            request = new FetchRequest(MessageSummaryItems.Full | MessageSummaryItems.UniqueId);
            cancel = new CancellationTokenSource();
            _wellKnownConfigurationHandler = wellKnownConfigurationHandler;
            _codeFlowHelper = codeFlowHelper;
            _httpClientFactory = httpClientFactory;
        }

        async Task ReconnectAsync(EmailConfigModel config)
        {
            if (!client.IsConnected)
            {
                switch (config.ServerType)
                {
                    case ServerMailType.Gmail:
                        await client.ConnectAsync(config.Host, config.Port, SecureSocketOptions.Auto, cancel.Token);
                        break;
                    case ServerMailType.Office365:
                        await client.ConnectAsync(config.Host, config.Port, SecureSocketOptions.Auto, cancel.Token);
                        break;
                    default:
                        break;
                }

            }


            if (!client.IsAuthenticated)
            {
                switch (config.ServerType)
                {
                    case ServerMailType.Gmail:
                        await client.AuthenticateAsync(config.Username, config.Password, cancel.Token);

                        await client.Inbox.OpenAsync(FolderAccess.ReadWrite, cancel.Token);
                        break;
                    case ServerMailType.Office365:
                        {
                            OAuth2Client oAuth2Client = CreateOAuth2Client(config);
                            var request = await oAuth2Client.GenerateTokenRequestForClientFlowAsync(
                                $"https://login.microsoftonline.com/{config.TenantID}/v2.0",
                                "https://outlook.office365.com/.default",
                            config.ClientSecret);

                            var clientHttp = _httpClientFactory.CreateClient("default");
                            var response = await clientHttp.SendAsync(request);
                            if (!response.IsSuccessStatusCode)
                            {
                                string error = "";
                                if (response.Content != null)
                                {
                                    error = (await response.Content.ReadAsStringAsync()) ?? "";
                                }
                                _logger.LogError($"Internal error: {error}");
                                return;
                            }

                            var stringResponse = await response.Content.ReadAsStringAsync();
                            var obj = JsonConvert.DeserializeAnonymousType(stringResponse, new
                            {
                                access_token = ""
                            })!;

                            await client.AuthenticateAsync(new SaslMechanismOAuth2(config.Username, obj.access_token), cancel.Token);
                            await client.Inbox.OpenAsync(FolderAccess.ReadWrite, cancel.Token);
                        }
                        break;
                    default:
                        break;
                }

            }
        }

        private OAuth2Client CreateOAuth2Client(EmailConfigModel config)
        {
            var oAuth2Client = new OAuth2Client(
                _codeFlowHelper,
                _wellKnownConfigurationHandler,
                $"https://login.microsoftonline.com/{config.TenantID}/v2.0",
                config.ClientID);
            return oAuth2Client;
        }

        async Task FetchSentMessageAsync()
        {
            IMailFolder sent = null;

            if ((client.Capabilities & (ImapCapabilities.SpecialUse | ImapCapabilities.XList)) != 0)
            {
                sent = client.GetFolder(SpecialFolder.Sent);
            }

            if (client.Capabilities.HasFlag(ImapCapabilities.SpecialUse))
                sent = client.GetFolder(SpecialFolder.Sent);

            if (sent == null)
            {


                // get the default personal namespace root folder
                var personal = client.GetFolder(client.PersonalNamespaces[0]);

                var sentFolder = client.GetFolder(SpecialFolder.Sent);

                // This assumes the sent folder's name is "Sent", but use whatever the real name is
                sent = await personal.GetSubfolderAsync("Sent").ConfigureAwait(false);
            }

            //await sent.AppendAsync(email, MessageFlags.Seen).ConfigureAwait(false);
        }

        /// <summary>
        /// Map data
        /// </summary>
        /// <param name="item"></param>
        /// <param name="htmlString"></param>
        /// <param name="mail_attachs"></param>
        /// <param name="queue_code"></param>
        /// <param name="queue_channel"></param>
        /// <returns></returns>
        protected MAIL_INBOXCreateModel? GetDataMail(IMessageSummary item, string? htmlString, List<string> mail_attachs,
             string queue_code, string queue_channel)
        {
            var fromName = item.Envelope.From.Mailboxes.Select(s => s.Name).FirstOrDefault();
            var fromEmail = item.Envelope.From.Mailboxes.Select(s => s.Address).FirstOrDefault();
            return new MAIL_INBOXCreateModel
            {
                Queue = queue_code,
                Index = item.Index,
                Body = htmlString,
                IsReply = item.IsReply,
                Flag = item.Flags.HasValue ? item.Flags.Value.ToString() : null,
                Date = item.Date.LocalDateTime,
                From = fromName,
                Channel = queue_channel,
                FromEmail = fromEmail,
                InReplyTo = item.Envelope.InReplyTo,
                MessageId = item.Envelope.MessageId,
                UniqueId = Convert.ToInt32(item.UniqueId.Id),
                Subject = item.Envelope.Subject,
                Tos = item.Envelope.To.Mailboxes.Select(s => new MAIL_INBOX_ToModel
                {
                    Email = s.Address,
                    Name = s.Name
                }).ToList(),
                CCs = item.Envelope.Cc.Mailboxes.Select(s => new MAIL_INBOX_ToModel
                {
                    Email = s.Address,
                    Name = s.Name
                }).ToList(),
                BCCs = item.Envelope.Bcc.Mailboxes.Select(s => new MAIL_INBOX_ToModel
                {
                    Email = s.Address,
                    Name = s.Name
                }).ToList(),
                Attachs = mail_attachs
            };
        }

        /// <summary>
        /// Lấy đính kèm
        /// </summary>
        /// <param name="uniqueId"></param>
        /// <param name="attachs"></param>
        /// <param name="config_AttachSource"></param>
        /// <param name="config_Code"></param>
        /// <returns></returns>
        List<string> GetAttachsMailFromMine(UniqueId uniqueId, IList<MimeEntity> attachs, string config_AttachSource, string config_Code)
        {
            var mail_attachs = new List<string>();
            try
            {
                foreach (MimeEntity entity in attachs)
                {
                    // determine a directory to save stuff in
                    var directory = Path.Combine(config_AttachSource, config_Code, uniqueId.ToString());
                    // create the directory
                    if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);

                    var fileName = entity.ContentDisposition?.FileName ?? entity.ContentType.Name;
                    if (!string.IsNullOrEmpty(fileName)) fileName = Helper.ReplaceInvalidChars(fileName);
                    else continue;

                    if (File.Exists(Path.Combine(directory, fileName)))
                    {
                        mail_attachs.Add(fileName);
                    }
                    else
                    {
                        using (var stream = File.Create(Path.Combine(directory, fileName)))
                        {
                            if (entity is MessagePart)
                            {
                                var rfc822 = (MessagePart)entity;
                                var path = Path.Combine(directory, fileName);
                                rfc822.Message.WriteTo(path);

                                mail_attachs.Add(fileName);
                            }
                            else
                            {
                                var part = (MimePart)entity;
                                // note: it's possible for this to be null, but most will specify a filename
                                var path = Path.Combine(directory, fileName);
                                // decode and save the content to a file
                                part.Content.DecodeTo(stream);

                                mail_attachs.Add(fileName);
                            }
                        }
                    }
                }
            }
            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, ex.Message);
            }

            return mail_attachs;
        }

        /// <summary>
        /// Lấy nội dung mail
        /// </summary>
        /// <param name="htmlString"></param>
        /// <returns></returns>
        protected string GetBodyV2(string? htmlString)
        {
            if (!string.IsNullOrEmpty(htmlString))
            {
                var regx = new Regex("<body.*?>(?<theBody>.*)</body>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                Match match = regx.Match(htmlString);
                if (match.Success)
                {
                    htmlString = match.Groups["theBody"].Value;
                }
            }
            return htmlString;
        }

        async Task FetchMessageSummariesAsync(EmailConfigModel config)
        {
            do
            {
                var data = new List<MAIL_INBOXCreateModel>();
                try
                {
                    var dataUni = await _InboxServices.GetUniqueBeforeAday(config.Code);
                    IList<UniqueId> uniqueIds = await client.Inbox.SearchAsync(
                        SearchQuery.DeliveredAfter(DateTime.Now.AddHours(-8)), cancel.Token);
                    if (uniqueIds == null || uniqueIds.Count == 0) break;

                    if (dataUni != null) uniqueIds = uniqueIds.Where(p => !dataUni.Any(p2 => p2.Id == p.Id)).ToList();

                    IList<IMessageSummary> fetched = await client.Inbox.FetchAsync(uniqueIds, request, cancel.Token);
                    if (fetched != null && fetched.Count > 0)
                    {
                        var fetchedMess = fetched.Select(s => s.Envelope.MessageId).ToList();
                        var exitMess = await _InboxServices.GetMessageIdBeforeAday(config.Code);
                        fetchedMess = fetchedMess.Where(x => exitMess.Contains(x)).ToList();

                        foreach (var item in fetched)
                        {
                            client.Inbox.Store(item.UniqueId, new StoreFlagsRequest(StoreAction.Add, MessageFlags.Flagged) { Silent = true });

                            if (!fetchedMess.Contains(item.Envelope.MessageId))
                            {
                                try
                                {
                                    MimeMessage message = client.Inbox.GetMessage(item.UniqueId);
                                    var hp = new HtmlPreviewVisitor(item.UniqueId, config.Code);
                                    message.Accept(hp);
                                    var htmlString = GetBodyV2(hp.HtmlBody);

                                    var mail_attachs = GetAttachsMailFromMine(item.UniqueId, hp.Attachments, config.AttachSource, config.Code);

                                    var mapMail = GetDataMail(item, htmlString, mail_attachs, config.Code, config.Channel);
                                    if (mapMail != null)
                                    {
                                        client.Inbox.Store(item.UniqueId, new StoreFlagsRequest(StoreAction.Add, MessageFlags.Flagged) { Silent = true });
                                        data.Add(mapMail);
                                    }
                                }
                                catch (ImapCommandException ex)
                                {
                                    _logger.LogError(ex, ex.Message);
                                }
                                catch (MessageNotFoundException ex)
                                {
                                    _logger.LogError(ex, ex.Message);
                                }
                            }
                        }
                    }
                }
                catch (ImapProtocolException ex)
                {
                    _logger.LogError(ex, ex.Message);
                    // protocol exceptions often result in the client getting disconnected
                    await ReconnectAsync(config);
                }
                catch (IOException ex)
                {
                    _logger.LogError(ex, ex.Message);
                    // I/O exceptions always result in the client getting disconnected
                    await ReconnectAsync(config);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                    Thread.Sleep(15000);
                    break;
                }

                try
                {
                    if (data != null && data.Count > 0)
                    {
                        await _InboxServices.Create(data, config.Code);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                }

                break;

            } while (true);



        }

        async Task WaitForNewMessagesAsync(EmailConfigModel config)
        {
            do
            {
                try
                {
                    if (client.Capabilities.HasFlag(ImapCapabilities.Idle))
                    {
                        // Note: IMAP servers are only supposed to drop the connection after 30 minutes, so normally
                        // we'd IDLE for a max of, say, ~29 minutes... but GMail seems to drop idle connections after
                        // about 10 minutes, so we'll only idle for 9 minutes.
                        done = new CancellationTokenSource(new TimeSpan(0, 9, 0));
                        try
                        {
                            await client.IdleAsync(done.Token, cancel.Token);
                        }
                        finally
                        {
                            done.Dispose();
                            done = null;
                        }
                    }
                    else
                    {
                        // Note: we don't want to spam the IMAP server with NOOP commands, so lets wait a minute
                        // between each NOOP command.
                        await Task.Delay(new TimeSpan(0, 1, 0), cancel.Token);
                        await client.NoOpAsync(cancel.Token);
                    }
                    break;
                }
                catch (ImapProtocolException)
                {
                    // protocol exceptions often result in the client getting disconnected
                    await ReconnectAsync(config);
                }
                catch (IOException)
                {
                    // I/O exceptions always result in the client getting disconnected
                    await ReconnectAsync(config);
                }
            } while (true);
        }

        async Task IdleAsync(EmailConfigModel config)
        {
            do
            {
                try
                {
                    await WaitForNewMessagesAsync(config);

                    if (messagesArrived)
                    {
                        await FetchMessageSummariesAsync(config);
                        messagesArrived = false;
                    }
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            } while (!cancel.IsCancellationRequested);
        }

        public async Task<(bool, string)> RunAsync(EmailConfigModel config)
        {
            // connect to the IMAP server and get our initial list of messages
            try
            {
                await ReconnectAsync(config);
                //await FetchSentMessageAsync();
                await FetchMessageSummariesAsync(config);
            }
            catch (OperationCanceledException ex)
            {
                await client.DisconnectAsync(true);
                _logger.LogError(ex, ex.Message);

                return (false, ex.Message);
            }

            // Note: We capture client.Inbox here because cancelling IdleAsync() *may* require
            // disconnecting the IMAP client connection, and, if it does, the `client.Inbox`
            // property will no longer be accessible which means we won't be able to disconnect
            // our event handlers.
            var inbox = client.Inbox;

            // keep track of changes to the number of messages in the folder (this is how we'll tell if new messages have arrived).
            inbox.CountChanged += OnCountChanged;

            // keep track of messages being expunged so that when the CountChanged event fires, we can tell if it's
            // because new messages have arrived vs messages being removed (or some combination of the two).
            inbox.MessageExpunged += OnMessageExpunged;

            // keep track of flag changes
            inbox.MessageFlagsChanged += OnMessageFlagsChanged;

            await IdleAsync(config);

            inbox.MessageFlagsChanged -= OnMessageFlagsChanged;
            inbox.MessageExpunged -= OnMessageExpunged;
            inbox.CountChanged -= OnCountChanged;

            await client.DisconnectAsync(true);


            return (true, string.Empty);
        }

        // Note: the CountChanged event will fire when new messages arrive in the folder and/or when messages are expunged.
        async void OnCountChanged(object sender, EventArgs e)
        {
            var folder = (ImapFolder)sender;
            await Task.CompletedTask;
            // Note: because we are keeping track of the MessageExpunged event and updating our
            // 'messages' list, we know that if we get a CountChanged event and folder.Count is
            // larger than messages.Count, then it means that new messages have arrived.
            //var counter = await _InboxServices.GetMaxIndexPhiNhanThoInbox();
            //if (folder.Count > counter)
            //{
            //    int arrived = folder.Count - counter;

            //    if (arrived > 1)
            //        Console.WriteLine("\t{0} new messages have arrived.", arrived);
            //    else
            //        Console.WriteLine("\t1 new message has arrived.");

            //    // Note: your first instinct may be to fetch these new messages now, but you cannot do
            //    // that in this event handler (the ImapFolder is not re-entrant).
            //    //
            //    // Instead, cancel the `done` token and update our state so that we know new messages
            //    // have arrived. We'll fetch the summaries for these new messages later...
            //    messagesArrived = true;
            //    done?.Cancel();
            //}

            messagesArrived = true;
            done?.Cancel();
        }

        void OnMessageExpunged(object sender, MessageEventArgs e)
        {
            //var folder = (ImapFolder)sender;

            //if (e.Index < messages.Count)
            //{
            //    var message = messages[e.Index];

            //    Console.WriteLine("{0}: message #{1} has been expunged: {2}", folder, e.Index, message.Envelope.Subject);

            //    // Note: If you are keeping a local cache of message information
            //    // (e.g. MessageSummary data) for the folder, then you'll need
            //    // to remove the message at e.Index.
            //    messages.RemoveAt(e.Index);
            //}
            //else
            //{
            //    Console.WriteLine("{0}: message #{1} has been expunged.", folder, e.Index);
            //}
        }

        void OnMessageFlagsChanged(object sender, MessageFlagsChangedEventArgs e)
        {
            var folder = (ImapFolder)sender;

            Console.WriteLine("{0}: flags have changed for message #{1} ({2}).", folder, e.Index, e.Flags);
        }

        public void Exit()
        {
            cancel.Cancel();
        }

        public void Dispose()
        {
            client.Dispose();
            cancel.Dispose();

            GC.SuppressFinalize(this);
        }
    }
}
