﻿using ASA.Mail.Common;
using CTS.Common;

namespace ASA.Mail.Models
{
    public class EmailConfigModel
    {
        public ServerMailType ServerType { get; set; }
        public MailType Type { get; set; }
        public string? Host { get; set; }
        public int Port { get; set; }
        public string? Email { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? AttachSource { get; set; }
        public string? Code { get; set; }
        public string? Channel { get; set; }

        //Office 365
        public string? ClientID { get; set; }
        public string? ClientSecret { get; set; }
        public string? TenantID { get; set; }

        public List<EmailConfigFolder> Folders { get; set; }
    }

    public class EmailConfigFolder
    {
        public string FolderName { get; set; }
        public List<EmailConfigFolder> SubFolders { get; set; }
    }
}
