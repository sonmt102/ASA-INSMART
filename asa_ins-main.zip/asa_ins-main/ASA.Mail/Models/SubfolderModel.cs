﻿namespace ASA.Mail.Models
{
    public class SubfolderModel
    {
        public string Name { get; set; }
        public List<SubfolderModel> Subfolders { get; set; }
    }
}
