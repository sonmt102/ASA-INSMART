﻿using CTS.Common;

namespace ASA.Mail.Models
{
    public class DetailEmailModel
    {
        public Guid Id { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime Date { get; set; }
        public string DateStr { get => Date.ToString(FormatDate.DateTime_ddMMyyyyHHmm); }
        public List<DetailEmail_AttachModel> Attachs { get; set; }

    }

    public class DetailEmail_AttachModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
