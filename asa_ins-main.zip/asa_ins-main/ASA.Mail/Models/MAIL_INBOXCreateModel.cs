﻿namespace ASA.Mail.Models
{
    public class MAIL_INBOXCreateModel
    {
        public int Index { get; set; }
        public string? Queue { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        public string? PreviewBody { get; set; }
        public string? Channel { get; set; }
        public string? From { get; set; }
        public string? FromEmail { get; set; }
        public string? Flag { get; set; }
        public bool IsReply { get; set; }
        public string? MessageId { get; set; }
        public string? InReplyTo { get; set; }
        public string? FolderMail { get; set; }
        public int UniqueId { get; set; }
        public DateTime Date { get; set; }
        public List<MAIL_INBOX_ToModel> Tos { get; set; }
        public List<MAIL_INBOX_ToModel> CCs { get; set; }
        public List<MAIL_INBOX_ToModel> BCCs { get; set; }
        public List<string> Attachs { get; set; }
    }

    public class MAIL_INBOX_ToModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }


}
