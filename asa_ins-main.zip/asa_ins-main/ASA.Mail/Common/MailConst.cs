﻿namespace ASA.Mail.Common
{
    public static class MailConst
    {
        public const string FolderSentItem = "SentItems";
    }
}
