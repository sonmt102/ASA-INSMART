﻿using System;

namespace net.scan.ace.SecureMail
{
    internal enum SecureTransferEncoding
    {
        QuotedPrintable,
        Base64,
        SevenBit
    }
}
