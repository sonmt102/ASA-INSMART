﻿using System;
namespace CTS.AegisImplicitMail
{
    public class ServerException : Exception
    {
        public ServerException(String msg):base(msg)
        {
        }
    }
}
